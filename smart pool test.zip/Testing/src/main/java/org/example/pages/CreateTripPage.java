package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class CreateTripPage extends BasePage {
    private By originInput = By.cssSelector("input[placeholder='Search pickup location...']");
    private By destinationInput = By.cssSelector("input[placeholder='Search drop-off location...']");
    private By suggestionItem = By.cssSelector(".suggestion-item");
    private By vehicleSelect = By.name("vehicleId");
    private By departureTimeInput = By.name("departureTime");
    private By availableSeatsInput = By.name("availableSeats");
    private By pricePerSeatInput = By.name("pricePerSeat");
    private By approvalModeSelect = By.name("approvalMode");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By successAlert = By.cssSelector(".alert-success");
    private By errorAlert = By.cssSelector(".alert-danger");

    public CreateTripPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/create-trip");
    }

    public void selectPickup(String query) {
        writeText(originInput, query);
        // Wait for suggestions to load and click the first suggestion
        click(suggestionItem);
    }

    public void selectDropoff(String query) {
        writeText(destinationInput, query);
        // Wait for suggestions to load and click the first suggestion
        click(suggestionItem);
    }

    public void selectVehicleByVisibleText(String vehicleModel) {
        WebElement selectElement = waitVisibility(vehicleSelect);
        org.openqa.selenium.support.ui.Select select = new org.openqa.selenium.support.ui.Select(selectElement);
        for (WebElement option : select.getOptions()) {
            if (option.getText().contains(vehicleModel)) {
                select.selectByVisibleText(option.getText());
                break;
            }
        }
    }

    public void createTrip(String pickup, String dropoff, String vehicleModel, String departureTime, String seats, String price, String approvalMode) {
        selectPickup(pickup);
        selectDropoff(dropoff);
        if (vehicleModel != null) {
            selectVehicleByVisibleText(vehicleModel);
        }
        setAttribute(departureTimeInput, "value", departureTime);
        writeText(availableSeatsInput, seats);
        writeText(pricePerSeatInput, price);
        if (approvalMode != null) {
            selectByValue(approvalModeSelect, approvalMode);
        }
        click(submitButton);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }

    public String getErrorText() {
        return readText(errorAlert);
    }
}
