package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class NotificationsPage extends BasePage {
    private By latestNotifItem = By.cssSelector(".notif-item:first-of-type");
    private By latestNotifTitle = By.cssSelector(".notif-item:first-of-type .notif-title");
    private By latestNotifMessage = By.cssSelector(".notif-item:first-of-type .notif-msg");
    private By unreadCountText = By.cssSelector(".page-header p");
    private By markAllReadBtn = By.cssSelector(".page-header button");

    public NotificationsPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/notifications");
    }

    public String getLatestNotificationTitle() {
        return readText(latestNotifTitle);
    }

    public String getLatestNotificationMessage() {
        return readText(latestNotifMessage);
    }

    public String getUnreadCountText() {
        return readText(unreadCountText);
    }

    public void clickMarkAllAsRead() {
        if (isDisplayed(markAllReadBtn)) {
            click(markAllReadBtn);
        }
    }
}
