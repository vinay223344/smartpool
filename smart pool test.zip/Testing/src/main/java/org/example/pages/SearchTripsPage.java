package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class SearchTripsPage extends BasePage {
    private By originInput = By.cssSelector("input[placeholder='Search pickup location...']");
    private By destinationInput = By.cssSelector("input[placeholder='Search drop-off location...']");
    private By suggestionItem = By.cssSelector(".suggestion-item");
    private By searchButton = By.cssSelector("button[type='submit']");
    private By viewRideButton = By.cssSelector(".view-ride-btn");
    private By emptyState = By.cssSelector(".empty-state");

    public SearchTripsPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/search-trips");
    }

    public void selectPickup(String query) {
        writeText(originInput, query);
        click(suggestionItem);
    }

    public void selectDropoff(String query) {
        writeText(destinationInput, query);
        click(suggestionItem);
    }

    public void searchRides(String pickup, String dropoff) {
        selectPickup(pickup);
        selectDropoff(dropoff);
        click(searchButton);
    }

    public void viewFirstRide() {
        click(viewRideButton);
    }

    public void viewRideByDriver(String driverName) {
        By viewRideBtn = By.xpath("//div[contains(@class,'ride-card') and descendant::div[contains(@class,'driver-chip') and descendant::span[contains(text(),'" + driverName + "')]]]//a[contains(@class,'view-ride-btn')]");
        click(viewRideBtn);
    }

    public boolean isEmptyStateDisplayed() {
        return isDisplayed(emptyState);
    }

    public boolean isRideFound() {
        return isDisplayed(viewRideButton);
    }
}
