package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TripBookingsPage extends BasePage {

    public TripBookingsPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo(Long tripId) {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/trip-bookings/" + tripId);
    }

    public void approveBookingForPassenger(String email) {
        By approveBtn = By.xpath("//tr[descendant::small[contains(text(),'" + email + "')]]//button[contains(@class,'go')]");
        click(approveBtn);
    }

    public void rejectBookingForPassenger(String email) {
        By rejectBtn = By.xpath("//tr[descendant::small[contains(text(),'" + email + "')]]//button[contains(@class,'danger')]");
        click(rejectBtn);
    }

    public String getPassengerBookingStatus(String email) {
        By statusBadge = By.xpath("//tr[descendant::small[contains(text(),'" + email + "')]]//span[contains(@class,'badge-status')]");
        return readText(statusBadge);
    }
}
