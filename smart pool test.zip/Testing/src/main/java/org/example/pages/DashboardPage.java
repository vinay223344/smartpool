package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class DashboardPage extends BasePage {
    private By myTripsCount = By.xpath("//div[contains(@class,'scard')][descendant::span[contains(text(),'My Trips')]]//span[contains(@class,'scard-num')]");
    private By myBookingsCount = By.xpath("//div[contains(@class,'scard')][descendant::span[contains(text(),'My Bookings')]]//span[contains(@class,'scard-num')]");
    private By pendingCount = By.xpath("//div[contains(@class,'scard')][descendant::span[contains(text(),'Pending')]]//span[contains(@class,'scard-num')]");
    private By activeCount = By.xpath("//div[contains(@class,'scard')][descendant::span[contains(text(),'Active')]]//span[contains(@class,'scard-num')]");

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/dashboard");
    }

    public int getMyTripsCount() {
        return Integer.parseInt(readText(myTripsCount).trim());
    }

    public int getMyBookingsCount() {
        return Integer.parseInt(readText(myBookingsCount).trim());
    }

    public int getPendingCount() {
        return Integer.parseInt(readText(pendingCount).trim());
    }

    public int getActiveCount() {
        return Integer.parseInt(readText(activeCount).trim());
    }
}
