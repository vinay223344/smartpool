package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class LoginPage extends BasePage {
    private By emailInput = By.name("email");
    private By passwordInput = By.name("password");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By errorAlert = By.cssSelector(".alert-danger");
    private By forgotLink = By.cssSelector("a[routerLink='/forgot-password']");
    private By registerLink = By.cssSelector("a[routerLink='/register']");

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/login");
    }

    public void logout() {
        try {
            org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
            js.executeScript("window.localStorage.clear();");
            js.executeScript("window.sessionStorage.clear();");
        } catch (Exception ignored) {}
        navigateTo();
    }

    public void login(String email, String password) {
        waitForUrlToContain("/login", 5);
        writeText(emailInput, email);
        writeText(passwordInput, password);
        click(submitButton);
    }

    public String getErrorText() {
        return readText(errorAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }

    public void clickForgot() {
        click(forgotLink);
    }

    public void clickRegister() {
        click(registerLink);
    }
}
