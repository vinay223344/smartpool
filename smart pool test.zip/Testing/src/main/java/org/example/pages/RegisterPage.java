package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class RegisterPage extends BasePage {
    private By nameInput = By.name("name");
    private By emailInput = By.name("email");
    private By passwordInput = By.name("password");
    private By phoneInput = By.name("phone");
    private By genderSelect = By.name("gender");
    private By departmentInput = By.name("department");
    private By cityInput = By.name("city");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By errorAlert = By.cssSelector(".alert-danger");
    private By successAlert = By.cssSelector(".alert-success");
    private By loginRedirectionLink = By.linkText("Sign in");

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/register");
    }

    public void register(String name, String email, String password, String phone, String gender, String department, String city) {
        writeText(nameInput, name);
        writeText(emailInput, email);
        writeText(passwordInput, password);
        writeText(phoneInput, phone);
        if (gender != null && !gender.isEmpty()) {
            selectByValue(genderSelect, gender);
        }
        writeText(departmentInput, department);
        writeText(cityInput, city);
        click(submitButton);
    }

    public String getErrorText() {
        return readText(errorAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }

    public String getSuccessText() {
        return readText(successAlert);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successAlert);
    }

    public void clickSignIn() {
        click(loginRedirectionLink);
    }
}
