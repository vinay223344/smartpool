package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ForgotPasswordPage extends BasePage {
    private By emailInput = By.name("email");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By errorAlert = By.cssSelector(".alert-danger");
    private By successAlert = By.cssSelector(".alert-success");
    private By backToSignInLink = By.linkText("Back to Sign In");

    public ForgotPasswordPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/forgot-password");
    }

    public void requestResetLink(String email) {
        writeText(emailInput, email);
        click(submitButton);
    }

    public String getErrorText() {
        return readText(errorAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }

    public String getSuccessText() {
        return readText(successAlert);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successAlert);
    }

    public void clickBackToSignIn() {
        click(backToSignInLink);
    }
}
