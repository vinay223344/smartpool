package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class AdminVehiclesPage extends BasePage {

    public AdminVehiclesPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/admin/vehicles");
    }

    public void approveVehicleByPlate(String licensePlate) {
        By approveBtnLocator = By.xpath("//div[contains(@class,'card')][descendant::small[contains(text(),'" + licensePlate + "')]]//button[contains(text(),'Approve')]");
        click(approveBtnLocator);
    }
    
    public boolean isVehiclePending(String licensePlate) {
        By cardLocator = By.xpath("//div[contains(@class,'card')][descendant::small[contains(text(),'" + licensePlate + "')]]");
        return isDisplayed(cardLocator);
    }
}
