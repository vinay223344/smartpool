package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class BasePage {
    protected WebDriver driver;
    protected WebDriverWait wait;

    public BasePage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
    }

    protected WebElement waitVisibility(By locator) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    protected WebElement waitPresence(By locator) {
        return wait.until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    protected void click(By locator) {
        WebElement element = wait.until(ExpectedConditions.elementToBeClickable(locator));
        try {
            element.click();
        } catch (org.openqa.selenium.ElementClickInterceptedException e) {
            org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
            js.executeScript("arguments[0].click();", element);
        }
    }

    protected void writeText(By locator, String text) {
        WebElement element = waitVisibility(locator);
        element.clear();
        element.sendKeys(text);
    }

    protected String readText(By locator) {
        return waitVisibility(locator).getText();
    }

    protected boolean isDisplayed(By locator) {
        try {
            return waitVisibility(locator).isDisplayed();
        } catch (Exception e) {
            return false;
        }
    }

    protected void setAttribute(By locator, String attributeName, String value) {
        WebElement element = waitVisibility(locator);
        org.openqa.selenium.JavascriptExecutor js = (org.openqa.selenium.JavascriptExecutor) driver;
        js.executeScript("arguments[0].setAttribute(arguments[1], arguments[2]);", element, attributeName, value);
        js.executeScript("arguments[0].value = arguments[2];", element, attributeName, value);
        js.executeScript("arguments[0].dispatchEvent(new Event('input', { bubbles: true }));", element);
        js.executeScript("arguments[0].dispatchEvent(new Event('change', { bubbles: true }));", element);
    }

    public boolean waitForUrlToContain(String fraction, int timeoutSeconds) {
        WebDriverWait urlWait = new WebDriverWait(driver, Duration.ofSeconds(timeoutSeconds));
        try {
            return urlWait.until(ExpectedConditions.urlContains(fraction));
        } catch (Exception e) {
            return false;
        }
    }

    protected void selectByValue(By locator, String value) {
        WebElement selectElement = waitVisibility(locator);
        Select select = new Select(selectElement);
        select.selectByValue(value);
    }
}
