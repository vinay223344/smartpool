package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class MyTripsPage extends BasePage {

    public MyTripsPage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/my-trips");
    }

    public String getTripStatus(String origin, String destination) {
        By statusLocator = By.xpath("//tr[descendant::strong[contains(text(),'" + origin + "')] and descendant::strong[contains(text(),'" + destination + "')]]//span[contains(@class,'badge-status')]");
        return readText(statusLocator);
    }

    public void cancelTrip(String origin, String destination) {
        By cancelBtnLocator = By.xpath("//tr[descendant::strong[contains(text(),'" + origin + "')] and descendant::strong[contains(text(),'" + destination + "')]]//button[contains(@class,'danger')]");
        click(cancelBtnLocator);
        // Accept the confirmation dialog
        driver.switchTo().alert().accept();
    }

    public boolean isTripDisplayed(String origin, String destination) {
        By rowLocator = By.xpath("//tr[descendant::strong[contains(text(),'" + origin + "')] and descendant::strong[contains(text(),'" + destination + "')]]");
        return isDisplayed(rowLocator);
    }

    public Long getTripId(String origin, String destination) {
        By bookingsLink = By.xpath("//tr[descendant::strong[contains(text(),'" + origin + "')] and descendant::strong[contains(text(),'" + destination + "')]]//a[contains(@href,'/trip-bookings/')]");
        String href = waitVisibility(bookingsLink).getAttribute("href");
        return Long.parseLong(href.substring(href.lastIndexOf("/") + 1));
    }
}
