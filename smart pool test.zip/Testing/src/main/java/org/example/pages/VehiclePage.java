package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class VehiclePage extends BasePage {
    private By licensePlateInput = By.name("licensePlate");
    private By modelInput = By.name("model");
    private By colorInput = By.name("color");
    private By totalSeatsInput = By.name("totalSeats");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By successAlert = By.cssSelector(".alert-success");

    public VehiclePage(WebDriver driver) {
        super(driver);
    }

    public void navigateTo() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/my-vehicles");
    }

    public void registerVehicle(String licensePlate, String model, String color, String totalSeats) {
        writeText(licensePlateInput, licensePlate);
        writeText(modelInput, model);
        writeText(colorInput, color);
        writeText(totalSeatsInput, totalSeats);
        click(submitButton);
    }

    public String getSuccessMessage() {
        return readText(successAlert);
    }

    public boolean isSuccessMessageDisplayed() {
        return isDisplayed(successAlert);
    }

    public String getVehicleStatus(String licensePlate) {
        By statusLocator = By.xpath("//div[contains(@class,'vcard')][descendant::div[contains(text(),'" + licensePlate + "')]]//span[contains(@class,'v-tag')]");
        return readText(statusLocator);
    }
}
