package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class TripDetailPage extends BasePage {
    private By bookingButton = By.cssSelector("button.book-btn");
    private By successAlert = By.cssSelector(".alert-success");
    private By errorAlert = By.cssSelector(".alert-danger");
    private By alertMessage = By.cssSelector(".alert");
    private By minusButton = By.cssSelector(".seat-stepper button:nth-of-type(1)");
    private By plusButton = By.cssSelector(".seat-stepper button:nth-of-type(2)");
    private By seatsInput = By.cssSelector(".seat-stepper input");
    private By statusBadge = By.cssSelector(".pg-head .badge-status");
    private By cancelBookingBtn = By.cssSelector("button.cancel-btn");

    public TripDetailPage(WebDriver driver) {
        super(driver);
    }

    public void bookSeats(int count) {
        // Stepper defaults to 1. If we need more, click plus button (count - 1) times
        for (int i = 1; i < count; i++) {
            click(plusButton);
        }
        click(bookingButton);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }

    public String getAlertText() {
        return readText(alertMessage);
    }

    public String getTripStatus() {
        return readText(statusBadge);
    }

    public void cancelBooking() {
        click(cancelBookingBtn);
        driver.switchTo().alert().accept();
    }
}
