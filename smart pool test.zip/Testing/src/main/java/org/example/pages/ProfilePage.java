package org.example.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class ProfilePage extends BasePage {
    private By nameInput = By.name("name");
    private By phoneInput = By.name("phone");
    private By genderSelect = By.name("gender");
    private By departmentInput = By.name("department");
    private By cityInput = By.name("city");
    private By submitButton = By.cssSelector("button[type='submit']");
    private By successAlert = By.cssSelector(".alert-success");
    private By errorAlert = By.cssSelector(".alert-danger");
    private By photoFileInput = By.cssSelector("input[type='file']");
    
    // Header settings link to access profile page
    private By settingsLink = By.cssSelector("a[routerLink='/profile']");

    public ProfilePage(WebDriver driver) {
        super(driver);
    }

    public void navigateToProfile() {
        driver.get(org.example.utils.ConfigReader.getProperty("url") + "/profile");
    }

    public void updateProfile(String name, String phone, String gender, String department, String city) {
        writeText(nameInput, name);
        writeText(phoneInput, phone);
        if (gender != null && !gender.isEmpty()) {
            selectByValue(genderSelect, gender);
        }
        writeText(departmentInput, department);
        writeText(cityInput, city);
        click(submitButton);
    }

    public void uploadPhoto(String absoluteFilePath) {
        // Since file input is hidden but present, send keys works on it directly in Selenium
        waitPresence(photoFileInput).sendKeys(absoluteFilePath);
    }

    public String getSuccessText() {
        return readText(successAlert);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successAlert);
    }

    public String getErrorText() {
        return readText(errorAlert);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorAlert);
    }
}
