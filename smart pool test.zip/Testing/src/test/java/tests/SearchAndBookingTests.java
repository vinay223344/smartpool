package tests;

import org.example.pages.*;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Random;

public class SearchAndBookingTests extends BaseTest {

    private String registerAndApproveVehicle(String email) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        VehiclePage vehiclePage = new VehiclePage(driver);
        vehiclePage.navigateTo();
        String licensePlate = "TN-99-BK-" + (1000 + new Random().nextInt(9000));
        vehiclePage.registerVehicle(licensePlate, "Ford Mustang", "Yellow", "4");
        Assert.assertTrue(vehiclePage.isSuccessMessageDisplayed());

        loginPage.logout();

        loginPage.login("admin@cognizant.com", "admin");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        AdminVehiclesPage adminVehiclesPage = new AdminVehiclesPage(driver);
        adminVehiclesPage.navigateTo();
        adminVehiclesPage.approveVehicleByPlate(licensePlate);

        loginPage.logout();

        return "Ford Mustang";
    }

    @Test
    public void testSearchAndBookTrip_Success() {
        // 1. Setup Driver
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String driverName = "Seat Driver " + System.currentTimeMillis();
        String driverEmail = "s_driver_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register(driverName, driverEmail, "Password123", "9876543210", "MALE", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        String vehicleModel = registerAndApproveVehicle(driverEmail);

        // 2. Offer ride as Driver
        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(driverEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        CreateTripPage createTripPage = new CreateTripPage(driver);
        createTripPage.navigateTo();
        createTripPage.createTrip("Chennai", "Bangalore", vehicleModel, "2026-10-15T08:30", "4", "450.00", "MANUAL");
        Assert.assertTrue(createTripPage.isSuccessDisplayed());

        MyTripsPage myTripsPage = new MyTripsPage(driver);
        myTripsPage.navigateTo();
        Long tripId = myTripsPage.getTripId("Chennai", "Bangalore");
        
        loginPage.logout(); // Logout Driver

        // 3. Setup Passenger
        registerPage.navigateTo();
        String passengerEmail = "s_pass_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Seat Passenger", passengerEmail, "Password123", "9876543211", "FEMALE", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        loginPage.navigateTo(); // Navigate to login page first!
        loginPage.login(passengerEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        // 4. Search and book ride as Passenger
        SearchTripsPage searchPage = new SearchTripsPage(driver);
        searchPage.navigateTo();
        searchPage.searchRides("Chennai", "Bangalore");
        Assert.assertTrue(searchPage.isRideFound(), "Rides should be found matching the route");
        searchPage.viewRideByDriver(driverName);

        TripDetailPage detailPage = new TripDetailPage(driver);
        detailPage.bookSeats(2); // book 2 seats
        
        if (!detailPage.isSuccessDisplayed()) {
            String errorMsg = detailPage.getAlertText();
            System.err.println("=== BOOKING DIAGNOSTIC ERROR MSG: " + errorMsg + " ===");
            Assert.fail("Booking failed. Error alert message shown: " + errorMsg);
        }
        Assert.assertTrue(detailPage.getAlertText().toLowerCase().contains("request"));

        loginPage.logout(); // Logout Passenger

        // 5. Driver reviews and approves booking request
        loginPage.login(driverEmail, "Password123");
        if (!loginPage.waitForUrlToContain("/dashboard", 10)) {
            String loginError = loginPage.isErrorDisplayed() ? loginPage.getErrorText() : "Unknown redirect failure";
            System.err.println("=== DRIVER LOGIN FAILED: " + loginError + " ===");
            Assert.fail("Driver login failed: " + loginError);
        }

        TripBookingsPage bookingsPage = new TripBookingsPage(driver);
        bookingsPage.navigateTo(tripId);
        try {
            Assert.assertEquals(bookingsPage.getPassengerBookingStatus(passengerEmail), "PENDING");
        } catch (Exception e) {
            System.err.println("=== DIAGNOSTIC: BOOKINGS PAGE SOURCE ===");
            System.err.println(driver.getPageSource());
            throw e;
        }
        bookingsPage.approveBookingForPassenger(passengerEmail);
        
        // Wait for page update
        try {
            Assert.assertEquals(bookingsPage.getPassengerBookingStatus(passengerEmail), "APPROVED");
        } catch (Exception e) {
            System.err.println("=== DIAGNOSTIC: BOOKINGS APPROVED CHECK FAILED ===");
            System.err.println(driver.getPageSource());
            throw e;
        }

        loginPage.logout(); // Logout Driver

        // 6. Passenger checks dashboard metrics and notifications
        loginPage.login(passengerEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        DashboardPage dashboardPage = new DashboardPage(driver);
        dashboardPage.navigateTo();
        Assert.assertEquals(dashboardPage.getMyBookingsCount(), 1, "Passenger booking stat card should increment to 1");

        NotificationsPage notificationsPage = new NotificationsPage(driver);
        notificationsPage.navigateTo();
        Assert.assertTrue(notificationsPage.getLatestNotificationTitle().contains("Booking Approved"), "Latest notification title matches approval");
        Assert.assertTrue(notificationsPage.getLatestNotificationMessage().contains("Chennai"), "Latest notification mentions the route");
    }

    @Test
    public void testSearchNoRidesFound() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.logout(); // Ensure fresh state
        
        // Register standard passenger to search
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String passengerEmail = "search_fail_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Fail Searcher", passengerEmail, "Password123", "9876543212", "OTHER", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        loginPage.navigateTo(); // Navigate to login page first!
        loginPage.login(passengerEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        SearchTripsPage searchPage = new SearchTripsPage(driver);
        searchPage.navigateTo();
        // Route with no rides offered
        searchPage.searchRides("Salem", "Hosur");
        
        Assert.assertTrue(searchPage.isEmptyStateDisplayed(), "Empty state should be displayed when no matching rides are found");
    }
}
