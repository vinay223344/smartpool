package tests;

import org.example.pages.LoginPage;
import org.example.pages.RegisterPage;
import org.example.pages.VehiclePage;
import org.example.pages.AdminVehiclesPage;
import org.example.pages.CreateTripPage;
import org.example.pages.MyTripsPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Random;

public class TripTests extends BaseTest {

    private String driverEmail;
    private String vehicleModel;

    private String registerAndApproveVehicle(String email) {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        VehiclePage vehiclePage = new VehiclePage(driver);
        vehiclePage.navigateTo();
        String licensePlate = "TN-99-TR-" + (1000 + new Random().nextInt(9000));
        vehiclePage.registerVehicle(licensePlate, "Tesla Model S", "Black", "5");
        Assert.assertTrue(vehiclePage.isSuccessMessageDisplayed());

        loginPage.logout();

        loginPage.login("admin@cognizant.com", "admin");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        AdminVehiclesPage adminVehiclesPage = new AdminVehiclesPage(driver);
        adminVehiclesPage.navigateTo();
        adminVehiclesPage.approveVehicleByPlate(licensePlate);

        loginPage.logout();

        return "Tesla Model S";
    }

    @Test
    public void testCreateSingleTrip_Success() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        driverEmail = "trip_driver_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Trip Driver", driverEmail, "Password123", "9876543210", "MALE", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        vehicleModel = registerAndApproveVehicle(driverEmail);

        LoginPage loginPage = new LoginPage(driver);
        loginPage.login(driverEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        CreateTripPage createTripPage = new CreateTripPage(driver);
        createTripPage.navigateTo();
        createTripPage.createTrip("Chennai", "Bangalore", vehicleModel, "2026-10-15T08:30", "4", "450.00", "MANUAL");

        Assert.assertTrue(createTripPage.isSuccessDisplayed(), "Trip should be created successfully");

        MyTripsPage myTripsPage = new MyTripsPage(driver);
        myTripsPage.navigateTo();
        Assert.assertTrue(myTripsPage.isTripDisplayed("Chennai", "Bangalore"), "Created trip should be displayed in trips list");
        Assert.assertEquals(myTripsPage.getTripStatus("Chennai", "Bangalore"), "SCHEDULED");

        myTripsPage.cancelTrip("Chennai", "Bangalore");
        Assert.assertEquals(myTripsPage.getTripStatus("Chennai", "Bangalore"), "CANCELLED");
    }

    @Test(dependsOnMethods = "testCreateSingleTrip_Success")
    public void testCreateTrip_FutureDateGuard() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(driverEmail, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        CreateTripPage createTripPage = new CreateTripPage(driver);
        createTripPage.navigateTo();
        createTripPage.createTrip("Chennai", "Bangalore", vehicleModel, "2020-01-01T08:30", "4", "450.00", "MANUAL");

        Assert.assertTrue(createTripPage.isErrorDisplayed() || !driver.getCurrentUrl().contains("/my-trips"), "Should show error alert or block submission");
    }
}
