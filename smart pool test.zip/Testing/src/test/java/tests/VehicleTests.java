package tests;

import org.example.pages.LoginPage;
import org.example.pages.RegisterPage;
import org.example.pages.VehiclePage;
import org.example.pages.AdminVehiclesPage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.util.Random;

public class VehicleTests extends BaseTest {

    @Test
    public void testRegisterVehicle_PendingApproval() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String email = "driver_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Driver User", email, "Password123", "9876543210", "MALE", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        VehiclePage vehiclePage = new VehiclePage(driver);
        vehiclePage.navigateTo();
        String licensePlate = "TN-99-AA-" + (1000 + new Random().nextInt(9000));
        vehiclePage.registerVehicle(licensePlate, "Swift Dzire", "White", "4");

        Assert.assertTrue(vehiclePage.isSuccessMessageDisplayed());
        Assert.assertTrue(vehiclePage.getSuccessMessage().contains("Awaiting admin approval"));
        
        Assert.assertTrue(vehiclePage.getVehicleStatus(licensePlate).contains("Pending"), "Status should be Pending initially");
    }

    @Test
    public void testAdminApproveVehicle() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String email = "driver_approve_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Driver Approve", email, "Password123", "9876543210", "FEMALE", "QA", "Coimbatore");
        Assert.assertTrue(registerPage.isSuccessDisplayed());

        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        VehiclePage vehiclePage = new VehiclePage(driver);
        vehiclePage.navigateTo();
        String licensePlate = "TN-99-BB-" + (1000 + new Random().nextInt(9000));
        vehiclePage.registerVehicle(licensePlate, "Hyundai i20", "Red", "5");
        Assert.assertTrue(vehiclePage.isSuccessMessageDisplayed());
        
        loginPage.logout();

        loginPage.login("admin@cognizant.com", "admin");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        AdminVehiclesPage adminVehiclesPage = new AdminVehiclesPage(driver);
        adminVehiclesPage.navigateTo();
        Assert.assertTrue(adminVehiclesPage.isVehiclePending(licensePlate), "Vehicle should be pending in admin queue");
        
        adminVehiclesPage.approveVehicleByPlate(licensePlate);
        
        loginPage.logout();

        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        vehiclePage.navigateTo();
        Assert.assertTrue(vehiclePage.getVehicleStatus(licensePlate).contains("Approved"), "Status should be Approved after admin action");
    }
}
