package tests;

import org.example.pages.LoginPage;
import org.example.pages.RegisterPage;
import org.example.pages.ProfilePage;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class ProfileTests extends BaseTest {

    @Test
    public void testUpdateProfileDetails() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String email = "profile_test_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Profile User", email, "Password123", "9876543210", "MALE", "QA", "Coimbatore");

        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.navigateToProfile();

        profilePage.updateProfile("Profile User Updated", "9988776655", "FEMALE", "Engineering", "Chennai");
        Assert.assertTrue(profilePage.isSuccessDisplayed(), "Success alert should be displayed after profile update");
        Assert.assertTrue(profilePage.getSuccessText().contains("updated"), "Success message mismatch");
    }

    @Test
    public void testProfilePictureUpload() throws IOException {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String email = "pic_test_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Pic User", email, "Password123", "9876543210", "MALE", "QA", "Coimbatore");

        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(email, "Password123");
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10));

        ProfilePage profilePage = new ProfilePage(driver);
        profilePage.navigateToProfile();

        // Create a dummy temp image file to upload
        File tempImage = File.createTempFile("avatar_temp", ".jpg");
        tempImage.deleteOnExit();
        try (FileWriter writer = new FileWriter(tempImage)) {
            writer.write("dummy image data");
        }

        profilePage.uploadPhoto(tempImage.getAbsolutePath());
        
        Assert.assertFalse(profilePage.isErrorDisplayed(), "Error should not be shown during photo upload");
    }
}
