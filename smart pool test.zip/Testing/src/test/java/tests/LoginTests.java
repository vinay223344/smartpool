package tests;

import org.example.pages.LoginPage;
import org.example.pages.RegisterPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class LoginTests extends BaseTest {

    @Test
    public void testLoginFailure_InvalidCredentials() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login("wronguser@cognizant.com", "WrongPassword");

        Assert.assertTrue(loginPage.isErrorDisplayed(), "Error message should be shown for invalid login");
        Assert.assertTrue(loginPage.getErrorText().contains("Invalid email or password"), "Error message text mismatch");
    }

    @Test
    public void testLoginFailure_BlankFields() {
        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login("", "");

        // Should prevent login attempt (HTML5 validation required tags)
        Assert.assertFalse(driver.getCurrentUrl().contains("/dashboard"), "Should not redirect to dashboard");
    }

    @Test
    public void testLoginSuccess_AfterRegistration() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String uniqueEmail = "login_test_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Login Tester", uniqueEmail, "Password123", "9876543210", "FEMALE", "QA", "Coimbatore");
        
        Assert.assertTrue(registerPage.isSuccessDisplayed(), "Registration should succeed");

        LoginPage loginPage = new LoginPage(driver);
        loginPage.navigateTo();
        loginPage.login(uniqueEmail, "Password123");
        
        // Assert we are redirected to Dashboard
        Assert.assertTrue(loginPage.waitForUrlToContain("/dashboard", 10), "Should redirect to dashboard after successful login");
    }
}
