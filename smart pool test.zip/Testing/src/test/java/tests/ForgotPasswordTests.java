package tests;

import org.example.pages.LoginPage;
import org.example.pages.ForgotPasswordPage;
import org.example.pages.RegisterPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ForgotPasswordTests extends BaseTest {

    @Test
    public void testForgotPassword_Success() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String email = "forgot_test_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Forgot Tester", email, "Password123", "9876543210", "OTHER", "QA", "Coimbatore");

        ForgotPasswordPage forgotPage = new ForgotPasswordPage(driver);
        forgotPage.navigateTo();
        forgotPage.requestResetLink(email);

        Assert.assertTrue(forgotPage.isSuccessDisplayed(), "Success message should be displayed for password reset request");
        Assert.assertTrue(forgotPage.getSuccessText().contains("link has been sent"), "Success text should confirm link was sent");
    }

    @Test
    public void testForgotPassword_UnregisteredEmail() {
        ForgotPasswordPage forgotPage = new ForgotPasswordPage(driver);
        forgotPage.navigateTo();
        forgotPage.requestResetLink("notregistered_" + System.currentTimeMillis() + "@cognizant.com");

        Assert.assertTrue(forgotPage.isErrorDisplayed(), "Error message should be displayed for unregistered email");
        Assert.assertTrue(forgotPage.getErrorText().contains("No account found with that email"), "Error text mismatch");
    }
}
