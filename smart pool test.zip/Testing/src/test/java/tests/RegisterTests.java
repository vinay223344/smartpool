package tests;

import org.example.pages.LoginPage;
import org.example.pages.RegisterPage;
import org.testng.Assert;
import org.testng.annotations.Test;

public class RegisterTests extends BaseTest {

    @Test
    public void testRegisterValidation_NonWhitelistedDomain() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String uniqueEmail = "testuser_" + System.currentTimeMillis() + "@invaliddomain.com";
        registerPage.register("Automation User", uniqueEmail, "Secure123", "9876543210", "MALE", "QA", "Coimbatore");

        Assert.assertTrue(registerPage.isErrorDisplayed(), "Error alert should be displayed for non-whitelisted domain");
        Assert.assertTrue(registerPage.getErrorText().contains("not whitelisted"), "Error text should contain 'not whitelisted'");
    }

    @Test
    public void testRegisterValidation_ShortPassword() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String uniqueEmail = "testuser_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Automation User", uniqueEmail, "123", "9876543210", "MALE", "QA", "Coimbatore");

        // The HTML5 minlength="6" validation should prevent form submission.
        Assert.assertFalse(registerPage.isSuccessDisplayed(), "Success alert should not be displayed");
    }

    @Test
    public void testRegisterValidation_MissingRequiredFields() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        registerPage.register("", "", "", "", "", "", "");

        Assert.assertFalse(registerPage.isSuccessDisplayed(), "Success alert should not be displayed when inputs are missing");
    }

    @Test
    public void testRegisterSuccess_WhitelistedDomain() {
        RegisterPage registerPage = new RegisterPage(driver);
        registerPage.navigateTo();
        String uniqueEmail = "autom_" + System.currentTimeMillis() + "@cognizant.com";
        registerPage.register("Automation Success", uniqueEmail, "Password123", "9876543210", "MALE", "QA", "Coimbatore");

        Assert.assertTrue(registerPage.isSuccessDisplayed(), "Success message should be displayed");
        Assert.assertTrue(registerPage.getSuccessText().contains("Account created"), "Success text should confirm account creation");
    }
}
