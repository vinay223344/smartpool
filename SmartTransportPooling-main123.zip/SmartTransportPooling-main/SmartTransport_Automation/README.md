# SmartTransport Pooling — Selenium Automation Framework

Complete end-to-end test automation suite using **Selenium 4 + TestNG + Page Object Model + PageFactory + Data Driven Testing**.

---

## Project Structure

```
SmartTransport_Automation/
├── pom.xml                          ← Maven dependencies
├── testng.xml                       ← TestNG suite (13 test groups)
├── README.md                        ← This file
│
├── src/main/java/com/smarttransport/
│   ├── pages/                       ← 15 Page Object classes
│   │   ├── BasePage.java            ← Parent class (PageFactory + 25 helpers)
│   │   ├── LoginPage.java
│   │   ├── RegisterPage.java
│   │   ├── DashboardPage.java
│   │   ├── CreateTripPage.java      ← Map + GPS + Leaflet + autocomplete
│   │   ├── SearchTripsPage.java
│   │   ├── TripDetailPage.java
│   │   ├── MyTripsPage.java
│   │   ├── TripBookingsPage.java
│   │   ├── MyBookingsPage.java
│   │   ├── NotificationsPage.java
│   │   ├── MyVehiclesPage.java
│   │   ├── ForgotPasswordPage.java
│   │   ├── AdminDashboardPage.java
│   │   ├── AdminOrganizationsPage.java
│   │   └── AdminVehiclesPage.java
│   │
│   └── utils/
│       ├── ConfigReader.java        ← Singleton config.properties reader
│       ├── DriverFactory.java       ← ThreadLocal WebDriver (Chrome/Firefox/Edge)
│       ├── WaitUtils.java           ← All explicit waits (no Thread.sleep)
│       ├── ExcelUtils.java          ← Apache POI Excel data reader
│       └── ScreenshotUtils.java     ← Auto-screenshot on failure
│
├── src/main/resources/
│   ├── config.properties            ← URLs, browser, timeouts, credentials
│   └── log4j2.xml                   ← Logging configuration
│
└── src/test/java/com/smarttransport/
    ├── base/
    │   └── BaseTest.java            ← @BeforeSuite/@BeforeMethod/@AfterMethod
    │
    └── tests/
        ├── LoginTest.java           ← 7 tests + data driven
        ├── RegistrationTest.java    ← 8 tests + data driven
        ├── TripManagementTest.java  ← 8 tests + data driven
        ├── BookingTest.java         ← 8 tests + data driven
        ├── SearchTripsTest.java     ← 6 tests + data driven
        ├── NotificationTest.java    ← 5 tests
        ├── AdminTest.java           ← 8 tests
        ├── CrossRoleDashboardTest.java    ← 5 multi-role tests
        ├── CrossRoleNotificationTest.java ← 7 multi-role tests
        ├── E2EBookingFlowTest.java        ← 9 end-to-end scenarios
        ├── E2EEdgeCaseTest.java           ← 9 edge case scenarios
        └── UXTest.java                    ← 11 UI/UX tests
```

---

## Prerequisites

| Requirement | Version |
|---|---|
| Java | 17+ |
| Maven | 3.8+ |
| Chrome Browser | Latest |
| SmartTransport Backend | Running on port 8081 |
| SmartTransport Frontend | Running on port 4200 |
| MySQL | Running with smart_transport DB |

---

## Setup — Step by Step

### 1. Start the application

```bash
# Terminal 1 — Start Backend
cd SmartTransport
mvn spring-boot:run

# Terminal 2 — Start Frontend
cd SmartTransport_Frontend
ng serve
```

### 2. Create test users in database

Run these SQL inserts to create the 4 test users:

```sql
-- admin@test.com (ADMIN role)
INSERT INTO users (name, email, password, role, organization_domain, enabled, email_verified)
VALUES ('Admin User', 'admin@test.com',
        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/S',
        'ADMIN', 'test.com', true, true);

-- john@test.com (USER role — default user)
INSERT INTO users (name, email, password, role, organization_domain, city, enabled, email_verified)
VALUES ('John Doe', 'john@test.com',
        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/S',
        'USER', 'test.com', 'Chennai', true, true);

-- driver@test.com (DRIVER role — Ram)
INSERT INTO users (name, email, password, role, organization_domain, city, gender, enabled, email_verified)
VALUES ('Ram Driver', 'driver@test.com',
        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/S',
        'DRIVER', 'test.com', 'Chennai', 'MALE', true, true);

-- passenger@test.com (PASSENGER role — Satya)
INSERT INTO users (name, email, password, role, organization_domain, city, gender, enabled, email_verified)
VALUES ('Satya Passenger', 'passenger@test.com',
        '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/S',
        'PASSENGER', 'test.com', 'Chennai', 'MALE', true, true);

-- Whitelist test.com domain
INSERT INTO organizations (name, email_domain, whitelisted)
VALUES ('Test Organization', 'test.com', true);
```

> **Password for ALL users:** `pass123`
> (BCrypt hash: `$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lh/S`)

### 3. Create Excel test data file

Create `src/test/resources/testdata/TestData.xlsx` with 5 sheets.
See `TestData_README.md` in the same folder for exact structure.

### 4. Run the tests

```bash
cd SmartTransport_Automation

# Run ALL tests
mvn test

# Run only SMOKE tests
mvn test -Dgroups=smoke

# Run only E2E tests
mvn test -Dgroups=e2e

# Run specific test class
mvn test -Dtest=LoginTest

# Run specific test method
mvn test -Dtest=E2EBookingFlowTest#testRamCreatesTripSatyaBooksAndRamApproves
```

---

## Configuration (config.properties)

| Property | Default | Description |
|---|---|---|
| `base.url` | http://localhost:4200 | Angular frontend URL |
| `browser` | chrome | Browser: chrome, firefox, edge |
| `implicit.wait` | 10 | Seconds for implicit waits |
| `explicit.wait` | 15 | Seconds for WebDriverWait |
| `headless` | false | Set true for CI/CD |
| `screenshot.on.failure` | true | Auto-capture on test failure |
| `admin.email` | admin@test.com | Admin test user |
| `default.user.email` | john@test.com | Default test user |
| `default.driver.email` | driver@test.com | Driver test user (Ram) |
| `default.passenger.email` | passenger@test.com | Passenger test user (Satya) |

---

## Test Suites Summary

| Suite | Tests | Description |
|---|---|---|
| Smoke Tests | 5 | Core happy path tests |
| Authentication | 15 | Login, register, JWT, guards |
| Trip Management | 8 | Create, update, cancel, start, complete |
| Search Trips | 6 | All search filters + autocomplete |
| Booking | 8 | Book, approve, reject, cancel |
| Notifications | 5 | Bell badge, mark read, polling |
| Admin | 8 | Dashboard, orgs, vehicles |
| Cross-Role Dashboard | 5 | Same URL different content per role |
| Cross-Role Notifications | 7 | Action by Role A → verify by Role B |
| E2E Critical Scenarios | 9 | Full Ram↔Satya booking flows |
| E2E Edge Cases | 9 | Boundary conditions, isolation, security |
| UI/UX | 11 | Responsive, toasts, empty states, map |
| Data Driven | 5 | Excel-powered parametric tests |

---

## Key Design Patterns Used

### 1. Page Object Model (POM) with PageFactory
```java
public class LoginPage extends BasePage {
    @FindBy(css = "input[type='email']")
    private WebElement emailInput;      // PageFactory lazy proxy

    public LoginPage(WebDriver driver) {
        super(driver);                  // PageFactory.initElements() in BasePage
    }

    public DashboardPage loginAs(String email, String password) {
        typeText(emailInput, email);
        typeText(passwordInput, password);
        click(loginButton);
        WaitUtils.waitForUrlContains("/dashboard");
        return new DashboardPage(driver);
    }
}
```

### 2. Fluent API (method chaining)
```java
// Clean test code — reads like English
getSearchTripsPage()
    .enterOrigin("Chennai")
    .enterDestination("Bangalore")
    .setMinPrice(100)
    .selectGender("FEMALE")
    .clickSearch();
```

### 3. Explicit Waits Only (no Thread.sleep)
```java
// WaitUtils handles all waits
WaitUtils.waitForVisible(element);
WaitUtils.waitForClickable(button);
WaitUtils.waitForUrlContains("/dashboard");
WaitUtils.waitForSpinnerToDisappear();
```

### 4. ThreadLocal WebDriver (parallel-safe)
```java
// Each thread has its own isolated driver
private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();
```

### 5. Data-Driven with @DataProvider + Excel
```java
@DataProvider(name = "loginData")
public Object[][] getLoginData() {
    return ExcelUtils.readSheet(ConfigReader.getExcelDataPath(), "LoginData");
}

@Test(dataProvider = "loginData")
public void testLogin(String email, String password, String expected) {
    // runs once per row in Excel
}
```

### 6. Cross-Role Sequential Testing (Role Switching)
```java
// Login as Ram → do action → logout → login as Satya → verify result
loginAsDriver();
/* Ram's actions */
driver.get(baseUrl + "/login");

loginAsPassenger();
/* Satya verifies notification received */
```

### 7. Extent Reports (Auto HTML Report)
- Report generated at: `test-output/reports/SmartTransport_AutoReport.html`
- Screenshots embedded in report on test failure
- Dark theme with test steps logged

---

## Critical E2E Scenarios Covered

| Scenario | Flow |
|---|---|
| E2E-01 | Ram creates → Satya books (PENDING) → Ram approves (APPROVED) → Satya cancels → Seats restored |
| E2E-02 | Ram creates Chennai→Bangalore with stop Salem,Vellore → Satya searches Salem→Vellore → FOUND |
| E2E-03 | Ram rejects Satya's booking → Satya gets rejection notification → Satya tries re-book (DEF-001) |
| E2E-04 | Ram creates AUTO trip → Satya books → INSTANTLY APPROVED (no Ram action needed) |
| E2E-05 | SCHEDULED → ACTIVE (Satya notified) → COMPLETED (Satya notified) |
| E2E-06 | 1-seat trip: Satya books → APPROVED → Priya tries → BLOCKED (0 seats left) |
| E2E-07 | Satya has APPROVED booking → Ram cancels trip → Satya's booking auto-CANCELLED |
| E2E-08 | Satya searches stop-as-origin (Salem→Bangalore) → finds Ram's Chennai→Bangalore trip |
| E2E-09 | Ram searches his own route → his own trip NOT in results (excludeDriverId works) |
| E2E-10 | Past-departure trips NOT in search results |
| E2E-12 | Gender filter: female search shows only female driver trips |
| E2E-13 | My Bookings is isolated: Satya and Default User see only their own bookings |
| E2E-16 | Admin whitelists domain → User registers → Success. Domain blocked → User rejected |
| E2E-18 | Stop-as-origin + endpoint-as-dest search (Hosur→Bangalore finds Chennai→Bangalore trip) |

---

## Reports Location

After running tests:

```
test-output/
├── reports/SmartTransport_AutoReport.html   ← Open in browser
├── screenshots/                              ← Failure screenshots
└── logs/automation.log                       ← Full execution log
```

---

## Troubleshooting

| Problem | Solution |
|---|---|
| ChromeDriver version mismatch | WebDriverManager auto-downloads correct version |
| Element not found | Check @FindBy CSS selector — app may have changed |
| Login fails | Verify test users exist in DB with correct password hash |
| Map not loading | Ensure internet connection for OpenStreetMap tiles |
| Locations not set | Photon/Nominatim API needed — or click map manually |
| Tests skip due to no data | Run in order: create trip data first, then booking tests |

---

## Running in Headless Mode (CI/CD)

```properties
# In config.properties
headless=true
browser=chrome
```

```bash
mvn test -Dheadless=true
```
