package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * DashboardPage — Page Object for http://localhost:4200/dashboard
 */
public class DashboardPage extends BasePage {

    private static final Logger log = LogManager.getLogger(DashboardPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/dashboard";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    // Stat cards
    @FindBy(css = ".scard:nth-child(1) .scard-num")
    private WebElement myTripsCount;

    @FindBy(css = ".scard:nth-child(2) .scard-num")
    private WebElement myBookingsCount;

    @FindBy(css = ".scard:nth-child(3) .scard-num")
    private WebElement pendingCount;

    @FindBy(css = ".scard:nth-child(4) .scard-num")
    private WebElement activeCount;

    // Welcome message
    @FindBy(css = ".dash-header h2, h2[class*='welcome'], h2")
    private WebElement welcomeMessage;

    // Quick action pills
    @FindBy(css = "a[href*='search-trips'], a[routerLink*='search-trips']")
    private WebElement searchRidesBtn;

    @FindBy(css = "a[href*='create-trip'], a[routerLink*='create-trip']")
    private WebElement createTripBtn;

    @FindBy(css = "a[href*='my-bookings'], a[routerLink*='my-bookings']")
    private WebElement bookingsBtn;

    @FindBy(css = "a[href*='my-trips'], a[routerLink*='my-trips']")
    private WebElement myTripsBtn;

    // Refresh button
    @FindBy(css = ".refresh-btn, button[title*='refresh'], button.btn-refresh")
    private WebElement refreshButton;

    // Active/Upcoming trips panel rows
    @FindBy(css = ".trip-row")
    private List<WebElement> tripRows;

    // Recent bookings panel rows
    @FindBy(css = ".booking-row")
    private List<WebElement> bookingRows;

    // Notification bell badge
    @FindBy(css = ".notif-badge")
    private WebElement notifBadge;

    // Navbar logout
    @FindBy(css = "button[title*='Logout'], button[title*='logout']")
    private WebElement logoutButton;

    // Sidebar navigation items
    @FindBy(css = ".sb-link[routerLink='/search-trips']")
    private WebElement sidebarSearchRides;

    @FindBy(css = ".sb-link[routerLink='/my-bookings']")
    private WebElement sidebarMyBookings;

    @FindBy(css = ".sb-link[routerLink='/create-trip']")
    private WebElement sidebarCreateTrip;

    @FindBy(css = ".sb-link[routerLink='/my-trips']")
    private WebElement sidebarMyTrips;

    @FindBy(css = ".sb-link[routerLink='/my-vehicles']")
    private WebElement sidebarMyVehicles;

    // Admin sidebar items
    @FindBy(css = ".sb-link[routerLink='/admin/dashboard']")
    private WebElement sidebarAdminDashboard;

    @FindBy(css = ".sb-link[routerLink='/admin/organizations']")
    private WebElement sidebarAdminOrganizations;

    @FindBy(css = ".sb-link[routerLink='/admin/vehicles']")
    private WebElement sidebarAdminVehicles;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public DashboardPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public DashboardPage open() {
        log.info("Opening Dashboard page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/dashboard");
        waitForVisible(welcomeMessage);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Stat Cards
    // ──────────────────────────────────────────────

    public int getMyTripsCount() {
        waitForVisible(myTripsCount);
        return Integer.parseInt(getText(myTripsCount));
    }

    public int getMyBookingsCount() {
        return Integer.parseInt(getText(myBookingsCount));
    }

    public int getPendingCount() {
        return Integer.parseInt(getText(pendingCount));
    }

    public int getActiveCount() {
        return Integer.parseInt(getText(activeCount));
    }

    // ──────────────────────────────────────────────
    //  Welcome message
    // ──────────────────────────────────────────────

    public String getWelcomeText() {
        waitForVisible(welcomeMessage);
        return getText(welcomeMessage);
    }

    public boolean isDashboardLoaded() {
        return isDisplayed(welcomeMessage);
    }

    // ──────────────────────────────────────────────
    //  Notification Badge
    // ──────────────────────────────────────────────

    public boolean isNotifBadgeVisible() {
        return isDisplayed(notifBadge);
    }

    public int getNotifBadgeCount() {
        if (!isDisplayed(notifBadge)) return 0;
        try {
            return Integer.parseInt(getText(notifBadge));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ──────────────────────────────────────────────
    //  Quick Actions
    // ──────────────────────────────────────────────

    public SearchTripsPage clickSearchRides() {
        click(searchRidesBtn);
        WaitUtils.waitForUrlContains("/search-trips");
        return new SearchTripsPage(driver);
    }

    public CreateTripPage clickCreateTrip() {
        click(createTripBtn);
        WaitUtils.waitForUrlContains("/create-trip");
        return new CreateTripPage(driver);
    }

    public void clickRefresh() {
        click(refreshButton);
        waitForSpinner();
    }

    // ──────────────────────────────────────────────
    //  Sidebar Checks
    // ──────────────────────────────────────────────

    public boolean isSidebarSearchRidesVisible()     { return isDisplayed(sidebarSearchRides); }
    public boolean isSidebarMyBookingsVisible()       { return isDisplayed(sidebarMyBookings); }
    public boolean isSidebarCreateTripVisible()       { return isDisplayed(sidebarCreateTrip); }
    public boolean isSidebarMyTripsVisible()          { return isDisplayed(sidebarMyTrips); }
    public boolean isSidebarMyVehiclesVisible()       { return isDisplayed(sidebarMyVehicles); }
    public boolean isSidebarAdminDashboardVisible()   { return isDisplayed(sidebarAdminDashboard); }
    public boolean isSidebarAdminOrgsVisible()        { return isDisplayed(sidebarAdminOrganizations); }
    public boolean isSidebarAdminVehiclesVisible()    { return isDisplayed(sidebarAdminVehicles); }

    // ──────────────────────────────────────────────
    //  Panels
    // ──────────────────────────────────────────────

    public int getActiveTripsRowCount() {
        return tripRows.size();
    }

    public int getRecentBookingsRowCount() {
        return bookingRows.size();
    }

    // ──────────────────────────────────────────────
    //  Logout
    // ──────────────────────────────────────────────

    public LoginPage logout() {
        log.info("Logging out...");
        click(logoutButton);
        WaitUtils.waitForUrlContains("/login");
        return new LoginPage(driver);
    }
}
