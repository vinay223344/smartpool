package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.io.File;

/**
 * ProfilePage — Page Object for http://localhost:4200/profile
 * Covers: view/edit profile fields, upload picture, save.
 */
public class ProfilePage extends BasePage {

    private static final Logger log = LogManager.getLogger(ProfilePage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/profile";

    // ── Profile form fields ──
    @FindBy(css = "input[name='name'], input[id='name'], "
               + "input[placeholder*='Name'], input[placeholder*='name']")
    private WebElement nameInput;

    @FindBy(css = "input[name='phone'], input[placeholder*='Phone']")
    private WebElement phoneInput;

    @FindBy(css = "select[name='gender'], select[id='gender']")
    private WebElement genderSelect;

    @FindBy(css = "input[name='department'], input[placeholder*='Department']")
    private WebElement departmentInput;

    @FindBy(css = "input[name='city'], input[placeholder*='City']")
    private WebElement cityInput;

    // ── Email (read-only usually) ──
    @FindBy(css = "input[name='email'], input[type='email']")
    private WebElement emailField;

    // ── Save / Update button ──
    @FindBy(css = "button[type='submit'], button[class*='save'], "
               + "button[class*='update']")
    private WebElement saveButton;

    // ── Profile picture ──
    @FindBy(css = "img[class*='profile'], img[class*='avatar'], "
               + ".profile-pic img, [class*='profile-picture'] img")
    private WebElement profilePicImage;

    @FindBy(css = "input[type='file']")
    private WebElement fileInput;

    @FindBy(css = "button[class*='upload'], button[class*='picture'], "
               + "label[class*='upload']")
    private WebElement uploadButton;

    // ── Success / Error messages ──
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successMessage;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement errorMessage;

    // ── Role display (read-only) ──
    @FindBy(css = "[class*='role'], .role-badge, .badge[class*='role']")
    private WebElement roleBadge;

    // ── Organization domain (read-only) ──
    @FindBy(css = "[class*='org'], [class*='domain'], .org-domain")
    private WebElement orgDomain;

    public ProfilePage(WebDriver driver) { super(driver); }

    // ── Navigation ──

    public ProfilePage open() {
        log.info("Opening Profile page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/profile");
        WaitUtils.waitForVisible(saveButton, 5);
        return this;
    }

    // ── Read Actions ──

    public String getNameValue()       { return getValue(nameInput); }
    public String getPhoneValue()      { return getValue(phoneInput); }
    public String getDepartmentValue() { return getValue(departmentInput); }
    public String getCityValue()       { return getValue(cityInput); }
    public String getEmailValue()      { return getValue(emailField); }

    public String getSelectedGender() {
        return new org.openqa.selenium.support.ui.Select(genderSelect)
                .getFirstSelectedOption().getText();
    }

    // ── Edit Actions ──

    public ProfilePage clearAndSetName(String name) {
        clearAndType(nameInput, name);
        return this;
    }

    public ProfilePage clearAndSetPhone(String phone) {
        clearAndType(phoneInput, phone);
        return this;
    }

    public ProfilePage selectGender(String gender) {
        selectByVisibleText(genderSelect, gender);
        return this;
    }

    public ProfilePage clearAndSetDepartment(String dept) {
        clearAndType(departmentInput, dept);
        return this;
    }

    public ProfilePage clearAndSetCity(String city) {
        clearAndType(cityInput, city);
        return this;
    }

    /** Clicks Save and waits for response */
    public ProfilePage clickSave() {
        log.info("Saving profile...");
        click(saveButton);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /**
     * Updates profile fields and saves — returns self for chaining.
     */
    public ProfilePage updateProfile(String name, String phone, String city) {
        if (name != null)  clearAndSetName(name);
        if (phone != null) clearAndSetPhone(phone);
        if (city != null)  clearAndSetCity(city);
        clickSave();
        return this;
    }

    // ── Profile Picture ──

    /**
     * Uploads a profile picture using the hidden file input.
     * @param absoluteFilePath absolute path to the image file
     */
    public ProfilePage uploadProfilePicture(String absoluteFilePath) {
        log.info("Uploading profile picture: {}", absoluteFilePath);
        // Make file input visible if hidden
        try {
            org.openqa.selenium.JavascriptExecutor js =
                    (org.openqa.selenium.JavascriptExecutor) driver;
            js.executeScript("arguments[0].style.display='block';", fileInput);
        } catch (Exception ignored) {}
        fileInput.sendKeys(absoluteFilePath);
        WaitUtils.pause(500);
        // If there is a separate upload button, click it
        if (isDisplayed(uploadButton)) {
            click(uploadButton);
        }
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    public boolean isProfilePicDisplayed() { return isDisplayed(profilePicImage); }

    public String getProfilePicSrc() {
        if (!isDisplayed(profilePicImage)) return "";
        return profilePicImage.getAttribute("src");
    }

    // ── Verification ──

    public boolean isSuccessMessageDisplayed() { return isDisplayed(successMessage); }
    public boolean isErrorMessageDisplayed()   { return isDisplayed(errorMessage); }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successMessage, 5);
        return getText(successMessage);
    }

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorMessage, 5);
        return getText(errorMessage);
    }

    public boolean isPageLoaded() {
        return isDisplayed(saveButton);
    }

    public String getRoleBadgeText() {
        return isDisplayed(roleBadge) ? getText(roleBadge) : "";
    }
}
