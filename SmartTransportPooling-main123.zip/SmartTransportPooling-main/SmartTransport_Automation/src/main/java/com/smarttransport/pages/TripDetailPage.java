package com.smarttransport.pages;

import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * TripDetailPage — Page Object for http://localhost:4200/trip/{id}
 */
public class TripDetailPage extends BasePage {

    private static final Logger log = LogManager.getLogger(TripDetailPage.class);

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    // Trip info
    @FindBy(css = "[class*='origin'], .trip-origin, h3")
    private WebElement originText;

    @FindBy(css = "[class*='destination'], .trip-destination")
    private WebElement destinationText;

    @FindBy(css = "[class*='departure'], .departure-time")
    private WebElement departureTimeText;

    @FindBy(css = "[class*='seats'], .available-seats")
    private WebElement availableSeatsText;

    @FindBy(css = "[class*='price'], .price-per-seat")
    private WebElement priceText;

    @FindBy(css = ".badge-status, [class*='status']")
    private WebElement statusBadge;

    // Driver info
    @FindBy(css = "[class*='driver-name'], .driver-name")
    private WebElement driverName;

    // Booking form
    @FindBy(css = "input[type='number'][name*='seat'], input[placeholder*='seat']")
    private WebElement seatsInput;

    @FindBy(css = "select[name='bookingType'], select[name*='type']")
    private WebElement bookingTypeSelect;

    @FindBy(css = "button[class*='book'], button:contains('Book Now'), button:contains('Request Booking')")
    private WebElement bookNowButton;

    // Booking result / confirmation
    @FindBy(css = ".alert-success, [class*='success'], [class*='booking-success']")
    private WebElement bookingSuccessMessage;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement bookingErrorMessage;

    // Fare preview
    @FindBy(css = "[class*='fare'], .fare-preview, strong[class*='fare']")
    private WebElement farePreview;

    // Trip stops
    @FindBy(css = "[class*='stop'], .stop-item")
    private List<WebElement> tripStops;

    // Sibling recurring trips
    @FindBy(css = "[class*='sibling'], .sibling-trip")
    private List<WebElement> siblingTrips;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public TripDetailPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Booking Actions
    // ──────────────────────────────────────────────

    public TripDetailPage setSeats(int seats) {
        log.debug("Setting seats to: {}", seats);
        clearAndType(seatsInput, String.valueOf(seats));
        return this;
    }

    public TripDetailPage selectBookingType(String type) {
        // type = "SINGLE" or "RECURRING"
        selectByVisibleText(bookingTypeSelect, type);
        return this;
    }

    public TripDetailPage clickBookNow() {
        log.info("Clicking Book Now...");
        scrollAndClick(bookNowButton);
        waitForSpinner();
        WaitUtils.pause(600);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Read Trip Info
    // ──────────────────────────────────────────────

    public String getOrigin()         { return getText(originText); }
    public String getDestination()    { return getText(destinationText); }
    public String getDepartureTime()  { return getText(departureTimeText); }
    public String getStatus()         { return getText(statusBadge); }
    public String getDriverName()     { return getText(driverName); }
    public String getFarePreview()    { return isDisplayed(farePreview) ? getText(farePreview) : ""; }

    public int getAvailableSeats() {
        String text = getText(availableSeatsText).replaceAll("[^0-9]", "");
        return text.isEmpty() ? 0 : Integer.parseInt(text);
    }

    // ──────────────────────────────────────────────
    //  Verification
    // ──────────────────────────────────────────────

    public boolean isBookingSuccessDisplayed() { return isDisplayed(bookingSuccessMessage); }
    public boolean isBookingErrorDisplayed()   { return isDisplayed(bookingErrorMessage); }
    public boolean isBookNowButtonDisplayed()  { return isDisplayed(bookNowButton); }

    public String getBookingSuccessText() {
        WaitUtils.waitForVisible(bookingSuccessMessage, 8);
        return getText(bookingSuccessMessage);
    }

    public String getBookingErrorText() {
        WaitUtils.waitForVisible(bookingErrorMessage, 8);
        return getText(bookingErrorMessage);
    }

    public int getStopsCount()     { return tripStops.size(); }
    public int getSiblingsCount()  { return siblingTrips.size(); }
}
