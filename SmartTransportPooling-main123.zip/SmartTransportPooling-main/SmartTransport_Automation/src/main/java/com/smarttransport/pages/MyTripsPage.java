package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

public class MyTripsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(MyTripsPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/my-trips";

    @FindBy(css = ".trip-row, .trip-card, [class*='trip-item']")
    private List<WebElement> tripRows;

    @FindBy(css = "select[name='status'], select[class*='filter']")
    private WebElement statusFilter;

    @FindBy(css = ".empty-state h5, [class*='empty'], .no-trips")
    private WebElement emptyState;

    @FindBy(css = ".alert, [class*='toast']")
    private WebElement toastMessage;

    public MyTripsPage(WebDriver driver) { super(driver); }

    public MyTripsPage open() {
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/my-trips");
        WaitUtils.pause(600);
        return this;
    }

    public int getTripCount() { return tripRows.size(); }

    public boolean isEmptyStateDisplayed() { return isDisplayed(emptyState); }

    public String getTripStatus(int index) {
        WebElement row = tripRows.get(index);
        // Try badge-status class first, fallback to any badge
        List<WebElement> badges = row.findElements(
                By.cssSelector(".badge-status, [class*='badge'], [class*='status']"));
        return badges.isEmpty() ? "" : badges.get(0).getText().trim();
    }

    /** Clicks Start Trip using XPath text match */
    public MyTripsPage clickStartTrip(int index) {
        log.info("Clicking Start Trip at index: {}", index);
        WebElement row = tripRows.get(index);
        WebElement btn = row.findElement(
                By.xpath(".//button[contains(@class,'start')"
                       + " or contains(normalize-space(.),'Start')]"));
        scrollAndClick(btn);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /** Clicks Complete Trip using XPath text match */
    public MyTripsPage clickCompleteTrip(int index) {
        log.info("Clicking Complete Trip at index: {}", index);
        WebElement row = tripRows.get(index);
        WebElement btn = row.findElement(
                By.xpath(".//button[contains(@class,'complete')"
                       + " or contains(normalize-space(.),'Complete')]"));
        scrollAndClick(btn);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /** Clicks Cancel Trip then confirms dialog or modal */
    public MyTripsPage clickCancelTrip(int index) {
        log.info("Clicking Cancel Trip at index: {}", index);
        WebElement row = tripRows.get(index);
        WebElement btn = row.findElement(
                By.xpath(".//button[contains(@class,'cancel')"
                       + " or contains(normalize-space(.),'Cancel')]"));
        scrollAndClick(btn);
        // Accept browser alert or modal confirm button
        try {
            WaitUtils.waitForAlert().accept();
        } catch (Exception e) {
            List<WebElement> confirmBtns = driver.findElements(
                    By.xpath(".//div[contains(@class,'modal')]"
                           + "//button[contains(@class,'btn-danger')]"
                           + " | .//button[contains(normalize-space(.),'Confirm')]"));
            if (!confirmBtns.isEmpty()) click(confirmBtns.get(0));
        }
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /** Navigates to trip-bookings page for this trip */
    public TripBookingsPage clickManageBookings(int index) {
        WebElement row = tripRows.get(index);
        WebElement link = row.findElement(
                By.xpath(".//a[contains(@href,'trip-bookings')"
                       + " or contains(@routerLink,'trip-bookings')]"
                       + " | .//button[contains(normalize-space(.),'Manage')"
                       + " or contains(normalize-space(.),'Bookings')]"));
        click(link);
        WaitUtils.waitForUrlContains("/trip-bookings/");
        return new TripBookingsPage(driver);
    }

    public boolean isStartTripButtonVisible(int index) {
        List<WebElement> btns = tripRows.get(index).findElements(
                By.xpath(".//button[contains(@class,'start')"
                       + " or contains(normalize-space(.),'Start')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    public boolean isCompleteTripButtonVisible(int index) {
        List<WebElement> btns = tripRows.get(index).findElements(
                By.xpath(".//button[contains(@class,'complete')"
                       + " or contains(normalize-space(.),'Complete')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    public String getToastMessage() {
        WaitUtils.waitForVisible(toastMessage, 5);
        return getText(toastMessage);
    }
}
