package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * MyBookingsPage — Fixed: button:contains() replaced with XPath.
 */
public class MyBookingsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(MyBookingsPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/my-bookings";

    @FindBy(css = ".booking-row, [class*='booking-item']")
    private List<WebElement> bookingRows;

    @FindBy(css = ".empty-state h5, [class*='empty']")
    private WebElement emptyState;

    @FindBy(css = ".alert, [class*='toast']")
    private WebElement toastMessage;

    // Status filter dropdown (client-side filtering)
    @FindBy(css = "select[name='status'], select[class*='filter']")
    private WebElement statusFilter;

    public MyBookingsPage(WebDriver driver) { super(driver); }

    public MyBookingsPage open() {
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/my-bookings");
        WaitUtils.pause(600);
        return this;
    }

    public int getBookingCount() { return bookingRows.size(); }

    public boolean isEmptyStateDisplayed() { return isDisplayed(emptyState); }

    /** Returns status badge text of booking at index */
    public String getBookingStatus(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> badges = row.findElements(
                By.cssSelector(".badge-status, [class*='badge'], [class*='status']"));
        return badges.isEmpty() ? "" : badges.get(0).getText().trim();
    }

    /** Returns fare text of booking at index */
    public String getBookingFare(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> fares = row.findElements(
                By.cssSelector("[class*='fare'], strong[style*='color']"));
        return fares.isEmpty() ? "" : fares.get(0).getText().trim();
    }

    /** Returns the route text (origin → destination) at index */
    public String getBookingRoute(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> routes = row.findElements(
                By.cssSelector("[class*='route'], .booking-route"));
        return routes.isEmpty() ? row.getText().split("\n")[0] : routes.get(0).getText().trim();
    }

    /** Returns booking type (SINGLE / RECURRING) */
    public String getBookingType(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> types = row.findElements(
                By.cssSelector("[class*='type'], [class*='booking-type']"));
        return types.isEmpty() ? "" : types.get(0).getText().trim();
    }

    /** Returns departure time text */
    public String getDepartureTime(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> times = row.findElements(
                By.cssSelector("[class*='departure'], [class*='time'], time"));
        return times.isEmpty() ? "" : times.get(0).getText().trim();
    }

    /** Clicks Cancel and confirms — XPath text match */
    public MyBookingsPage cancelBooking(int index) {
        log.info("Cancelling booking at index: {}", index);
        WebElement row = bookingRows.get(index);
        WebElement cancelBtn = row.findElement(
                By.xpath(".//button[contains(@class,'cancel')"
                       + " or contains(normalize-space(.),'Cancel')]"));
        click(cancelBtn);
        // Accept alert or confirm modal
        try {
            WaitUtils.waitForAlert().accept();
        } catch (Exception e) {
            List<WebElement> confirmBtns = driver.findElements(
                    By.xpath(".//button[contains(@class,'btn-danger')"
                           + " or contains(normalize-space(.),'Confirm')]"));
            if (!confirmBtns.isEmpty()) click(confirmBtns.get(0));
        }
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /** True if Cancel button visible at index */
    public boolean isCancelButtonVisible(int index) {
        List<WebElement> btns = bookingRows.get(index).findElements(
                By.xpath(".//button[contains(@class,'cancel')"
                       + " or contains(normalize-space(.),'Cancel')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    /** Filter by status using client-side dropdown (if available) */
    public MyBookingsPage filterByStatus(String status) {
        if (isDisplayed(statusFilter)) {
            selectByVisibleText(statusFilter, status);
            WaitUtils.pause(300);
        }
        return this;
    }

    /** Count bookings with a specific status */
    public long countByStatus(String status) {
        return bookingRows.stream()
                .filter(r -> {
                    List<WebElement> badges = r.findElements(
                            By.cssSelector(".badge-status, [class*='badge']"));
                    return !badges.isEmpty()
                            && badges.get(0).getText().trim()
                               .equalsIgnoreCase(status);
                })
                .count();
    }

    public String getToastMessage() {
        WaitUtils.waitForVisible(toastMessage, 5);
        return getText(toastMessage);
    }
}
