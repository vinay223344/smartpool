package com.smarttransport.listeners;

import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.smarttransport.base.BaseTest;
import com.smarttransport.utils.ScreenshotUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.testng.*;

/**
 * TestListener — ITestListener + ISuiteListener implementation.
 *
 * Hooks into every test lifecycle event:
 *  onTestStart       → log test name to console
 *  onTestSuccess     → mark PASS in Extent
 *  onTestFailure     → screenshot + mark FAIL in Extent
 *  onTestSkipped     → mark SKIP in Extent
 *  onStart (suite)   → log suite start
 *  onFinish (suite)  → flush Extent report
 *
 * Registered in testng.xml <listeners> block.
 */
public class TestListener implements ITestListener, ISuiteListener {

    private static final Logger log = LogManager.getLogger(TestListener.class);

    // ── Helper: get current thread's ExtentTest safely ──
    private ExtentTest getTest() {
        return BaseTest.extentTest.get();
    }

    // ════════════════════════════════════════════
    //  ITestListener hooks
    // ════════════════════════════════════════════

    @Override
    public void onTestStart(ITestResult result) {
        log.info("▶ STARTING: [{}] {}",
                result.getTestClass().getRealClass().getSimpleName(),
                result.getName());

        ExtentTest test = getTest();
        if (test != null) {
            test.assignCategory(result.getMethod().getGroups());
            test.assignAuthor("QA Team");
            test.log(Status.INFO, "Test started: " + result.getName());
        }
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        log.info("✅ PASSED : {}", result.getName());
        ExtentTest test = getTest();
        if (test != null) {
            test.pass("✅ Test PASSED in "
                    + (result.getEndMillis() - result.getStartMillis()) + " ms");
        }
    }

    @Override
    public void onTestFailure(ITestResult result) {
        log.error("❌ FAILED : {} — {}", result.getName(),
                result.getThrowable() != null
                        ? result.getThrowable().getMessage() : "unknown");

        ExtentTest test = getTest();
        if (test != null) {
            // Capture screenshot and embed in report
            String b64 = ScreenshotUtils.captureBase64();
            String msg  = "❌ Test FAILED: "
                    + (result.getThrowable() != null
                        ? result.getThrowable().getMessage() : "unknown error");

            if (b64 != null && !b64.isEmpty()) {
                test.fail(msg).addScreenCaptureFromBase64String(
                        b64, "Failure Screenshot");
            } else {
                test.fail(msg);
            }

            // Log full stack trace
            if (result.getThrowable() != null) {
                test.fail(result.getThrowable());
            }
        }
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        log.warn("⏭ SKIPPED: {} — {}",
                result.getName(),
                result.getSkipCausedBy() != null
                        ? result.getSkipCausedBy().toString() : "dependency failed");

        ExtentTest test = getTest();
        if (test != null) {
            test.skip("⏭ Test SKIPPED: "
                    + (result.getThrowable() != null
                        ? result.getThrowable().getMessage() : "dependency"));
        }
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        log.warn("⚠ FAILED (within success %): {}", result.getName());
    }

    @Override
    public void onStart(ITestContext context) {
        log.info("═══════════════════════════════════");
        log.info("TEST CONTEXT STARTING: {}", context.getName());
        log.info("═══════════════════════════════════");
    }

    @Override
    public void onFinish(ITestContext context) {
        log.info("═══════════════════════════════════════════");
        log.info("TEST CONTEXT FINISHED: {} | Pass:{} Fail:{} Skip:{}",
                context.getName(),
                context.getPassedTests().size(),
                context.getFailedTests().size(),
                context.getSkippedTests().size());
        log.info("═══════════════════════════════════════════");
    }

    // ════════════════════════════════════════════
    //  ISuiteListener hooks
    // ════════════════════════════════════════════

    @Override
    public void onStart(ISuite suite) {
        log.info("╔══════════════════════════════════════════╗");
        log.info("║  SUITE STARTING: {}  ║", suite.getName());
        log.info("╚══════════════════════════════════════════╝");
    }

    @Override
    public void onFinish(ISuite suite) {
        log.info("╔══════════════════════════════════════════╗");
        log.info("║  SUITE FINISHED: {}  ║", suite.getName());
        log.info("╚══════════════════════════════════════════╝");

        // Flush Extent report safely here as a backup
        if (BaseTest.extent != null) {
            BaseTest.extent.flush();
            log.info("Extent Report flushed by TestListener");
        }
    }
}
