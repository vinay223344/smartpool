package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * LandingPage — Page Object for http://localhost:4200/
 * Covers: hero section, features section, Sign In CTA, Register CTA.
 */
public class LandingPage extends BasePage {

    private static final Logger log = LogManager.getLogger(LandingPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/";

    // ── Hero section ──
    @FindBy(css = "h1, .hero h1, [class*='hero'] h1")
    private WebElement heroHeading;

    @FindBy(css = "[class*='hero'] p, .hero-subtitle, .lead")
    private WebElement heroSubtitle;

    // ── CTA Buttons ──
    @FindBy(css = "a[routerLink='/login'], a[href*='login'], "
               + "button[routerLink='/login']")
    private WebElement signInButton;

    @FindBy(css = "a[routerLink='/register'], a[href*='register'], "
               + "button[routerLink='/register']")
    private WebElement registerButton;

    // ── Features section ──
    @FindBy(css = ".feature-card, [class*='feature-item'], [class*='feature']")
    private List<WebElement> featureCards;

    // ── How it works section ──
    @FindBy(css = "[class*='how-it-works'], [class*='steps'], .step-item")
    private List<WebElement> howItWorksSteps;

    // ── Navbar ──
    @FindBy(css = "nav a[routerLink='/login'], nav a[href*='login']")
    private WebElement navSignIn;

    @FindBy(css = "nav a[routerLink='/register'], nav a[href*='register']")
    private WebElement navRegister;

    // Brand / logo
    @FindBy(css = ".brand, [class*='brand'], nav .brand")
    private WebElement brandLogo;

    public LandingPage(WebDriver driver) { super(driver); }

    // ── Navigation ──

    public LandingPage open() {
        log.info("Opening Landing page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.pause(500);
        return this;
    }

    // ── Actions ──

    public LoginPage clickSignIn() {
        log.info("Clicking Sign In on landing page");
        click(signInButton);
        WaitUtils.waitForUrlContains("/login");
        return new LoginPage(driver);
    }

    public RegisterPage clickRegister() {
        log.info("Clicking Register on landing page");
        click(registerButton);
        WaitUtils.waitForUrlContains("/register");
        return new RegisterPage(driver);
    }

    public LoginPage clickNavSignIn() {
        click(navSignIn);
        WaitUtils.waitForUrlContains("/login");
        return new LoginPage(driver);
    }

    public RegisterPage clickNavRegister() {
        click(navRegister);
        WaitUtils.waitForUrlContains("/register");
        return new RegisterPage(driver);
    }

    // ── Verification ──

    public boolean isHeroHeadingDisplayed() { return isDisplayed(heroHeading); }

    public String getHeroHeadingText() {
        WaitUtils.waitForVisible(heroHeading);
        return getText(heroHeading);
    }

    public boolean isSignInButtonDisplayed() { return isDisplayed(signInButton); }

    public boolean isRegisterButtonDisplayed() { return isDisplayed(registerButton); }

    public int getFeatureCardsCount() { return featureCards.size(); }

    public int getHowItWorksStepsCount() { return howItWorksSteps.size(); }

    public boolean isBrandLogoDisplayed() { return isDisplayed(brandLogo); }

    public boolean isPageLoaded() {
        return isDisplayed(heroHeading) || isDisplayed(signInButton);
    }
}
