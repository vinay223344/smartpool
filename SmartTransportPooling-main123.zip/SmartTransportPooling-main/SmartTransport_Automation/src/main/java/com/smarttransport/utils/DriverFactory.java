package com.smarttransport.utils;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.edge.EdgeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.firefox.FirefoxOptions;

import java.time.Duration;

/**
 * DriverFactory — Creates and manages WebDriver instances.
 *
 * Uses ThreadLocal to support parallel test execution safely.
 * Each thread gets its own independent WebDriver instance.
 */
public class DriverFactory {

    private static final Logger log = LogManager.getLogger(DriverFactory.class);

    // ThreadLocal ensures each test thread has its own driver
    private static final ThreadLocal<WebDriver> driverThreadLocal = new ThreadLocal<>();

    // Private constructor — utility class
    private DriverFactory() {}

    /**
     * Initializes the WebDriver based on browser name from config.
     * Must be called before any test interacts with the browser.
     */
    public static void initDriver() {
        String browser = ConfigReader.getBrowser().toLowerCase();
        boolean headless = ConfigReader.isHeadless();

        log.info("Initializing browser: {} | headless: {}", browser, headless);

        WebDriver driver;

        switch (browser) {
            case "chrome" -> {
                WebDriverManager.chromedriver().setup();
                ChromeOptions options = new ChromeOptions();
                if (headless) options.addArguments("--headless=new");
                options.addArguments("--start-maximized");
                options.addArguments("--disable-notifications");
                options.addArguments("--disable-popup-blocking");
                options.addArguments("--disable-extensions");
                options.addArguments("--remote-allow-origins=*");
                // Disable password manager prompts
                options.addArguments("--disable-save-password-bubble");
                driver = new ChromeDriver(options);
            }
            case "firefox" -> {
                WebDriverManager.firefoxdriver().setup();
                FirefoxOptions options = new FirefoxOptions();
                if (headless) options.addArguments("--headless");
                driver = new FirefoxDriver(options);
                driver.manage().window().maximize();
            }
            case "edge" -> {
                WebDriverManager.edgedriver().setup();
                EdgeOptions options = new EdgeOptions();
                if (headless) options.addArguments("--headless=new");
                options.addArguments("--start-maximized");
                driver = new EdgeDriver(options);
            }
            default -> throw new RuntimeException("Unsupported browser: " + browser
                    + ". Valid options: chrome, firefox, edge");
        }

        // ── Configure timeouts ──
        driver.manage().timeouts().implicitlyWait(
                Duration.ofSeconds(ConfigReader.getImplicitWait()));
        driver.manage().timeouts().pageLoadTimeout(
                Duration.ofSeconds(ConfigReader.getPageLoadTimeout()));
        driver.manage().timeouts().scriptTimeout(
                Duration.ofSeconds(30));

        // Store driver in ThreadLocal
        driverThreadLocal.set(driver);
        log.info("WebDriver initialized successfully for thread: {}", Thread.currentThread().getId());
    }

    /**
     * Returns the WebDriver for the current thread.
     * Throws exception if driver is not initialized.
     */
    public static WebDriver getDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver == null) {
            throw new RuntimeException("WebDriver is not initialized. Call DriverFactory.initDriver() first.");
        }
        return driver;
    }

    /**
     * Quits the WebDriver and removes it from ThreadLocal.
     * Must be called after each test to free resources.
     */
    public static void quitDriver() {
        WebDriver driver = driverThreadLocal.get();
        if (driver != null) {
            try {
                driver.quit();
                log.info("WebDriver closed for thread: {}", Thread.currentThread().getId());
            } catch (Exception e) {
                log.warn("Error while closing driver: {}", e.getMessage());
            } finally {
                driverThreadLocal.remove();
            }
        }
    }

    /**
     * Checks if driver is active for the current thread.
     */
    public static boolean isDriverActive() {
        return driverThreadLocal.get() != null;
    }
}
