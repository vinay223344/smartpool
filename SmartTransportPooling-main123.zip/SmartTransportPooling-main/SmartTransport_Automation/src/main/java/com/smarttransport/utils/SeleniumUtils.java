package com.smarttransport.utils;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import java.util.List;

/**
 * SeleniumUtils — Static helpers for locating elements
 * that CSS :contains() cannot handle (invalid in Selenium).
 *
 * All methods use XPath with normalize-space() for reliability.
 */
public class SeleniumUtils {

    private SeleniumUtils() {}

    /** Find button by exact or partial visible text. */
    public static By buttonByText(String text) {
        return By.xpath(".//button[contains(normalize-space(.),'" + text + "')]");
    }

    /** Find button by text inside a given parent element. */
    public static WebElement buttonByText(WebElement parent, String text) {
        return parent.findElement(
                By.xpath(".//button[contains(normalize-space(.),'" + text + "')]"));
    }

    /** Find button by text safely — null if not found. */
    public static WebElement buttonByTextSafe(WebElement parent, String text) {
        List<WebElement> found = parent.findElements(
                By.xpath(".//button[contains(normalize-space(.),'" + text + "')]"));
        return found.isEmpty() ? null : found.get(0);
    }

    /** Find any element (button or link) by partial text. */
    public static By clickableByText(String text) {
        return By.xpath(".//*[self::button or self::a]"
                + "[contains(normalize-space(.),'" + text + "')]");
    }

    /** Find a link by partial text. */
    public static By linkByText(String text) {
        return By.xpath(".//a[contains(normalize-space(.),'" + text + "')]");
    }

    /** Check if a list of elements contains one with the given text. */
    public static boolean anyElementContainsText(List<WebElement> elements, String text) {
        return elements.stream()
                .anyMatch(e -> e.getText().toLowerCase().contains(text.toLowerCase()));
    }
}
