package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * AdminVehiclesPage — Fixed: button:contains() replaced with XPath.
 */
public class AdminVehiclesPage extends BasePage {

    private static final Logger log = LogManager.getLogger(AdminVehiclesPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/admin/vehicles";

    @FindBy(css = "tbody tr, .vehicle-row, [class*='vehicle-item']")
    private List<WebElement> vehicleRows;

    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successAlert;

    @FindBy(css = ".empty-state, [class*='empty']")
    private WebElement emptyState;

    // Vehicle details columns inside each row
    // col 0=licensePlate, 1=model, 2=owner, 3=status, 4=action

    public AdminVehiclesPage(WebDriver driver) { super(driver); }

    public AdminVehiclesPage open() {
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/admin/vehicles");
        WaitUtils.pause(500);
        return this;
    }

    public int getPendingVehicleCount() { return vehicleRows.size(); }

    public boolean isEmptyStateDisplayed() { return isDisplayed(emptyState); }

    public String getLicensePlate(int index) {
        List<WebElement> cells = vehicleRows.get(index)
                .findElements(By.cssSelector("td"));
        return cells.isEmpty() ? "" : cells.get(0).getText().trim();
    }

    public String getVehicleModel(int index) {
        List<WebElement> cells = vehicleRows.get(index)
                .findElements(By.cssSelector("td"));
        return cells.size() > 1 ? cells.get(1).getText().trim() : "";
    }

    public String getOwnerName(int index) {
        List<WebElement> cells = vehicleRows.get(index)
                .findElements(By.cssSelector("td"));
        return cells.size() > 2 ? cells.get(2).getText().trim() : "";
    }

    /** Approves vehicle at given index — XPath text match */
    public AdminVehiclesPage approveVehicle(int index) {
        log.info("Approving vehicle at index: {}", index);
        WebElement row = vehicleRows.get(index);
        WebElement approveBtn = row.findElement(
                By.xpath(".//button[contains(normalize-space(.),'Approve')"
                       + " or contains(@class,'approve')]"));
        click(approveBtn);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    public boolean isApproveButtonVisible(int index) {
        List<WebElement> btns = vehicleRows.get(index).findElements(
                By.xpath(".//button[contains(normalize-space(.),'Approve')"
                       + " or contains(@class,'approve')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    public boolean isSuccessDisplayed() { return isDisplayed(successAlert); }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successAlert, 5);
        return getText(successAlert);
    }
}
