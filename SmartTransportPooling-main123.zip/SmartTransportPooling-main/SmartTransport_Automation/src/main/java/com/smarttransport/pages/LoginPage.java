package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * LoginPage — Page Object for http://localhost:4200/login
 *
 * PageFactory @FindBy annotations locate elements lazily.
 * All interactions go through BasePage helper methods.
 */
public class LoginPage extends BasePage {

    private static final Logger log = LogManager.getLogger(LoginPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/login";

    // ──────────────────────────────────────────────
    //  @FindBy Element Declarations (PageFactory)
    // ──────────────────────────────────────────────

    @FindBy(css = "input[type='email'], input[name='email'], input[id='email']")
    private WebElement emailInput;

    @FindBy(css = "input[type='password'], input[name='password']")
    private WebElement passwordInput;

    @FindBy(css = "button[type='submit']")
    private WebElement loginButton;

    // Error/alert message shown on failed login
    @FindBy(css = ".alert, .alert-danger, [class*='error'], .text-danger")
    private WebElement errorMessage;

    // Loading spinner on the button
    @FindBy(css = ".spinner-border")
    private WebElement spinner;

    // Link to register page
    @FindBy(css = "a[href*='register'], [routerLink*='register']")
    private WebElement registerLink;

    // Forgot password link
    @FindBy(css = "a[href*='forgot'], [routerLink*='forgot']")
    private WebElement forgotPasswordLink;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public LoginPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    /**
     * Opens the login page directly.
     */
    public LoginPage open() {
        log.info("Opening Login page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/login");
        return this;
    }

    // ──────────────────────────────────────────────
    //  Actions
    // ──────────────────────────────────────────────

    /**
     * Enters email into the email input field.
     */
    public LoginPage enterEmail(String email) {
        log.debug("Entering email: {}", email);
        typeText(emailInput, email);
        return this;
    }

    /**
     * Enters password into the password input field.
     */
    public LoginPage enterPassword(String password) {
        log.debug("Entering password: [hidden]");
        typeText(passwordInput, password);
        return this;
    }

    /**
     * Clicks the Login button and waits for spinner to finish.
     */
    public LoginPage clickLoginButton() {
        log.info("Clicking Login button...");
        click(loginButton);
        waitForSpinner();
        return this;
    }

    /**
     * Full login action — enters credentials and clicks login.
     * Returns DashboardPage if login is successful.
     */
    public DashboardPage loginAs(String email, String password) {
        log.info("Attempting login as: {}", email);
        enterEmail(email);
        enterPassword(password);
        clickLoginButton();
        // Wait for redirect to dashboard
        WaitUtils.waitForUrlContains("/dashboard");
        log.info("Login successful — redirected to dashboard");
        return new DashboardPage(driver);
    }

    /**
     * Attempts login and stays on the login page (for negative tests).
     */
    public LoginPage loginExpectingFailure(String email, String password) {
        log.info("Attempting login expecting failure as: {}", email);
        enterEmail(email);
        enterPassword(password);
        clickLoginButton();
        // Stay on login page — wait for error message
        WaitUtils.waitForVisible(errorMessage);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Verification Methods
    // ──────────────────────────────────────────────

    /**
     * Returns the error message text shown on failed login.
     */
    public String getErrorMessage() {
        return getText(errorMessage);
    }

    /**
     * Returns true if error message is displayed.
     */
    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    /**
     * Returns true if the login button is present (page loaded).
     */
    public boolean isLoginPageLoaded() {
        return isDisplayed(loginButton);
    }

    /**
     * Returns true if the spinner is visible (loading in progress).
     */
    public boolean isSpinnerVisible() {
        return isDisplayed(spinner);
    }

    // ──────────────────────────────────────────────
    //  Navigation Links
    // ──────────────────────────────────────────────

    /**
     * Clicks Forgot Password link.
     */
    public ForgotPasswordPage clickForgotPassword() {
        click(forgotPasswordLink);
        WaitUtils.waitForUrlContains("/forgot-password");
        return new ForgotPasswordPage(driver);
    }

    /**
     * Clicks Register link.
     */
    public RegisterPage clickRegisterLink() {
        click(registerLink);
        WaitUtils.waitForUrlContains("/register");
        return new RegisterPage(driver);
    }
}
