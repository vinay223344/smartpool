package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * MyVehiclesPage — Page Object for http://localhost:4200/my-vehicles
 */
public class MyVehiclesPage extends BasePage {

    private static final Logger log = LogManager.getLogger(MyVehiclesPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/my-vehicles";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    // Vehicle list rows
    @FindBy(css = ".vehicle-card, .vehicle-item, [class*='vehicle-row']")
    private List<WebElement> vehicleRows;

    // Register vehicle button
    @FindBy(css = "button[class*='register'], button:contains('Register Vehicle'), button:contains('Add Vehicle')")
    private WebElement registerVehicleButton;

    // Registration form fields (shown in modal or inline)
    @FindBy(css = "input[name='licensePlate'], input[placeholder*='License']")
    private WebElement licensePlateInput;

    @FindBy(css = "input[name='model'], input[placeholder*='Model']")
    private WebElement modelInput;

    @FindBy(css = "input[name='color'], input[placeholder*='Color']")
    private WebElement colorInput;

    @FindBy(css = "input[name='totalSeats'], input[placeholder*='Seats'], input[type='number'][name*='seat']")
    private WebElement totalSeatsInput;

    @FindBy(css = "input[name='licenseDocUrl'], input[placeholder*='Doc']")
    private WebElement licenseDocInput;

    // Form submit button
    @FindBy(css = "button[type='submit'], button:contains('Save'), button:contains('Register')")
    private WebElement saveButton;

    // Success/Error alerts
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successAlert;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement errorAlert;

    // Empty state
    @FindBy(css = ".empty-state h5, [class*='empty']")
    private WebElement emptyState;

    // License plate field validation error
    @FindBy(css = "input[name='licensePlate'] ~ .invalid-feedback")
    private WebElement licensePlateError;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public MyVehiclesPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public MyVehiclesPage open() {
        log.info("Opening My Vehicles page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/my-vehicles");
        WaitUtils.pause(500);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Register Vehicle
    // ──────────────────────────────────────────────

    /**
     * Clicks the Register Vehicle button to open the form.
     */
    public MyVehiclesPage clickRegisterVehicle() {
        log.info("Clicking Register Vehicle button...");
        click(registerVehicleButton);
        WaitUtils.waitForVisible(licensePlateInput, 5);
        return this;
    }

    public MyVehiclesPage enterLicensePlate(String plate) {
        typeText(licensePlateInput, plate);
        return this;
    }

    public MyVehiclesPage enterModel(String model) {
        typeText(modelInput, model);
        return this;
    }

    public MyVehiclesPage enterColor(String color) {
        typeText(colorInput, color);
        return this;
    }

    public MyVehiclesPage enterTotalSeats(int seats) {
        clearAndType(totalSeatsInput, String.valueOf(seats));
        return this;
    }

    public MyVehiclesPage enterLicenseDocUrl(String url) {
        if (isDisplayed(licenseDocInput)) {
            typeText(licenseDocInput, url);
        }
        return this;
    }

    /**
     * Clicks Save/Register after filling the form.
     */
    public MyVehiclesPage clickSave() {
        log.info("Clicking Save vehicle...");
        click(saveButton);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /**
     * Full vehicle registration in one method.
     */
    public MyVehiclesPage registerVehicle(String plate, String model,
                                          String color, int seats) {
        clickRegisterVehicle();
        enterLicensePlate(plate);
        enterModel(model);
        enterColor(color);
        enterTotalSeats(seats);
        clickSave();
        return this;
    }

    // ──────────────────────────────────────────────
    //  Vehicle List
    // ──────────────────────────────────────────────

    public int getVehicleCount() {
        return vehicleRows.size();
    }

    public boolean isEmptyStateDisplayed() {
        return isDisplayed(emptyState);
    }

    /**
     * Returns the status text (e.g., "Pending Approval") of vehicle at index.
     */
    public String getVehicleStatus(int index) {
        WebElement row = vehicleRows.get(index);
        List<WebElement> badges = row.findElements(
                By.cssSelector(".badge, [class*='status'], [class*='approval']"));
        return badges.isEmpty() ? "" : badges.get(0).getText().trim();
    }

    // ──────────────────────────────────────────────
    //  Verification
    // ──────────────────────────────────────────────

    public boolean isSuccessAlertDisplayed() { return isDisplayed(successAlert); }
    public boolean isErrorAlertDisplayed()   { return isDisplayed(errorAlert); }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successAlert, 5);
        return getText(successAlert);
    }

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorAlert, 5);
        return getText(errorAlert);
    }

    public String getLicensePlateError() {
        return isDisplayed(licensePlateError) ? getText(licensePlateError) : "";
    }
}
