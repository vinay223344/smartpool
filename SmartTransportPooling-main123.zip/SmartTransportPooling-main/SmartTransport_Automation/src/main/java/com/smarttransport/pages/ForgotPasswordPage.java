package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * ForgotPasswordPage — Page Object for /forgot-password
 */
public class ForgotPasswordPage extends BasePage {

    private static final Logger log = LogManager.getLogger(ForgotPasswordPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/forgot-password";

    @FindBy(css = "input[type='email'], input[name='email']")
    private WebElement emailInput;

    @FindBy(css = "button[type='submit']")
    private WebElement sendResetButton;

    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successMessage;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement errorMessage;

    public ForgotPasswordPage(WebDriver driver) {
        super(driver);
    }

    public ForgotPasswordPage open() {
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/forgot-password");
        return this;
    }

    public ForgotPasswordPage enterEmail(String email) {
        typeText(emailInput, email);
        return this;
    }

    public ForgotPasswordPage clickSendResetLink() {
        log.info("Clicking Send Reset Link...");
        click(sendResetButton);
        waitForSpinner();
        return this;
    }

    public ForgotPasswordPage requestPasswordReset(String email) {
        enterEmail(email);
        clickSendResetLink();
        return this;
    }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successMessage);
        return getText(successMessage);
    }

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorMessage);
        return getText(errorMessage);
    }

    public boolean isSuccessMessageDisplayed() { return isDisplayed(successMessage); }
    public boolean isErrorMessageDisplayed()   { return isDisplayed(errorMessage); }
}
