package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * AdminOrganizationsPage — Fixed: all button:contains() replaced with XPath.
 */
public class AdminOrganizationsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(AdminOrganizationsPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/admin/organizations";

    // ── Add button — use XPath to find by text ──
    // @FindBy cannot use :contains(), so we locate dynamically in methods

    // Form fields (in modal or inline)
    @FindBy(css = "input[name='name'], input[placeholder*='Organization Name'], "
               + "input[placeholder*='organization']")
    private WebElement orgNameInput;

    @FindBy(css = "input[name='emailDomain'], input[placeholder*='domain'], "
               + "input[placeholder*='Domain']")
    private WebElement domainInput;

    @FindBy(css = "input[type='checkbox'][name*='whitelisted'], "
               + "input[type='checkbox']")
    private WebElement whitelistedCheckbox;

    // Form submit
    @FindBy(css = "button[type='submit']")
    private WebElement saveButton;

    // Table rows
    @FindBy(css = "tbody tr, .org-row, [class*='org-item']")
    private List<WebElement> orgRows;

    // Alerts
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successAlert;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement errorAlert;

    // Empty state
    @FindBy(css = ".empty-state, [class*='empty']")
    private WebElement emptyState;

    public AdminOrganizationsPage(WebDriver driver) { super(driver); }

    public AdminOrganizationsPage open() {
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/admin/organizations");
        WaitUtils.pause(500);
        return this;
    }

    // ── Open the Add/Create form ──

    public AdminOrganizationsPage clickAddOrganization() {
        log.info("Clicking Add Organization button...");
        // Find any button with Add/Create text using XPath
        WebElement addBtn = driver.findElement(
                By.xpath(".//button[contains(normalize-space(.),'Add')"
                       + " or contains(normalize-space(.),'Create')"
                       + " or contains(normalize-space(.),'New')]"));
        click(addBtn);
        WaitUtils.waitForVisible(orgNameInput, 5);
        return this;
    }

    public AdminOrganizationsPage enterOrgName(String name) {
        typeText(orgNameInput, name);
        return this;
    }

    public AdminOrganizationsPage enterDomain(String domain) {
        typeText(domainInput, domain);
        return this;
    }

    public AdminOrganizationsPage setWhitelisted(boolean value) {
        boolean current = isSelected(whitelistedCheckbox);
        if (current != value) click(whitelistedCheckbox);
        return this;
    }

    public AdminOrganizationsPage clickSave() {
        log.info("Saving organization...");
        click(saveButton);
        waitForSpinner();
        WaitUtils.pause(400);
        return this;
    }

    public AdminOrganizationsPage createOrganization(String name, String domain, boolean whitelisted) {
        clickAddOrganization();
        enterOrgName(name);
        enterDomain(domain);
        setWhitelisted(whitelisted);
        clickSave();
        return this;
    }

    // ── Table actions ──

    public int getOrgCount() { return orgRows.size(); }

    public boolean isEmptyStateDisplayed() { return isDisplayed(emptyState); }

    public String getOrgName(int index) {
        List<WebElement> cells = orgRows.get(index).findElements(By.cssSelector("td"));
        return cells.isEmpty() ? "" : cells.get(0).getText().trim();
    }

    public String getOrgDomain(int index) {
        List<WebElement> cells = orgRows.get(index).findElements(By.cssSelector("td"));
        return cells.size() > 1 ? cells.get(1).getText().trim() : "";
    }

    public String getOrgWhitelistStatus(int index) {
        List<WebElement> cells = orgRows.get(index).findElements(By.cssSelector("td"));
        return cells.size() > 2 ? cells.get(2).getText().trim() : "";
    }

    /** Clicks Edit on org row at index — XPath text match */
    public AdminOrganizationsPage clickEditOrg(int index) {
        WebElement row = orgRows.get(index);
        WebElement editBtn = row.findElement(
                By.xpath(".//button[contains(normalize-space(.),'Edit')"
                       + " or contains(@class,'edit')]"));
        click(editBtn);
        WaitUtils.waitForVisible(orgNameInput, 5);
        return this;
    }

    /** Clicks Delete on org row at index — XPath text match */
    public AdminOrganizationsPage deleteOrg(int index) {
        log.info("Deleting org at index: {}", index);
        WebElement row = orgRows.get(index);
        WebElement deleteBtn = row.findElement(
                By.xpath(".//button[contains(normalize-space(.),'Delete')"
                       + " or contains(@class,'delete')]"));
        click(deleteBtn);
        try { WaitUtils.waitForAlert().accept(); } catch (Exception ignored) {}
        waitForSpinner();
        WaitUtils.pause(400);
        return this;
    }

    // ── Verification ──

    public boolean isSuccessDisplayed() { return isDisplayed(successAlert); }
    public boolean isErrorDisplayed()   { return isDisplayed(errorAlert); }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successAlert, 5);
        return getText(successAlert);
    }

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorAlert, 5);
        return getText(errorAlert);
    }
}
