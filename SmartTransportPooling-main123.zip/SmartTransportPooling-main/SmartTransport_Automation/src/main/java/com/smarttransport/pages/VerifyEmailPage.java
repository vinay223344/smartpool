package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * VerifyEmailPage — Page Object for /verify-email?token=...
 */
public class VerifyEmailPage extends BasePage {

    private static final Logger log = LogManager.getLogger(VerifyEmailPage.class);

    @FindBy(css = ".alert-success, [class*='success'], h3[class*='success']")
    private WebElement successMessage;

    @FindBy(css = ".alert-danger, [class*='error'], h3[class*='error']")
    private WebElement errorMessage;

    @FindBy(css = ".spinner-border, [class*='loading']")
    private WebElement spinner;

    @FindBy(css = "a[routerLink='/login'], a[href*='login'], button[class*='login']")
    private WebElement loginLink;

    public VerifyEmailPage(WebDriver driver) { super(driver); }

    public VerifyEmailPage openWithToken(String token) {
        String url = ConfigReader.getBaseUrl() + "/verify-email?token=" + token;
        log.info("Opening Verify Email page with token");
        navigateTo(url);
        WaitUtils.waitForUrlContains("/verify-email");
        WaitUtils.waitForSpinnerToDisappear();
        WaitUtils.pause(600);
        return this;
    }

    public boolean isSuccessDisplayed() { return isDisplayed(successMessage); }
    public boolean isErrorDisplayed()   { return isDisplayed(errorMessage); }

    public String getSuccessText() {
        WaitUtils.waitForVisible(successMessage, 8);
        return getText(successMessage);
    }

    public String getErrorText() {
        WaitUtils.waitForVisible(errorMessage, 8);
        return getText(errorMessage);
    }

    public LoginPage clickLoginLink() {
        click(loginLink);
        WaitUtils.waitForUrlContains("/login");
        return new LoginPage(driver);
    }

    public boolean isVerificationComplete() {
        return isSuccessDisplayed() || isErrorDisplayed();
    }
}
