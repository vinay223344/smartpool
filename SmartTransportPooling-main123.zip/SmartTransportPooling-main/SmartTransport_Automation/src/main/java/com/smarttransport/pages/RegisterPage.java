package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * RegisterPage — Page Object for http://localhost:4200/register
 */
public class RegisterPage extends BasePage {

    private static final Logger log = LogManager.getLogger(RegisterPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/register";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    @FindBy(css = "input[name='name'], input[id='name'], input[placeholder*='Name']")
    private WebElement nameInput;

    @FindBy(css = "input[type='email'], input[name='email']")
    private WebElement emailInput;

    @FindBy(css = "input[type='password'], input[name='password']")
    private WebElement passwordInput;

    @FindBy(css = "input[name='phone'], input[placeholder*='Phone']")
    private WebElement phoneInput;

    @FindBy(css = "select[name='gender'], select[id='gender']")
    private WebElement genderSelect;

    @FindBy(css = "input[name='department'], input[placeholder*='Department']")
    private WebElement departmentInput;

    @FindBy(css = "input[name='city'], input[placeholder*='City']")
    private WebElement cityInput;

    @FindBy(css = "select[name='role'], select[id='role']")
    private WebElement roleSelect;

    @FindBy(css = "button[type='submit']")
    private WebElement registerButton;

    // Error messages
    @FindBy(css = ".alert-danger, [class*='error'], .text-danger")
    private WebElement errorMessage;

    // Success message
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successMessage;

    // Field-level validation messages
    @FindBy(css = "input[name='name'] ~ .invalid-feedback, input[name='name'] + span")
    private WebElement nameError;

    @FindBy(css = "input[type='email'] ~ .invalid-feedback")
    private WebElement emailError;

    @FindBy(css = "input[type='password'] ~ .invalid-feedback")
    private WebElement passwordError;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public RegisterPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public RegisterPage open() {
        log.info("Opening Register page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/register");
        return this;
    }

    // ──────────────────────────────────────────────
    //  Actions
    // ──────────────────────────────────────────────

    public RegisterPage enterName(String name) {
        log.debug("Entering name: {}", name);
        typeText(nameInput, name);
        return this;
    }

    public RegisterPage enterEmail(String email) {
        log.debug("Entering email: {}", email);
        typeText(emailInput, email);
        return this;
    }

    public RegisterPage enterPassword(String password) {
        log.debug("Entering password...");
        typeText(passwordInput, password);
        return this;
    }

    public RegisterPage enterPhone(String phone) {
        typeText(phoneInput, phone);
        return this;
    }

    public RegisterPage selectGender(String gender) {
        log.debug("Selecting gender: {}", gender);
        selectByVisibleText(genderSelect, gender);
        return this;
    }

    public RegisterPage enterDepartment(String dept) {
        typeText(departmentInput, dept);
        return this;
    }

    public RegisterPage enterCity(String city) {
        typeText(cityInput, city);
        return this;
    }

    public RegisterPage selectRole(String role) {
        log.debug("Selecting role: {}", role);
        selectByVisibleText(roleSelect, role);
        return this;
    }

    /**
     * Submits the registration form.
     */
    public RegisterPage clickRegister() {
        log.info("Clicking Register button...");
        click(registerButton);
        waitForSpinner();
        return this;
    }

    // ──────────────────────────────────────────────
    //  Composite Actions
    // ──────────────────────────────────────────────

    /**
     * Registers a user with all fields provided.
     */
    public RegisterPage registerFullUser(String name, String email, String password,
                                         String phone, String gender, String dept,
                                         String city, String role) {
        log.info("Registering full user: {}", email);
        enterName(name);
        enterEmail(email);
        enterPassword(password);
        enterPhone(phone);
        selectGender(gender);
        enterDepartment(dept);
        enterCity(city);
        selectRole(role);
        clickRegister();
        return this;
    }

    /**
     * Registers with only mandatory fields.
     */
    public RegisterPage registerMinimal(String name, String email, String password) {
        log.info("Registering minimal user: {}", email);
        enterName(name);
        enterEmail(email);
        enterPassword(password);
        clickRegister();
        return this;
    }

    // ──────────────────────────────────────────────
    //  Verification Methods
    // ──────────────────────────────────────────────

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorMessage);
        return getText(errorMessage);
    }

    public boolean isErrorDisplayed() {
        return isDisplayed(errorMessage);
    }

    public boolean isSuccessDisplayed() {
        return isDisplayed(successMessage);
    }

    public String getNameValidationError() {
        return isDisplayed(nameError) ? getText(nameError) : "";
    }

    public String getEmailValidationError() {
        return isDisplayed(emailError) ? getText(emailError) : "";
    }

    public String getPasswordValidationError() {
        return isDisplayed(passwordError) ? getText(passwordError) : "";
    }

    public boolean isRegisterButtonEnabled() {
        return isEnabled(registerButton);
    }
}
