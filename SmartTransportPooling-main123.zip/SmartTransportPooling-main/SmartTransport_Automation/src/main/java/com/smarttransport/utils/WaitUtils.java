package com.smarttransport.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.List;

/**
 * WaitUtils — Centralizes all Explicit Wait operations.
 *
 * Rules followed:
 * - NEVER use Thread.sleep() in test code (except rare animation waits)
 * - Always use WebDriverWait with ExpectedConditions
 * - Custom wait methods for Angular SPA patterns
 */
public class WaitUtils {

    private static final Logger log = LogManager.getLogger(WaitUtils.class);

    // Default timeouts
    private static final int DEFAULT_TIMEOUT  = ConfigReader.getExplicitWait();
    private static final int SHORT_TIMEOUT    = 5;
    private static final int LONG_TIMEOUT     = 30;

    // Private constructor
    private WaitUtils() {}

    // ──────────────────────────────────────────────
    //  Core helper — creates WebDriverWait
    // ──────────────────────────────────────────────

    private static WebDriverWait getWait() {
        return new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(DEFAULT_TIMEOUT));
    }

    private static WebDriverWait getWait(int seconds) {
        return new WebDriverWait(DriverFactory.getDriver(), Duration.ofSeconds(seconds));
    }

    // ──────────────────────────────────────────────
    //  Visibility Waits
    // ──────────────────────────────────────────────

    /**
     * Waits until the element is visible on screen.
     */
    public static WebElement waitForVisible(WebElement element) {
        log.debug("Waiting for element to be visible...");
        return getWait().until(ExpectedConditions.visibilityOf(element));
    }

    public static WebElement waitForVisible(WebElement element, int seconds) {
        return getWait(seconds).until(ExpectedConditions.visibilityOf(element));
    }

    /**
     * Waits until the element located by the given By locator is visible.
     */
    public static WebElement waitForVisible(By locator) {
        return getWait().until(ExpectedConditions.visibilityOfElementLocated(locator));
    }

    // ──────────────────────────────────────────────
    //  Clickability Waits
    // ──────────────────────────────────────────────

    /**
     * Waits until element is visible AND enabled (ready to click).
     */
    public static WebElement waitForClickable(WebElement element) {
        log.debug("Waiting for element to be clickable...");
        return getWait().until(ExpectedConditions.elementToBeClickable(element));
    }

    public static WebElement waitForClickable(By locator) {
        return getWait().until(ExpectedConditions.elementToBeClickable(locator));
    }

    public static WebElement waitForClickable(WebElement element, int seconds) {
        return getWait(seconds).until(ExpectedConditions.elementToBeClickable(element));
    }

    // ──────────────────────────────────────────────
    //  Presence Waits
    // ──────────────────────────────────────────────

    /**
     * Waits for element to exist in DOM (may not be visible).
     */
    public static WebElement waitForPresence(By locator) {
        return getWait().until(ExpectedConditions.presenceOfElementLocated(locator));
    }

    /**
     * Waits for all elements matching locator to be present in DOM.
     */
    public static List<WebElement> waitForAllPresent(By locator) {
        return getWait().until(ExpectedConditions.presenceOfAllElementsLocatedBy(locator));
    }

    // ──────────────────────────────────────────────
    //  URL / Navigation Waits
    // ──────────────────────────────────────────────

    /**
     * Waits for the current URL to contain the given substring.
     * Use after clicking navigation links.
     */
    public static void waitForUrlContains(String urlFragment) {
        log.debug("Waiting for URL to contain: {}", urlFragment);
        getWait().until(ExpectedConditions.urlContains(urlFragment));
    }

    public static void waitForUrlContains(String urlFragment, int seconds) {
        getWait(seconds).until(ExpectedConditions.urlContains(urlFragment));
    }

    /**
     * Waits for URL to exactly match.
     */
    public static void waitForUrlToBe(String exactUrl) {
        getWait().until(ExpectedConditions.urlToBe(exactUrl));
    }

    // ──────────────────────────────────────────────
    //  Text Waits
    // ──────────────────────────────────────────────

    /**
     * Waits until element's text contains the expected string.
     */
    public static void waitForTextPresent(WebElement element, String text) {
        log.debug("Waiting for text '{}' in element...", text);
        getWait().until(ExpectedConditions.textToBePresentInElement(element, text));
    }

    /**
     * Waits until element's value attribute contains the expected string.
     */
    public static void waitForValuePresent(WebElement element, String value) {
        getWait().until(ExpectedConditions.textToBePresentInElementValue(element, value));
    }

    // ──────────────────────────────────────────────
    //  Disappearance / Staleness Waits
    // ──────────────────────────────────────────────

    /**
     * Waits until element is no longer visible (spinner hides, modal closes, etc.).
     */
    public static void waitForInvisible(WebElement element) {
        log.debug("Waiting for element to become invisible...");
        getWait().until(ExpectedConditions.invisibilityOf(element));
    }

    public static void waitForInvisible(By locator) {
        getWait().until(ExpectedConditions.invisibilityOfElementLocated(locator));
    }

    /**
     * Waits for element to become stale (after page refresh or DOM update).
     */
    public static void waitForStaleness(WebElement element) {
        getWait().until(ExpectedConditions.stalenessOf(element));
    }

    // ──────────────────────────────────────────────
    //  Angular SPA Specific Waits
    // ──────────────────────────────────────────────

    /**
     * Waits for Angular spinner/loader to disappear.
     * SmartTransport uses Bootstrap spinner with class "spinner-border".
     */
    public static void waitForSpinnerToDisappear() {
        log.debug("Waiting for loading spinner to disappear...");
        try {
            // First wait a short time for spinner to appear
            WebDriverWait shortWait = getWait(SHORT_TIMEOUT);
            shortWait.until(ExpectedConditions.presenceOfElementLocated(
                    By.cssSelector(".spinner-border")));
            // Then wait for it to disappear
            getWait(LONG_TIMEOUT).until(ExpectedConditions.invisibilityOfElementLocated(
                    By.cssSelector(".spinner-border")));
        } catch (TimeoutException e) {
            // Spinner may not have appeared at all — that is fine
            log.debug("Spinner not found — continuing without waiting for it");
        }
    }

    /**
     * Waits for an Angular toast notification to appear and returns its text.
     */
    public static String waitForToastMessage() {
        log.debug("Waiting for toast notification...");
        // SmartTransport renders toasts with specific class
        WebElement toast = getWait().until(
                ExpectedConditions.visibilityOfElementLocated(
                        By.cssSelector(".toast-message, .alert, [class*='toast']")));
        return toast.getText();
    }

    /**
     * Waits for the page to fully load using JavaScript document.readyState.
     */
    public static void waitForPageLoad() {
        log.debug("Waiting for page to fully load...");
        getWait().until((ExpectedCondition<Boolean>) driver -> {
            JavascriptExecutor js = (JavascriptExecutor) driver;
            return "complete".equals(js.executeScript("return document.readyState"));
        });
    }

    /**
     * Waits for Angular to finish all pending requests.
     * Uses a JS condition to check Angular's pending task queue.
     */
    public static void waitForAngular() {
        log.debug("Waiting for Angular...");
        try {
            JavascriptExecutor js = (JavascriptExecutor) DriverFactory.getDriver();
            getWait().until((ExpectedCondition<Boolean>) driver ->
                    (Boolean) js.executeScript(
                            "return (typeof angular === 'undefined') || " +
                            "(angular.element(document.body).injector() === undefined) || " +
                            "(angular.element(document.body).injector().get('$http').pendingRequests.length === 0)"
                    )
            );
        } catch (Exception e) {
            log.debug("Angular wait skipped (Angular 2+ detected): {}", e.getMessage());
        }
    }

    /**
     * Short pause for UI animations ONLY when truly necessary.
     * Use sparingly — prefer event-based waits.
     * @param millis milliseconds to wait (keep under 1000)
     */
    public static void pause(long millis) {
        log.debug("Pausing for {} ms (animation wait)", millis);
        try {
            Thread.sleep(millis);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    // ──────────────────────────────────────────────
    //  Alert Waits
    // ──────────────────────────────────────────────

    /**
     * Waits for a browser alert to be present and returns it.
     */
    public static Alert waitForAlert() {
        return getWait().until(ExpectedConditions.alertIsPresent());
    }

    // ──────────────────────────────────────────────
    //  Attribute Waits
    // ──────────────────────────────────────────────

    /**
     * Waits until element's attribute contains the expected value.
     * Useful for checking CSS class changes (e.g. button disabled state).
     */
    public static void waitForAttributeContains(WebElement element, String attribute, String value) {
        getWait().until(ExpectedConditions.attributeContains(element, attribute, value));
    }

    /**
     * Waits until element count matching the locator equals the expected count.
     */
    public static List<WebElement> waitForElementCount(By locator, int expectedCount) {
        return getWait().until(driver -> {
            List<WebElement> elements = driver.findElements(locator);
            return elements.size() >= expectedCount ? elements : null;
        });
    }
}
