package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * ResetPasswordPage — Page Object for /reset-password?token=...
 * Reached via the password reset email link.
 */
public class ResetPasswordPage extends BasePage {

    private static final Logger log = LogManager.getLogger(ResetPasswordPage.class);

    // ── Form fields ──
    @FindBy(css = "input[name='newPassword'], input[placeholder*='New Password'], "
               + "input[type='password']:first-of-type")
    private WebElement newPasswordInput;

    @FindBy(css = "input[name='confirmPassword'], input[placeholder*='Confirm'], "
               + "input[type='password']:last-of-type")
    private WebElement confirmPasswordInput;

    @FindBy(css = "button[type='submit']")
    private WebElement resetButton;

    // ── Messages ──
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successMessage;

    @FindBy(css = ".alert-danger, [class*='error']")
    private WebElement errorMessage;

    // ── Validation errors ──
    @FindBy(css = "input[name='newPassword'] ~ .invalid-feedback, "
               + "input[name='newPassword'] + span")
    private WebElement passwordError;

    public ResetPasswordPage(WebDriver driver) { super(driver); }

    // ── Navigation ──

    /**
     * Opens reset password page with the given token.
     */
    public ResetPasswordPage openWithToken(String token) {
        String url = ConfigReader.getBaseUrl() + "/reset-password?token=" + token;
        log.info("Opening Reset Password page with token");
        navigateTo(url);
        WaitUtils.waitForUrlContains("/reset-password");
        return this;
    }

    // ── Actions ──

    public ResetPasswordPage enterNewPassword(String password) {
        typeText(newPasswordInput, password);
        return this;
    }

    public ResetPasswordPage enterConfirmPassword(String password) {
        if (isDisplayed(confirmPasswordInput)) {
            typeText(confirmPasswordInput, password);
        }
        return this;
    }

    public ResetPasswordPage clickResetPassword() {
        log.info("Clicking Reset Password button...");
        click(resetButton);
        waitForSpinner();
        WaitUtils.pause(500);
        return this;
    }

    /**
     * Complete reset password flow in one call.
     */
    public ResetPasswordPage resetPassword(String newPassword) {
        enterNewPassword(newPassword);
        enterConfirmPassword(newPassword);
        clickResetPassword();
        return this;
    }

    // ── Verification ──

    public boolean isSuccessDisplayed() { return isDisplayed(successMessage); }
    public boolean isErrorDisplayed()   { return isDisplayed(errorMessage); }

    public String getSuccessText() {
        WaitUtils.waitForVisible(successMessage, 6);
        return getText(successMessage);
    }

    public String getErrorText() {
        WaitUtils.waitForVisible(errorMessage, 6);
        return getText(errorMessage);
    }

    public String getPasswordError() {
        return isDisplayed(passwordError) ? getText(passwordError) : "";
    }

    public boolean isPageLoaded() {
        return isDisplayed(newPasswordInput) || isDisplayed(resetButton);
    }
}
