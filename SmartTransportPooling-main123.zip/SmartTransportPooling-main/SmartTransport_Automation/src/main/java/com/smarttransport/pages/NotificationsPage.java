package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * NotificationsPage — Page Object for http://localhost:4200/notifications
 */
public class NotificationsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(NotificationsPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/notifications";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    // All notification rows
    @FindBy(css = ".notification-item, [class*='notif-item'], .list-group-item")
    private List<WebElement> notificationRows;

    // Unread notifications (have specific class/style)
    @FindBy(css = "[class*='unread'], .notification-item:not([class*='read'])")
    private List<WebElement> unreadRows;

    // Mark all as read button
    @FindBy(css = "button[class*='read-all'], button:contains('Mark All')")
    private WebElement markAllReadButton;

    // Empty state
    @FindBy(css = ".empty-state, [class*='empty'], .no-notifications")
    private WebElement emptyState;

    // Notification bell badge in navbar
    @FindBy(css = ".notif-badge")
    private WebElement navBadge;

    // Notification titles
    @FindBy(css = ".notification-title, [class*='notif-title'], strong")
    private List<WebElement> notifTitles;

    // Notification messages
    @FindBy(css = ".notification-message, [class*='notif-msg'], p")
    private List<WebElement> notifMessages;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public NotificationsPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public NotificationsPage open() {
        log.info("Opening Notifications page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/notifications");
        WaitUtils.pause(500);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Counts
    // ──────────────────────────────────────────────

    public int getTotalNotificationCount() {
        return notificationRows.size();
    }

    public int getUnreadCount() {
        return unreadRows.size();
    }

    /**
     * Returns the unread count shown on the navbar bell badge.
     */
    public int getNavBadgeCount() {
        if (!isDisplayed(navBadge)) return 0;
        try {
            return Integer.parseInt(getText(navBadge).trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    public boolean isNavBadgeVisible() {
        return isDisplayed(navBadge);
    }

    // ──────────────────────────────────────────────
    //  Read Actions
    // ──────────────────────────────────────────────

    /**
     * Clicks on a notification at the given index to mark it as read.
     */
    public NotificationsPage markAsRead(int index) {
        log.debug("Marking notification at index {} as read", index);
        if (index < notificationRows.size()) {
            // Look for a Mark as Read button inside the row
            WebElement row = notificationRows.get(index);
            List<WebElement> readBtns = row.findElements(
                    By.xpath(".//button[contains(@class,'read')"
                           + " or contains(normalize-space(.),'Read')]"));
            if (!readBtns.isEmpty()) {
                click(readBtns.get(0));
            } else {
                // Clicking the notification itself may mark it as read
                click(row);
            }
            WaitUtils.pause(400);
        }
        return this;
    }

    /**
     * Clicks Mark All as Read button.
     */
    public NotificationsPage markAllAsRead() {
        log.info("Clicking Mark All as Read...");
        WaitUtils.waitForClickable(markAllReadButton);
        click(markAllReadButton);
        WaitUtils.pause(500);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Content Verification
    // ──────────────────────────────────────────────

    /**
     * Returns the title text of notification at given index.
     */
    public String getNotificationTitle(int index) {
        if (index < notifTitles.size()) {
            return getText(notifTitles.get(index));
        }
        return "";
    }

    /**
     * Returns the message text of notification at given index.
     */
    public String getNotificationMessage(int index) {
        if (index < notifMessages.size()) {
            return getText(notifMessages.get(index));
        }
        return "";
    }

    /**
     * Returns true if any notification title contains the given keyword.
     */
    public boolean hasNotificationWithTitle(String keyword) {
        return notifTitles.stream()
                .anyMatch(t -> t.getText().toLowerCase().contains(keyword.toLowerCase()));
    }

    /**
     * Returns true if any notification message contains the given text.
     */
    public boolean hasNotificationWithMessage(String keyword) {
        return notifMessages.stream()
                .anyMatch(m -> m.getText().toLowerCase().contains(keyword.toLowerCase()));
    }

    public boolean isEmptyStateDisplayed() {
        return isDisplayed(emptyState);
    }

    public boolean isMarkAllReadButtonVisible() {
        return isDisplayed(markAllReadButton);
    }
}
