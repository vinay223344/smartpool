package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * CreateTripPage — Page Object for http://localhost:4200/create-trip
 *
 * Note: This page uses Leaflet.js map. Map interactions use JS executor.
 */
public class CreateTripPage extends BasePage {

    private static final Logger log = LogManager.getLogger(CreateTripPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/create-trip";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    // Location search inputs
    @FindBy(css = "input[placeholder*='pickup'], input[placeholder*='Pickup']")
    private WebElement pickupInput;

    @FindBy(css = "input[placeholder*='drop'], input[placeholder*='Drop-off']")
    private WebElement dropoffInput;

    // Suggestion dropdown items
    @FindBy(css = ".suggestion-item")
    private List<WebElement> locationSuggestions;

    // Vehicle selector
    @FindBy(css = "select[name='vehicleId']")
    private WebElement vehicleSelect;

    // Departure time
    @FindBy(css = "input[type='datetime-local'], input[name='departureTime']")
    private WebElement departureTimeInput;

    // Available seats
    @FindBy(css = "input[name='availableSeats'], input[type='number'][name*='seat']")
    private WebElement availableSeatsInput;

    // Price per seat
    @FindBy(css = "input[name='pricePerSeat'], input[placeholder*='price'], input[placeholder*='Price']")
    private WebElement pricePerSeatInput;

    // Approval mode
    @FindBy(css = "select[name='approvalMode']")
    private WebElement approvalModeSelect;

    // Recurring toggle/checkbox
    @FindBy(css = "input[name='recurring'], input[type='checkbox'][name*='recurring']")
    private WebElement recurringToggle;

    // Daily rate (visible when recurring)
    @FindBy(css = "input[name='dailyRate']")
    private WebElement dailyRateInput;

    // Add stop button
    @FindBy(css = "button[type='button'][class*='add'], button:contains('Add Stop')")
    private WebElement addStopButton;

    // Stop name inputs
    @FindBy(css = "input[name*='stop_']")
    private List<WebElement> stopInputs;

    // Submit button
    @FindBy(css = "button[type='submit']")
    private WebElement createTripButton;

    // Success/Error alerts
    @FindBy(css = ".alert-success, [class*='success']")
    private WebElement successAlert;

    @FindBy(css = ".alert-danger, [class*='error'], .alert")
    private WebElement errorAlert;

    // Map container
    @FindBy(css = ".create-trip-map, .leaflet-container")
    private WebElement mapContainer;

    // Reset markers button
    @FindBy(css = "button[class*='reset'], button:contains('Reset')")
    private WebElement resetMarkersButton;

    // Origin/destination coordinate indicators
    @FindBy(css = "small.text-success")
    private List<WebElement> coordinateConfirmations;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public CreateTripPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public CreateTripPage open() {
        log.info("Opening Create Trip page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/create-trip");
        // Wait for map to load
        WaitUtils.waitForVisible(mapContainer);
        WaitUtils.pause(1500); // allow Leaflet JS tiles to initialize
        return this;
    }

    // ──────────────────────────────────────────────
    //  Location Search (Autocomplete)
    // ──────────────────────────────────────────────

    /**
     * Types in the pickup field slowly to trigger autocomplete.
     * Waits for suggestions dropdown, then clicks first result.
     */
    public CreateTripPage setPickupLocation(String location) {
        log.info("Setting pickup location: {}", location);
        typeSlowly(pickupInput, location);
        // Wait for suggestion dropdown to appear
        WaitUtils.waitForVisible(By.cssSelector(".suggestion-item"), 8);
        // Click the first suggestion
        List<WebElement> suggestions = driver.findElements(By.cssSelector(".suggestion-item"));
        if (!suggestions.isEmpty()) {
            WaitUtils.waitForClickable(suggestions.get(0)).click();
            log.debug("Selected first pickup suggestion");
        }
        // Wait for coordinates to be confirmed
        WaitUtils.pause(500);
        return this;
    }

    /**
     * Types in the dropoff field and selects first suggestion.
     */
    public CreateTripPage setDropoffLocation(String location) {
        log.info("Setting dropoff location: {}", location);
        typeSlowly(dropoffInput, location);
        WaitUtils.waitForVisible(By.cssSelector(".suggestion-item"), 8);
        List<WebElement> suggestions = driver.findElements(By.cssSelector(".suggestion-item"));
        if (!suggestions.isEmpty()) {
            WaitUtils.waitForClickable(suggestions.get(0)).click();
        }
        WaitUtils.pause(500);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Map Interactions
    // ──────────────────────────────────────────────

    /**
     * Clicks on the map at approximate center to set origin marker.
     */
    public CreateTripPage clickMapForOrigin() {
        log.info("Clicking map to set origin marker...");
        WaitUtils.waitForVisible(mapContainer);
        // Click center-left area of the map for origin
        int x = mapContainer.getSize().getWidth()  / 3;
        int y = mapContainer.getSize().getHeight() / 2;
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].dispatchEvent(new MouseEvent('click', {bubbles: true, clientX: arguments[1], clientY: arguments[2]}))",
                mapContainer, x, y
        );
        WaitUtils.pause(800);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Trip Fields
    // ──────────────────────────────────────────────

    /**
     * Sets departure time using datetime-local input.
     * Format: "yyyy-MM-ddTHH:mm" (e.g. "2026-07-15T09:00")
     */
    public CreateTripPage setDepartureTime(String datetime) {
        log.debug("Setting departure time: {}", datetime);
        // Use JS to set value since Selenium sendKeys may not work for datetime-local
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].value = arguments[1];", departureTimeInput, datetime);
        // Trigger change event for Angular binding
        ((JavascriptExecutor) driver).executeScript(
                "arguments[0].dispatchEvent(new Event('input', {bubbles: true}));", departureTimeInput);
        return this;
    }

    public CreateTripPage setAvailableSeats(int seats) {
        clearAndType(availableSeatsInput, String.valueOf(seats));
        return this;
    }

    public CreateTripPage setPricePerSeat(double price) {
        clearAndType(pricePerSeatInput, String.valueOf(price));
        return this;
    }

    public CreateTripPage selectApprovalMode(String mode) {
        // mode = "Manual Review" or "Auto-Accept"
        selectByVisibleText(approvalModeSelect, mode);
        return this;
    }

    public CreateTripPage selectVehicle(String vehicleText) {
        // vehicleText is visible option text
        selectByVisibleText(vehicleSelect, vehicleText);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Recurring Trip
    // ──────────────────────────────────────────────

    public CreateTripPage enableRecurring() {
        if (!isSelected(recurringToggle)) {
            click(recurringToggle);
            WaitUtils.pause(400); // wait for daily rate field to appear
        }
        return this;
    }

    public CreateTripPage setDailyRate(double rate) {
        WaitUtils.waitForVisible(dailyRateInput);
        clearAndType(dailyRateInput, String.valueOf(rate));
        return this;
    }

    // ──────────────────────────────────────────────
    //  Intermediate Stops
    // ──────────────────────────────────────────────

    public CreateTripPage addStop(String stopName) {
        log.debug("Adding stop: {}", stopName);
        click(addStopButton);
        WaitUtils.pause(300);
        // Get the last stop input that was added
        List<WebElement> inputs = driver.findElements(By.cssSelector("input[name*='stop_']"));
        if (!inputs.isEmpty()) {
            WebElement lastInput = inputs.get(inputs.size() - 1);
            typeText(lastInput, stopName);
        }
        return this;
    }

    // ──────────────────────────────────────────────
    //  Submit
    // ──────────────────────────────────────────────

    public CreateTripPage clickCreateTrip() {
        log.info("Clicking Create Trip button...");
        scrollAndClick(createTripButton);
        waitForSpinner();
        return this;
    }

    // ──────────────────────────────────────────────
    //  Verification
    // ──────────────────────────────────────────────

    public boolean isSuccessAlertDisplayed() {
        return isDisplayed(successAlert);
    }

    public String getSuccessMessage() {
        WaitUtils.waitForVisible(successAlert, 8);
        return getText(successAlert);
    }

    public String getErrorMessage() {
        WaitUtils.waitForVisible(errorAlert, 8);
        return getText(errorAlert);
    }

    public boolean isErrorAlertDisplayed() {
        return isDisplayed(errorAlert);
    }

    public boolean isCreateButtonEnabled() {
        return isEnabled(createTripButton);
    }

    /**
     * Returns true if both pickup and dropoff have been confirmed with coordinates.
     */
    public boolean areLocationsSet() {
        List<WebElement> confirmations = driver.findElements(By.cssSelector("small.text-success"));
        return confirmations.size() >= 2;
    }

    public String getDefaultApprovalMode() {
        WaitUtils.waitForVisible(approvalModeSelect);
        return new org.openqa.selenium.support.ui.Select(approvalModeSelect)
                .getFirstSelectedOption().getText();
    }
}
