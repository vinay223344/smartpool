package com.smarttransport.pages;

import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * TripBookingsPage — Page Object for /trip-bookings/{tripId}
 * Fixed: replaced all button:contains() CSS with XPath.
 */
public class TripBookingsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(TripBookingsPage.class);

    @FindBy(css = ".booking-row, [class*='booking-item'], tr[class*='booking']")
    private List<WebElement> bookingRows;

    @FindBy(css = ".alert, [class*='toast']")
    private WebElement toastMessage;

    @FindBy(css = ".empty-state, [class*='empty']")
    private WebElement emptyState;

    // Page heading - confirm we are on the right page
    @FindBy(css = "h2, h3, .page-title")
    private WebElement pageHeading;

    public TripBookingsPage(WebDriver driver) { super(driver); }

    public int getBookingCount() { return bookingRows.size(); }

    public boolean isEmptyStateDisplayed() { return isDisplayed(emptyState); }

    /** Returns booking status badge text at given index */
    public String getBookingStatus(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> badges = row.findElements(
                By.cssSelector(".badge-status, [class*='status'], [class*='badge']"));
        return badges.isEmpty() ? "" : badges.get(0).getText().trim();
    }

    /** Returns passenger name from booking row at given index */
    public String getPassengerName(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> names = row.findElements(
                By.cssSelector("[class*='passenger'], [class*='name']"));
        return names.isEmpty() ? "" : names.get(0).getText().trim();
    }

    /** Returns fare text from booking row */
    public String getBookingFare(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> fares = row.findElements(
                By.cssSelector("[class*='fare'], strong[style*='color']"));
        return fares.isEmpty() ? "" : fares.get(0).getText().trim();
    }

    /** Returns booking time text */
    public String getBookingTime(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> times = row.findElements(
                By.cssSelector("[class*='time'], [class*='date'], time"));
        return times.isEmpty() ? "" : times.get(0).getText().trim();
    }

    /** Returns booking type (SINGLE or RECURRING) */
    public String getBookingType(int index) {
        WebElement row = bookingRows.get(index);
        List<WebElement> types = row.findElements(
                By.cssSelector("[class*='type'], [class*='booking-type']"));
        return types.isEmpty() ? "" : types.get(0).getText().trim();
    }

    /** Clicks Approve on booking at given index — XPath button text match */
    public TripBookingsPage approveBooking(int index) {
        log.info("Approving booking at index: {}", index);
        WebElement row = bookingRows.get(index);
        WebElement btn = row.findElement(
                By.xpath(".//button[contains(@class,'approve')"
                       + " or contains(normalize-space(.),'Approve')]"));
        click(btn);
        waitForSpinner();
        WaitUtils.pause(600);
        return this;
    }

    /** Clicks Reject on booking at given index — XPath button text match */
    public TripBookingsPage rejectBooking(int index) {
        log.info("Rejecting booking at index: {}", index);
        WebElement row = bookingRows.get(index);
        WebElement btn = row.findElement(
                By.xpath(".//button[contains(@class,'reject')"
                       + " or contains(normalize-space(.),'Reject')]"));
        click(btn);
        // Accept confirm dialog if present
        try { WaitUtils.waitForAlert().accept(); } catch (Exception ignored) {}
        waitForSpinner();
        WaitUtils.pause(600);
        return this;
    }

    /** True if Approve button visible for booking at index */
    public boolean isApproveButtonVisible(int index) {
        List<WebElement> btns = bookingRows.get(index).findElements(
                By.xpath(".//button[contains(@class,'approve')"
                       + " or contains(normalize-space(.),'Approve')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    /** True if Reject button visible for booking at index */
    public boolean isRejectButtonVisible(int index) {
        List<WebElement> btns = bookingRows.get(index).findElements(
                By.xpath(".//button[contains(@class,'reject')"
                       + " or contains(normalize-space(.),'Reject')]"));
        return !btns.isEmpty() && btns.get(0).isDisplayed();
    }

    public String getToastMessage() {
        WaitUtils.waitForVisible(toastMessage, 5);
        return getText(toastMessage);
    }

    public boolean isPageLoaded() {
        return driver.getCurrentUrl().contains("/trip-bookings/");
    }
}
