package com.smarttransport.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * ConfigReader — Reads configuration from config.properties file.
 * Singleton pattern ensures the file is loaded only once.
 */
public class ConfigReader {

    private static final Logger log = LogManager.getLogger(ConfigReader.class);
    private static Properties properties;
    private static final String CONFIG_PATH = "src/main/resources/config.properties";

    // Private constructor — prevents instantiation
    private ConfigReader() {}

    /**
     * Loads properties file once (thread-safe singleton).
     */
    public static Properties getProperties() {
        if (properties == null) {
            synchronized (ConfigReader.class) {
                if (properties == null) {
                    properties = new Properties();
                    try (FileInputStream fis = new FileInputStream(CONFIG_PATH)) {
                        properties.load(fis);
                        log.info("Configuration loaded from: {}", CONFIG_PATH);
                    } catch (IOException e) {
                        log.error("Failed to load config.properties: {}", e.getMessage());
                        throw new RuntimeException("config.properties not found at: " + CONFIG_PATH, e);
                    }
                }
            }
        }
        return properties;
    }

    // ── Convenience getters ──

    public static String get(String key) {
        String value = getProperties().getProperty(key);
        if (value == null) {
            throw new RuntimeException("Key not found in config.properties: " + key);
        }
        return value.trim();
    }

    public static int getInt(String key) {
        return Integer.parseInt(get(key));
    }

    public static boolean getBoolean(String key) {
        return Boolean.parseBoolean(get(key));
    }

    // ── Specific getters for clean code ──

    public static String getBaseUrl()           { return get("base.url"); }
    public static String getBrowser()           { return get("browser"); }
    public static int    getImplicitWait()      { return getInt("implicit.wait"); }
    public static int    getExplicitWait()      { return getInt("explicit.wait"); }
    public static int    getPageLoadTimeout()   { return getInt("page.load.timeout"); }
    public static boolean isHeadless()          { return getBoolean("headless"); }
    public static boolean isScreenshotOnFail()  { return getBoolean("screenshot.on.failure"); }
    public static String getScreenshotsDir()    { return get("screenshots.dir"); }
    public static String getReportsDir()        { return get("reports.dir"); }
    public static String getExcelDataPath()     { return get("excel.data.path"); }
    public static String getAdminEmail()        { return get("admin.email"); }
    public static String getAdminPassword()     { return get("admin.password"); }
    public static String getDefaultUserEmail()  { return get("default.user.email"); }
    public static String getDefaultUserPass()   { return get("default.user.password"); }
    public static String getDriverEmail()       { return get("default.driver.email"); }
    public static String getDriverPass()        { return get("default.driver.password"); }
    public static String getPassengerEmail()    { return get("default.passenger.email"); }
    public static String getPassengerPass()     { return get("default.passenger.password"); }
}
