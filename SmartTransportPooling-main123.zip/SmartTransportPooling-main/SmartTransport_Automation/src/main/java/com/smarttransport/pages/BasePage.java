package com.smarttransport.pages;

import com.smarttransport.utils.DriverFactory;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.*;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import java.util.List;

/**
 * BasePage — Parent class for all Page Object classes.
 *
 * Responsibilities:
 *  - Initializes PageFactory for @FindBy annotations
 *  - Provides common helper methods (click, type, select, scroll, etc.)
 *  - All page interactions go through WaitUtils for reliable waits
 *
 * Every page class MUST extend this class.
 */
public abstract class BasePage {

    private static final Logger log = LogManager.getLogger(BasePage.class);
    protected WebDriver driver;

    /**
     * Constructor — MUST be called via super(driver) from every page.
     * PageFactory.initElements scans all @FindBy annotations and creates
     * lazy proxies for each WebElement field.
     */
    public BasePage(WebDriver driver) {
        this.driver = driver;
        // initElements registers all @FindBy fields
        // Elements are located lazily — only when first accessed
        PageFactory.initElements(driver, this);
        log.debug("PageFactory initialized for: {}", this.getClass().getSimpleName());
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    /**
     * Navigates to the given URL and waits for the page to load.
     */
    protected void navigateTo(String url) {
        log.info("Navigating to: {}", url);
        driver.get(url);
        WaitUtils.waitForPageLoad();
    }

    public String getCurrentUrl() {
        return driver.getCurrentUrl();
    }

    public String getPageTitle() {
        return driver.getTitle();
    }

    // ──────────────────────────────────────────────
    //  Click Actions
    // ──────────────────────────────────────────────

    /**
     * Waits for element to be clickable then clicks it.
     */
    protected void click(WebElement element) {
        log.debug("Clicking element...");
        WaitUtils.waitForClickable(element).click();
    }

    /**
     * Scrolls to element then clicks — useful for elements below the fold.
     */
    protected void scrollAndClick(WebElement element) {
        log.debug("Scrolling to element and clicking...");
        scrollToElement(element);
        WaitUtils.waitForClickable(element).click();
    }

    /**
     * JavaScript click — use when normal click is blocked by overlays.
     */
    protected void jsClick(WebElement element) {
        log.debug("JS clicking element...");
        WaitUtils.waitForVisible(element);
        ((JavascriptExecutor) driver).executeScript("arguments[0].click();", element);
    }

    // ──────────────────────────────────────────────
    //  Input Actions
    // ──────────────────────────────────────────────

    /**
     * Clears the field then types the given text.
     * Waits for element to be visible before typing.
     */
    protected void typeText(WebElement element, String text) {
        log.debug("Typing '{}' into field...", text);
        WaitUtils.waitForVisible(element);
        element.clear();
        element.sendKeys(text);
    }

    /**
     * Types text character by character — use for fields with autocomplete.
     * Small delay between keystrokes mimics real user typing.
     */
    protected void typeSlowly(WebElement element, String text) {
        log.debug("Typing slowly '{}' into autocomplete field...", text);
        WaitUtils.waitForVisible(element);
        element.clear();
        for (char c : text.toCharArray()) {
            element.sendKeys(String.valueOf(c));
            WaitUtils.pause(80); // 80ms between keystrokes
        }
    }

    /**
     * Clears input using Ctrl+A then Delete — for stubborn fields.
     */
    protected void clearAndType(WebElement element, String text) {
        WaitUtils.waitForVisible(element);
        element.sendKeys(Keys.CONTROL + "a");
        element.sendKeys(Keys.DELETE);
        element.sendKeys(text);
    }

    /**
     * Sends special keys (ENTER, TAB, ESCAPE, etc.).
     */
    protected void sendKey(WebElement element, Keys key) {
        WaitUtils.waitForVisible(element);
        element.sendKeys(key);
    }

    // ──────────────────────────────────────────────
    //  Dropdown
    // ──────────────────────────────────────────────

    /**
     * Selects dropdown option by visible text.
     * For standard HTML <select> elements.
     */
    protected void selectByVisibleText(WebElement element, String text) {
        log.debug("Selecting '{}' from dropdown...", text);
        WaitUtils.waitForVisible(element);
        new Select(element).selectByVisibleText(text);
    }

    /**
     * Selects dropdown option by value attribute.
     */
    protected void selectByValue(WebElement element, String value) {
        WaitUtils.waitForVisible(element);
        new Select(element).selectByValue(value);
    }

    /**
     * Selects dropdown option by index (0-based).
     */
    protected void selectByIndex(WebElement element, int index) {
        WaitUtils.waitForVisible(element);
        new Select(element).selectByIndex(index);
    }

    // ──────────────────────────────────────────────
    //  Read / Verify Actions
    // ──────────────────────────────────────────────

    /**
     * Returns trimmed visible text of an element.
     */
    protected String getText(WebElement element) {
        WaitUtils.waitForVisible(element);
        return element.getText().trim();
    }

    /**
     * Returns the value attribute of an input field.
     */
    protected String getValue(WebElement element) {
        WaitUtils.waitForVisible(element);
        return element.getAttribute("value");
    }

    /**
     * Returns true if element is currently displayed on page.
     */
    protected boolean isDisplayed(WebElement element) {
        try {
            return element.isDisplayed();
        } catch (NoSuchElementException | StaleElementReferenceException e) {
            return false;
        }
    }

    /**
     * Returns true if element is enabled (not disabled).
     */
    protected boolean isEnabled(WebElement element) {
        try {
            WaitUtils.waitForVisible(element);
            return element.isEnabled();
        } catch (Exception e) {
            return false;
        }
    }

    /**
     * Returns true if a checkbox or radio is checked/selected.
     */
    protected boolean isSelected(WebElement element) {
        WaitUtils.waitForVisible(element);
        return element.isSelected();
    }

    /**
     * Checks if an element exists in the DOM without throwing exception.
     */
    protected boolean isElementPresent(By locator) {
        List<WebElement> elements = driver.findElements(locator);
        return !elements.isEmpty();
    }

    // ──────────────────────────────────────────────
    //  Scroll Actions
    // ──────────────────────────────────────────────

    /**
     * Scrolls the page until the element is in view.
     */
    protected void scrollToElement(WebElement element) {
        ((JavascriptExecutor) driver)
                .executeScript("arguments[0].scrollIntoView({behavior:'smooth',block:'center'});", element);
        WaitUtils.pause(300); // allow smooth scroll to complete
    }

    /**
     * Scrolls to top of page.
     */
    protected void scrollToTop() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, 0);");
    }

    /**
     * Scrolls to bottom of page.
     */
    protected void scrollToBottom() {
        ((JavascriptExecutor) driver).executeScript("window.scrollTo(0, document.body.scrollHeight);");
    }

    // ──────────────────────────────────────────────
    //  Hover / Mouse Actions
    // ──────────────────────────────────────────────

    /**
     * Hovers mouse over an element.
     */
    protected void hoverOver(WebElement element) {
        WaitUtils.waitForVisible(element);
        new Actions(driver).moveToElement(element).perform();
    }

    // ──────────────────────────────────────────────
    //  Button/Link by text — XPath based (CSS :contains is invalid in Selenium)
    // ──────────────────────────────────────────────

    /**
     * Finds a button whose visible text contains the given keyword.
     * Uses XPath normalize-space for robustness.
     */
    protected WebElement findButtonByText(String text) {
        return driver.findElement(
                By.xpath(".//button[contains(normalize-space(.),' " + text + "') "
                        + "or contains(normalize-space(.),'" + text + "')]"));
    }

    /**
     * Finds a button by text within a specific parent element.
     */
    protected WebElement findButtonByText(WebElement parent, String text) {
        return parent.findElement(
                By.xpath(".//button[contains(normalize-space(.),' " + text + "') "
                        + "or contains(normalize-space(.),'" + text + "')]"));
    }

    /**
     * Tries to find a button by text; returns null if not found (no exception).
     */
    protected WebElement findButtonByTextSafe(WebElement parent, String text) {
        try {
            return findButtonByText(parent, text);
        } catch (NoSuchElementException e) {
            return null;
        }
    }

    /**
     * Finds any clickable element (button or anchor) containing the given text.
     */
    protected WebElement findClickableByText(String text) {
        return driver.findElement(
                By.xpath(".//*[self::button or self::a]"
                        + "[contains(normalize-space(.),'" + text + "')]"));
    }

    // ──────────────────────────────────────────────
    //  Wait Helpers (delegated from WaitUtils)
    // ──────────────────────────────────────────────
        WaitUtils.waitForUrlContains(urlFragment);
    }

    protected void waitForVisible(WebElement element) {
        WaitUtils.waitForVisible(element);
    }

    protected void waitForPageLoad() {
        WaitUtils.waitForPageLoad();
    }

    protected void waitForSpinner() {
        WaitUtils.waitForSpinnerToDisappear();
    }

    // ──────────────────────────────────────────────
    //  LocalStorage (JWT token helpers)
    // ──────────────────────────────────────────────

    /**
     * Reads a value from browser localStorage.
     */
    protected String getLocalStorageValue(String key) {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        Object value = js.executeScript("return localStorage.getItem(arguments[0]);", key);
        return value != null ? value.toString() : null;
    }

    /**
     * Clears all localStorage (useful for logout simulation in test setup).
     */
    protected void clearLocalStorage() {
        ((JavascriptExecutor) driver).executeScript("localStorage.clear();");
        log.debug("LocalStorage cleared");
    }

    /**
     * Checks if JWT token exists in localStorage.
     */
    protected boolean isLoggedIn() {
        String token = getLocalStorageValue("token");
        return token != null && !token.isEmpty();
    }
}
