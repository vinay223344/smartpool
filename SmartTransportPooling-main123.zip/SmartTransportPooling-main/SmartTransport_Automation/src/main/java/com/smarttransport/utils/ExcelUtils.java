package com.smarttransport.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * ExcelUtils — Reads test data from Excel (.xlsx) files.
 *
 * Excel structure:
 *   Row 0  = Headers (column names)
 *   Row 1+ = Data rows
 *
 * Returns data as Object[][] for use with TestNG @DataProvider.
 */
public class ExcelUtils {

    private static final Logger log = LogManager.getLogger(ExcelUtils.class);

    private ExcelUtils() {}

    /**
     * Reads all data rows from an Excel sheet.
     * First row is treated as header and excluded from data.
     *
     * @param filePath   Path to the .xlsx file
     * @param sheetName  Name of the worksheet
     * @return           2D array of String values for @DataProvider
     */
    public static Object[][] readSheet(String filePath, String sheetName) {
        log.info("Reading Excel: {} | Sheet: {}", filePath, sheetName);

        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Sheet '" + sheetName + "' not found in " + filePath);
            }

            int totalRows = sheet.getLastRowNum();     // excludes header row
            int totalCols = sheet.getRow(0).getLastCellNum();

            log.info("Found {} data rows, {} columns in sheet '{}'",
                    totalRows, totalCols, sheetName);

            Object[][] data = new Object[totalRows][totalCols];

            // Start from row index 1 to skip header
            for (int rowIdx = 1; rowIdx <= totalRows; rowIdx++) {
                Row row = sheet.getRow(rowIdx);
                if (row == null) continue;

                for (int colIdx = 0; colIdx < totalCols; colIdx++) {
                    Cell cell = row.getCell(colIdx);
                    data[rowIdx - 1][colIdx] = getCellValueAsString(cell);
                }
            }
            return data;

        } catch (IOException e) {
            log.error("Failed to read Excel file '{}': {}", filePath, e.getMessage());
            throw new RuntimeException("Excel read error: " + e.getMessage(), e);
        }
    }

    /**
     * Reads Excel sheet as a list of maps (column name -> value).
     * Useful for readable access by column name.
     *
     * @param filePath   Path to the .xlsx file
     * @param sheetName  Name of the worksheet
     * @return           List of maps where key = column header, value = cell value
     */
    public static List<Map<String, String>> readSheetAsMaps(String filePath, String sheetName) {
        List<Map<String, String>> result = new ArrayList<>();

        try (FileInputStream fis = new FileInputStream(filePath);
             Workbook workbook = new XSSFWorkbook(fis)) {

            Sheet sheet = workbook.getSheet(sheetName);
            if (sheet == null) {
                throw new RuntimeException("Sheet '" + sheetName + "' not found.");
            }

            // Read headers from first row
            Row headerRow = sheet.getRow(0);
            int totalCols = headerRow.getLastCellNum();
            List<String> headers = new ArrayList<>();
            for (int i = 0; i < totalCols; i++) {
                headers.add(getCellValueAsString(headerRow.getCell(i)));
            }

            // Read data rows
            for (int rowIdx = 1; rowIdx <= sheet.getLastRowNum(); rowIdx++) {
                Row row = sheet.getRow(rowIdx);
                if (row == null) continue;

                Map<String, String> rowMap = new LinkedHashMap<>();
                for (int colIdx = 0; colIdx < totalCols; colIdx++) {
                    String header = headers.get(colIdx);
                    String value  = getCellValueAsString(row.getCell(colIdx));
                    rowMap.put(header, value);
                }
                result.add(rowMap);
            }

        } catch (IOException e) {
            throw new RuntimeException("Excel read error: " + e.getMessage(), e);
        }

        log.info("Read {} rows from sheet '{}'", result.size(), sheetName);
        return result;
    }

    /**
     * Gets cell value as a trimmed String regardless of cell type.
     */
    private static String getCellValueAsString(Cell cell) {
        if (cell == null) return "";

        return switch (cell.getCellType()) {
            case STRING  -> cell.getStringCellValue().trim();
            case NUMERIC -> {
                // Check if it's a whole number to avoid "1.0" instead of "1"
                double val = cell.getNumericCellValue();
                if (val == Math.floor(val)) {
                    yield String.valueOf((long) val);
                }
                yield String.valueOf(val);
            }
            case BOOLEAN -> String.valueOf(cell.getBooleanCellValue());
            case FORMULA -> cell.getCellFormula();
            default      -> "";
        };
    }
}
