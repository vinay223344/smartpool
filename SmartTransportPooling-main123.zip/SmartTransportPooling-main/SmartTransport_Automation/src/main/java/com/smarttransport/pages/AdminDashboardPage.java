package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 * AdminDashboardPage — Page Object for http://localhost:4200/admin/dashboard
 */
public class AdminDashboardPage extends BasePage {

    private static final Logger log = LogManager.getLogger(AdminDashboardPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/admin/dashboard";

    // ──────────────────────────────────────────────
    //  @FindBy — Stat Cards
    // ──────────────────────────────────────────────

    @FindBy(css = ".scard:nth-child(1) .scard-num, [class*='total-users']")
    private WebElement totalUsers;

    @FindBy(css = ".scard:nth-child(2) .scard-num, [class*='total-trips']")
    private WebElement totalTrips;

    @FindBy(css = ".scard:nth-child(3) .scard-num, [class*='active-trips']")
    private WebElement activeTrips;

    @FindBy(css = ".scard:nth-child(4) .scard-num, [class*='total-bookings']")
    private WebElement totalBookings;

    @FindBy(css = ".scard:nth-child(5) .scard-num, [class*='total-orgs']")
    private WebElement totalOrganizations;

    @FindBy(css = ".scard:nth-child(6) .scard-num, [class*='pending-vehicles']")
    private WebElement pendingVehicles;

    // Navigation links
    @FindBy(css = "a[routerLink*='admin/organizations'], a[href*='organizations'], button:contains('Organizations')")
    private WebElement organizationsLink;

    @FindBy(css = "a[routerLink*='admin/vehicles'], a[href*='admin/vehicles'], button:contains('Vehicles')")
    private WebElement vehiclesLink;

    // Sidebar items
    @FindBy(css = ".sb-link[routerLink='/admin/organizations']")
    private WebElement sidebarOrgs;

    @FindBy(css = ".sb-link[routerLink='/admin/vehicles']")
    private WebElement sidebarVehicles;

    @FindBy(css = ".sb-link[routerLink='/admin/dashboard']")
    private WebElement sidebarDashboard;

    // Non-admin links that should NOT appear
    @FindBy(css = ".sb-link[routerLink='/search-trips']")
    private WebElement sidebarSearchRides;

    @FindBy(css = ".sb-link[routerLink='/my-trips']")
    private WebElement sidebarMyTrips;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public AdminDashboardPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public AdminDashboardPage open() {
        log.info("Opening Admin Dashboard: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/admin/dashboard");
        WaitUtils.waitForVisible(totalUsers);
        return this;
    }

    // ──────────────────────────────────────────────
    //  Stat Getters
    // ──────────────────────────────────────────────

    public int getTotalUsers()         { return parseCount(totalUsers); }
    public int getTotalTrips()         { return parseCount(totalTrips); }
    public int getActiveTrips()        { return parseCount(activeTrips); }
    public int getTotalBookings()      { return parseCount(totalBookings); }
    public int getTotalOrganizations() { return parseCount(totalOrganizations); }
    public int getPendingVehicles()    { return parseCount(pendingVehicles); }

    private int parseCount(WebElement element) {
        try {
            WaitUtils.waitForVisible(element);
            return Integer.parseInt(getText(element).replaceAll("[^0-9]", ""));
        } catch (Exception e) {
            return 0;
        }
    }

    // ──────────────────────────────────────────────
    //  Navigation Actions
    // ──────────────────────────────────────────────

    public AdminOrganizationsPage clickOrganizationsLink() {
        log.info("Navigating to Admin Organizations...");
        click(organizationsLink);
        WaitUtils.waitForUrlContains("/admin/organizations");
        return new AdminOrganizationsPage(driver);
    }

    public AdminVehiclesPage clickVehiclesLink() {
        log.info("Navigating to Admin Vehicles...");
        click(vehiclesLink);
        WaitUtils.waitForUrlContains("/admin/vehicles");
        return new AdminVehiclesPage(driver);
    }

    // ──────────────────────────────────────────────
    //  Sidebar Checks (Admin role verification)
    // ──────────────────────────────────────────────

    public boolean isAdminDashboardSidebarVisible()   { return isDisplayed(sidebarDashboard); }
    public boolean isAdminOrgsSidebarVisible()        { return isDisplayed(sidebarOrgs); }
    public boolean isAdminVehiclesSidebarVisible()    { return isDisplayed(sidebarVehicles); }
    public boolean isSearchRidesSidebarVisible()      { return isDisplayed(sidebarSearchRides); }
    public boolean isMyTripsSidebarVisible()          { return isDisplayed(sidebarMyTrips); }

    public boolean isPageLoaded() {
        return isDisplayed(totalUsers);
    }
}
