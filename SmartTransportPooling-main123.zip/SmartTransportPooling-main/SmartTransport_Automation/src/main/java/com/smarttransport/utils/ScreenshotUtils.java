package com.smarttransport.utils;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * ScreenshotUtils — Captures and saves screenshots on test failure.
 */
public class ScreenshotUtils {

    private static final Logger log = LogManager.getLogger(ScreenshotUtils.class);
    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("yyyy-MM-dd_HH-mm-ss");

    private ScreenshotUtils() {}

    /**
     * Captures screenshot and saves it to the configured directory.
     * @param testName  Name of the test (used in filename)
     * @return          Absolute path of the saved screenshot file
     */
    public static String capture(String testName) {
        if (!DriverFactory.isDriverActive()) {
            log.warn("Cannot capture screenshot — driver is not active.");
            return null;
        }

        try {
            // Create directory if it does not exist
            String screenshotsDir = ConfigReader.getScreenshotsDir();
            Path dir = Paths.get(screenshotsDir);
            if (!Files.exists(dir)) {
                Files.createDirectories(dir);
            }

            // Generate unique filename with timestamp
            String timestamp = LocalDateTime.now().format(FORMATTER);
            String cleanName = testName.replaceAll("[^a-zA-Z0-9_-]", "_");
            String filename  = cleanName + "_" + timestamp + ".png";
            Path destination = dir.resolve(filename);

            // Take screenshot
            File source = ((TakesScreenshot) DriverFactory.getDriver())
                    .getScreenshotAs(OutputType.FILE);
            Files.copy(source.toPath(), destination);

            log.info("Screenshot saved: {}", destination.toAbsolutePath());
            return destination.toAbsolutePath().toString();

        } catch (IOException e) {
            log.error("Failed to save screenshot: {}", e.getMessage());
            return null;
        }
    }

    /**
     * Returns screenshot as Base64 string (for embedding in Extent Reports).
     */
    public static String captureBase64() {
        if (!DriverFactory.isDriverActive()) return null;
        try {
            return ((TakesScreenshot) DriverFactory.getDriver())
                    .getScreenshotAs(OutputType.BASE64);
        } catch (Exception e) {
            log.error("Failed to capture base64 screenshot: {}", e.getMessage());
            return null;
        }
    }
}
