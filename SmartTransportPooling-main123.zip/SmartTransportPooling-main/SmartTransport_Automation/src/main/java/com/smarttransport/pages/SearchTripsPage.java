package com.smarttransport.pages;

import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import java.util.List;

/**
 * SearchTripsPage — Page Object for http://localhost:4200/search-trips
 */
public class SearchTripsPage extends BasePage {

    private static final Logger log = LogManager.getLogger(SearchTripsPage.class);
    private static final String PAGE_URL = ConfigReader.getBaseUrl() + "/search-trips";

    // ──────────────────────────────────────────────
    //  @FindBy Elements
    // ──────────────────────────────────────────────

    @FindBy(css = "input[placeholder*='origin'], input[name='origin'], input[placeholder*='Origin']")
    private WebElement originInput;

    @FindBy(css = "input[placeholder*='destination'], input[name='destination']")
    private WebElement destinationInput;

    @FindBy(css = "input[name='departureAfter'], input[placeholder*='From']")
    private WebElement departureFromInput;

    @FindBy(css = "input[name='departureBefore'], input[placeholder*='To']")
    private WebElement departureToInput;

    @FindBy(css = "input[name='minPrice'], input[placeholder*='Min Price']")
    private WebElement minPriceInput;

    @FindBy(css = "input[name='maxPrice'], input[placeholder*='Max Price']")
    private WebElement maxPriceInput;

    @FindBy(css = "select[name='gender']")
    private WebElement genderSelect;

    @FindBy(css = "button[type='submit'], button.btn-search")
    private WebElement searchButton;

    // Trip cards / rows in results
    @FindBy(css = ".trip-card, .trip-item, [class*='trip-row']")
    private List<WebElement> tripResults;

    // Trip route text (origin → destination)
    @FindBy(css = ".trip-route, [class*='route']")
    private List<WebElement> tripRoutes;

    // Trip status badges
    @FindBy(css = ".badge-status, [class*='badge']")
    private List<WebElement> statusBadges;

    // Empty state message
    @FindBy(css = "[class*='empty'], .no-results, .empty-state h5")
    private WebElement emptyState;

    // Autocomplete suggestion items
    @FindBy(css = ".suggestion-item")
    private List<WebElement> suggestions;

    // ──────────────────────────────────────────────
    //  Constructor
    // ──────────────────────────────────────────────

    public SearchTripsPage(WebDriver driver) {
        super(driver);
    }

    // ──────────────────────────────────────────────
    //  Navigation
    // ──────────────────────────────────────────────

    public SearchTripsPage open() {
        log.info("Opening Search Trips page: {}", PAGE_URL);
        navigateTo(PAGE_URL);
        WaitUtils.waitForUrlContains("/search-trips");
        return this;
    }

    // ──────────────────────────────────────────────
    //  Search Form Actions
    // ──────────────────────────────────────────────

    public SearchTripsPage enterOrigin(String origin) {
        log.debug("Entering origin: {}", origin);
        typeText(originInput, origin);
        return this;
    }

    public SearchTripsPage enterDestination(String destination) {
        log.debug("Entering destination: {}", destination);
        typeText(destinationInput, destination);
        return this;
    }

    public SearchTripsPage setDepartureFrom(String date) {
        clearAndType(departureFromInput, date);
        return this;
    }

    public SearchTripsPage setDepartureTo(String date) {
        clearAndType(departureToInput, date);
        return this;
    }

    public SearchTripsPage setMinPrice(double price) {
        clearAndType(minPriceInput, String.valueOf(price));
        return this;
    }

    public SearchTripsPage setMaxPrice(double price) {
        clearAndType(maxPriceInput, String.valueOf(price));
        return this;
    }

    public SearchTripsPage selectGender(String gender) {
        selectByVisibleText(genderSelect, gender);
        return this;
    }

    /**
     * Clicks Search and waits for results to load.
     */
    public SearchTripsPage clickSearch() {
        log.info("Clicking Search button...");
        click(searchButton);
        waitForSpinner();
        WaitUtils.pause(600); // allow Angular to render results
        return this;
    }

    // ──────────────────────────────────────────────
    //  Autocomplete
    // ──────────────────────────────────────────────

    /**
     * Types slowly in origin to trigger autocomplete dropdown.
     * Returns list of visible suggestion texts.
     */
    public List<String> getOriginSuggestions(String query) {
        typeSlowly(originInput, query);
        WaitUtils.waitForVisible(By.cssSelector(".suggestion-item"), 8);
        return suggestions.stream().map(WebElement::getText).toList();
    }

    public boolean areSuggestionsVisible() {
        List<WebElement> s = driver.findElements(By.cssSelector(".suggestion-item"));
        return !s.isEmpty() && s.get(0).isDisplayed();
    }

    // ──────────────────────────────────────────────
    //  Results
    // ──────────────────────────────────────────────

    public int getResultsCount() {
        return tripResults.size();
    }

    public boolean hasResults() {
        return !tripResults.isEmpty();
    }

    public boolean isEmptyStateDisplayed() {
        return isDisplayed(emptyState);
    }

    /**
     * Returns the text of a specific trip route in results (0-indexed).
     */
    public String getResultRouteText(int index) {
        if (index >= tripRoutes.size()) return "";
        return getText(tripRoutes.get(index));
    }

    /**
     * Returns true if any result route text contains the given keyword.
     */
    public boolean resultContainsOrigin(String keyword) {
        return tripRoutes.stream()
                .anyMatch(r -> r.getText().toLowerCase().contains(keyword.toLowerCase()));
    }

    /**
     * Checks that no result has a status other than SCHEDULED.
     */
    public boolean allResultsAreScheduled() {
        return statusBadges.stream()
                .allMatch(b -> b.getText().equalsIgnoreCase("SCHEDULED"));
    }

    /**
     * Opens the first trip result and returns TripDetailPage.
     */
    public TripDetailPage openFirstResult() {
        log.info("Opening first search result...");
        if (tripResults.isEmpty()) {
            throw new RuntimeException("No search results to open.");
        }
        // Find and click the view/arrow button inside the first result
        WebElement link = tripResults.get(0).findElement(
                By.cssSelector("a, .view-btn, button"));
        click(link);
        WaitUtils.waitForUrlContains("/trip/");
        return new TripDetailPage(driver);
    }
}
