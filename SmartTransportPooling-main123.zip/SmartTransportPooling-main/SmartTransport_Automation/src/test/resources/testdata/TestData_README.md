# TestData.xlsx — Required Sheets and Columns

Create a file named `TestData.xlsx` in this folder with these 5 sheets:

---

## Sheet 1: LoginData
| email | password | expectedResult |
|---|---|---|
| john@test.com | pass123 | valid |
| john@test.com | wrongpass | invalid |
| nobody@test.com | pass123 | invalid |
| | pass123 | invalid |
| john@test.com | | invalid |

---

## Sheet 2: RegistrationData
| name | email | password | expectedResult |
|---|---|---|---|
| John Doe | newuser1@test.com | pass123 | valid |
| | newuser2@test.com | pass123 | invalid |
| Jane | jane@unknown.com | pass123 | invalid |
| Bob | bob@test.com | abc | invalid |

---

## Sheet 3: TripData
| origin | destination | seats | price | expectedResult |
|---|---|---|---|---|
| Chennai | Bangalore | 3 | 200 | valid |
| | Bangalore | 2 | 150 | invalid |
| Chennai | Bangalore | 0 | 200 | invalid |
| Chennai | Bangalore | 2 | | invalid |

---

## Sheet 4: BookingData
| tripId | seats | bookingType | expectedResult |
|---|---|---|---|
| 1 | 1 | SINGLE | valid |
| 1 | 0 | SINGLE | valid |
| 999 | 1 | SINGLE | invalid |

---

## Sheet 5: SearchData
| origin | destination | minPrice | maxPrice | expectedHasResults |
|---|---|---|---|---|
| Chennai | | | | false |
| | Bangalore | | | false |
| Chennai | Bangalore | 100 | 500 | false |
| Chennai | Bangalore | | 200 | false |
