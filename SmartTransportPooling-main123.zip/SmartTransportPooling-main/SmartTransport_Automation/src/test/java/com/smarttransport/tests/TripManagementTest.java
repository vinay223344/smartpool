package com.smarttransport.tests;

import com.smarttransport.base.BaseTest;
import com.smarttransport.pages.CreateTripPage;
import com.smarttransport.pages.MyTripsPage;
import com.smarttransport.utils.ExcelUtils;
import com.smarttransport.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * TripManagementTest — Covers TS-TRIP-01 to TS-TRIP-20
 * TC-TRIP-001 to TC-TRIP-023
 */
public class TripManagementTest extends BaseTest {

    // Format for datetime-local input: "yyyy-MM-dd'T'HH:mm"
    private static final DateTimeFormatter DT_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm");

    /** Returns a future datetime string N hours from now. */
    private String futureTime(int hoursFromNow) {
        return LocalDateTime.now().plusHours(hoursFromNow).format(DT_FMT);
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-001 — Create Valid Single Trip
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-001 Create Valid Single Trip With All Fields",
          groups = {"smoke", "trip"})
    public void testCreateValidSingleTrip() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to Create Trip page");
        CreateTripPage createTrip = getCreateTripPage().open();

        logStep("Set pickup location to Chennai");
        createTrip.setPickupLocation("Chennai");

        logStep("Set dropoff location to Bangalore");
        createTrip.setDropoffLocation("Bangalore");

        logStep("Set departure time to 2 hours from now");
        createTrip.setDepartureTime(futureTime(2));

        logStep("Set available seats to 3");
        createTrip.setAvailableSeats(3);

        logStep("Set price per seat to 200");
        createTrip.setPricePerSeat(200.0);

        logStep("Select approval mode as Manual Review");
        createTrip.selectApprovalMode("Manual Review");

        logStep("Add intermediate stop: Salem");
        createTrip.addStop("Salem");

        logStep("Verify both locations are confirmed on map");
        Assert.assertTrue(createTrip.areLocationsSet(),
                "Both pickup and dropoff locations should have coordinates confirmed");

        logStep("Click Create Trip button");
        createTrip.clickCreateTrip();

        logStep("Verify success message");
        Assert.assertTrue(
                createTrip.isSuccessAlertDisplayed()
                        || driver.getCurrentUrl().contains("/my-trips"),
                "Trip should be created successfully. URL: " + driver.getCurrentUrl());

        logPass("TC-TRIP-001 PASSED — Single trip created successfully");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-002 — Past Departure Time Rejected
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-002 Create Trip With Past Departure Time Is Rejected",
          groups = {"trip", "validation"})
    public void testPastDepartureTimeRejected() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to Create Trip page");
        CreateTripPage createTrip = getCreateTripPage().open();

        logStep("Set pickup and dropoff");
        createTrip.setPickupLocation("Chennai");
        createTrip.setDropoffLocation("Bangalore");

        logStep("Set departure time to 1 hour in the past");
        String pastTime = LocalDateTime.now().minusHours(1).format(DT_FMT);
        createTrip.setDepartureTime(pastTime);
        createTrip.setAvailableSeats(2);
        createTrip.setPricePerSeat(150.0);

        logStep("Click Create Trip");
        createTrip.clickCreateTrip();

        logStep("Verify error message about past departure");
        Assert.assertTrue(createTrip.isErrorAlertDisplayed(),
                "Error should be shown for past departure time");

        String error = createTrip.getErrorMessage();
        Assert.assertTrue(
                error.toLowerCase().contains("future")
                        || error.toLowerCase().contains("past")
                        || error.toLowerCase().contains("departure"),
                "Error should mention departure time. Got: " + error);

        logPass("TC-TRIP-002 PASSED — Past departure time rejected");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-004 — Zero Seats Validation
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-004 Create Trip With Zero Seats Shows Validation Error",
          groups = {"trip", "validation"})
    public void testZeroSeatsValidation() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to Create Trip page");
        CreateTripPage createTrip = getCreateTripPage().open();

        logStep("Set locations and time but 0 seats");
        createTrip.setPickupLocation("Chennai");
        createTrip.setDropoffLocation("Bangalore");
        createTrip.setDepartureTime(futureTime(2));
        createTrip.setAvailableSeats(0);
        createTrip.setPricePerSeat(200.0);

        logStep("Click Create Trip");
        createTrip.clickCreateTrip();

        logStep("Verify error or validation shown");
        Assert.assertTrue(
                createTrip.isErrorAlertDisplayed() || !createTrip.isCreateButtonEnabled(),
                "System should reject 0 seats");

        logPass("TC-TRIP-004 PASSED — Zero seats validation works");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-005 — Non-Recurring Without Price
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-005 Non-Recurring Trip Without Price Is Rejected",
          groups = {"trip", "validation"})
    public void testNonRecurringWithoutPrice() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to Create Trip page");
        CreateTripPage createTrip = getCreateTripPage().open();

        logStep("Set locations, time, seats — no price");
        createTrip.setPickupLocation("Chennai");
        createTrip.setDropoffLocation("Bangalore");
        createTrip.setDepartureTime(futureTime(3));
        createTrip.setAvailableSeats(2);
        // Deliberately NOT setting price

        logStep("Click Create Trip");
        createTrip.clickCreateTrip();

        logStep("Verify price error shown");
        Assert.assertTrue(createTrip.isErrorAlertDisplayed(),
                "Error should be shown when price is missing for non-recurring trip");

        String error = createTrip.getErrorMessage();
        Assert.assertTrue(
                error.toLowerCase().contains("price") || error.toLowerCase().contains("seat"),
                "Error should mention price. Got: " + error);

        logPass("TC-TRIP-005 PASSED — Non-recurring trip without price rejected");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-008 — Default Approval Mode is MANUAL
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-009 Default Approval Mode Is MANUAL",
          groups = {"trip"})
    public void testDefaultApprovalModeIsManual() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to Create Trip page");
        CreateTripPage createTrip = getCreateTripPage().open();

        logStep("Read default value of Approval Mode dropdown");
        String defaultMode = createTrip.getDefaultApprovalMode();
        logStep("Default approval mode: " + defaultMode);

        Assert.assertTrue(
                defaultMode.equalsIgnoreCase("Manual Review")
                        || defaultMode.equalsIgnoreCase("MANUAL"),
                "Default approval mode should be MANUAL. Got: " + defaultMode);

        logPass("TC-TRIP-009 PASSED — Default approval mode is Manual");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-010 — Driver Lists Own Trips Only
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-010 Driver Sees Only Their Own Trips",
          groups = {"trip"})
    public void testDriverSeesOwnTripsOnly() {
        logStep("Login as Driver");
        loginAsDriver();

        logStep("Navigate to My Trips page");
        MyTripsPage myTrips = getMyTripsPage().open();

        int tripCount = myTrips.getTripCount();
        logStep("Driver's trip count: " + tripCount);

        logStep("Verify My Trips page loaded");
        Assert.assertTrue(
                tripCount >= 0,
                "My Trips page should load correctly");

        logStep("Navigate to /dashboard to verify URL is correct");
        Assert.assertTrue(driver.getCurrentUrl().contains("/my-trips"),
                "Should be on /my-trips page");

        logPass("TC-TRIP-010 PASSED — My Trips page shows driver's own trips");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-017 — Start SCHEDULED Trip → ACTIVE
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-017 Start SCHEDULED Trip Changes Status to ACTIVE",
          groups = {"trip"})
    public void testStartScheduledTrip() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to My Trips page");
        MyTripsPage myTrips = getMyTripsPage().open();

        logStep("Find a SCHEDULED trip");
        int tripCount = myTrips.getTripCount();

        boolean foundScheduled = false;
        for (int i = 0; i < tripCount; i++) {
            String status = myTrips.getTripStatus(i);
            logStep("Trip " + i + " status: " + status);
            if ("SCHEDULED".equalsIgnoreCase(status)) {
                logStep("Start trip at index: " + i);
                myTrips.clickStartTrip(i);
                foundScheduled = true;

                // Refresh and check status
                myTrips = getMyTripsPage().open();
                String newStatus = myTrips.getTripStatus(i);
                logStep("New status after start: " + newStatus);
                Assert.assertEquals(newStatus, "ACTIVE",
                        "Trip status should change to ACTIVE after starting");
                break;
            }
        }

        if (!foundScheduled) {
            logStep("No SCHEDULED trip found — skipping start test");
        }

        logPass("TC-TRIP-017 PASSED — Trip start status verified");
    }

    // ──────────────────────────────────────────────
    //  TC-TRIP-018 — Start Button Not Shown for ACTIVE Trip
    // ──────────────────────────────────────────────

    @Test(testName = "TC-TRIP-018 Start Trip Button Not Shown For Already ACTIVE Trip",
          groups = {"trip", "ux"})
    public void testStartButtonNotVisibleForActiveTrip() {
        logStep("Login as driver");
        loginAsDriver();

        logStep("Navigate to My Trips page");
        MyTripsPage myTrips = getMyTripsPage().open();

        int tripCount = myTrips.getTripCount();
        for (int i = 0; i < tripCount; i++) {
            String status = myTrips.getTripStatus(i);
            if ("ACTIVE".equalsIgnoreCase(status)) {
                logStep("Found ACTIVE trip at index " + i);

                boolean startVisible = myTrips.isStartTripButtonVisible(i);
                boolean completeVisible = myTrips.isCompleteTripButtonVisible(i);

                Assert.assertFalse(startVisible,
                        "Start Trip button should NOT be visible for ACTIVE trip");
                Assert.assertTrue(completeVisible,
                        "Complete Trip button should be visible for ACTIVE trip");
                logPass("TC-TRIP-018 PASSED — Start button hidden for ACTIVE trip");
                return;
            }
        }
        logStep("No ACTIVE trip found — test skipped");
    }

    // ──────────────────────────────────────────────
    //  Data Driven — Trip Creation (Excel)
    // ──────────────────────────────────────────────

    @DataProvider(name = "tripData")
    public Object[][] getTripData() {
        return ExcelUtils.readSheet(
                ConfigReader.getExcelDataPath(),
                "TripData");
    }

    @Test(testName = "TC-TRIP-DD Data Driven Trip Creation",
          dataProvider = "tripData",
          groups = {"trip", "data-driven"})
    public void testCreateTripDataDriven(String origin, String destination,
                                          String seats, String price, String expectedResult) {
        logStep("Data driven trip: " + origin + " -> " + destination
                + " | seats: " + seats + " | price: " + price);

        loginAsDriver();
        CreateTripPage createTrip = getCreateTripPage().open();

        createTrip.setPickupLocation(origin);
        createTrip.setDropoffLocation(destination);
        createTrip.setDepartureTime(futureTime(2));

        if (!seats.isEmpty()) {
            try { createTrip.setAvailableSeats(Integer.parseInt(seats)); }
            catch (NumberFormatException ignored) {}
        }
        if (!price.isEmpty()) {
            try { createTrip.setPricePerSeat(Double.parseDouble(price)); }
            catch (NumberFormatException ignored) {}
        }

        createTrip.clickCreateTrip();

        if ("valid".equalsIgnoreCase(expectedResult)) {
            Assert.assertFalse(createTrip.isErrorAlertDisplayed(),
                    "Valid trip data should not show error");
        } else {
            Assert.assertTrue(createTrip.isErrorAlertDisplayed(),
                    "Invalid trip data should show error");
        }

        logPass("Data driven trip test completed: " + origin + " -> " + destination);
    }
}
