package com.smarttransport.tests;

import com.smarttransport.base.BaseTest;
import com.smarttransport.pages.RegisterPage;
import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.ExcelUtils;
import org.testng.Assert;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * RegistrationTest — Covers TS-AUTH-01 to TS-AUTH-04
 * TC-AUTH-001 to TC-AUTH-009
 */
public class RegistrationTest extends BaseTest {

    private static final String UNIQUE_SUFFIX =
            String.valueOf(System.currentTimeMillis()).substring(7);

    // ──────────────────────────────────────────────
    //  TC-AUTH-001 — Full Valid Registration
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-001 Register With All Valid Fields",
          groups = {"smoke", "auth", "registration"})
    public void testFullValidRegistration() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        String uniqueEmail = "testuser_" + UNIQUE_SUFFIX + "@test.com";

        logStep("Fill all registration fields");
        registerPage.registerFullUser(
                "Test User " + UNIQUE_SUFFIX,
                uniqueEmail,
                "pass123",
                "9876543210",
                "Male",
                "Engineering",
                "Chennai",
                "USER"
        );

        logStep("Verify registration success");
        // After registration user may be redirected or see success message
        boolean successOrRedirect = registerPage.isSuccessDisplayed()
                || driver.getCurrentUrl().contains("/dashboard")
                || driver.getCurrentUrl().contains("/verify-email");

        Assert.assertTrue(successOrRedirect,
                "Registration should succeed and show success or redirect. URL: "
                + driver.getCurrentUrl());

        logPass("TC-AUTH-001 PASSED — Full registration successful");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-002 — Minimum Fields Registration
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-002 Register With Minimum Required Fields Only",
          groups = {"auth", "registration"})
    public void testMinimalRegistration() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        String uniqueEmail = "minimal_" + UNIQUE_SUFFIX + "@test.com";

        logStep("Fill only mandatory fields — name, email, password");
        registerPage.registerMinimal("MinUser", uniqueEmail, "pass123");

        logStep("Verify no validation errors on optional fields");
        Assert.assertFalse(
                registerPage.isErrorDisplayed(),
                "No server error should appear for minimal registration. " +
                "Error: " + (registerPage.isErrorDisplayed()
                        ? registerPage.getErrorMessage() : "none"));

        logPass("TC-AUTH-002 PASSED — Minimal registration successful");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-003 — Missing Name Validation
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-003 Register Without Name Shows Validation Error",
          groups = {"auth", "registration", "validation"})
    public void testMissingNameValidation() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        logStep("Enter email and password but leave name blank");
        registerPage.enterEmail("user@test.com");
        registerPage.enterPassword("pass123");
        registerPage.clickRegister();

        logStep("Verify name validation error is shown");
        String nameError = registerPage.getNameValidationError();
        logStep("Name error: " + nameError);
        Assert.assertFalse(nameError.isEmpty(),
                "Name validation error should be displayed when name is blank");

        logPass("TC-AUTH-003 PASSED — Missing name shows validation error");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-004 — Password Too Short
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-004 Register With Password Less Than 6 Chars Shows Error",
          groups = {"auth", "registration", "validation"})
    public void testPasswordTooShort() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        logStep("Enter short password (3 chars)");
        registerPage.enterName("TestUser");
        registerPage.enterEmail("shortpass@test.com");
        registerPage.enterPassword("abc"); // only 3 chars
        registerPage.clickRegister();

        logStep("Verify password length validation error");
        String passError = registerPage.getPasswordValidationError();
        logStep("Password error: " + passError);

        boolean hasError = !passError.isEmpty() || registerPage.isErrorDisplayed();
        Assert.assertTrue(hasError,
                "Password too short should show validation error");

        logPass("TC-AUTH-004 PASSED — Short password shows validation error");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-005 — Invalid Email Format
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-005 Register With Invalid Email Format Shows Error",
          groups = {"auth", "registration", "validation"})
    public void testInvalidEmailFormat() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        logStep("Enter invalid email format (no @ symbol)");
        registerPage.enterName("TestUser");
        registerPage.enterEmail("notanemail");
        registerPage.enterPassword("pass123");
        registerPage.clickRegister();

        logStep("Verify email format validation error");
        String emailError = registerPage.getEmailValidationError();
        boolean hasError = !emailError.isEmpty() || registerPage.isErrorDisplayed();
        Assert.assertTrue(hasError, "Invalid email format should show validation error");

        logPass("TC-AUTH-005 PASSED — Invalid email format shows error");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-006 — Non-Whitelisted Domain
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-006 Register With Non-Whitelisted Domain Is Rejected",
          groups = {"auth", "registration"})
    public void testNonWhitelistedDomain() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        logStep("Enter email with non-whitelisted domain");
        registerPage.enterName("OutsideUser");
        registerPage.enterEmail("user@notwhitelisted.xyz");
        registerPage.enterPassword("pass123");
        registerPage.clickRegister();

        logStep("Verify error about non-whitelisted domain");
        Assert.assertTrue(registerPage.isErrorDisplayed(),
                "Registration should be rejected for non-whitelisted domain");

        String error = registerPage.getErrorMessage();
        logStep("Error: " + error);
        Assert.assertTrue(
                error.toLowerCase().contains("whitelist")
                        || error.toLowerCase().contains("domain")
                        || error.toLowerCase().contains("organization"),
                "Error should mention domain whitelist. Got: " + error);

        logPass("TC-AUTH-006 PASSED — Non-whitelisted domain rejected");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-008 — Duplicate Email
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-008 Register With Already Registered Email Is Rejected",
          groups = {"auth", "registration"})
    public void testDuplicateEmailRejected() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        logStep("Enter already registered email");
        registerPage.enterName("Duplicate User");
        registerPage.enterEmail(ConfigReader.getDefaultUserEmail()); // already exists
        registerPage.enterPassword("pass123");
        registerPage.clickRegister();

        logStep("Verify duplicate email error");
        Assert.assertTrue(registerPage.isErrorDisplayed(),
                "Duplicate email should be rejected");

        String error = registerPage.getErrorMessage();
        Assert.assertTrue(
                error.toLowerCase().contains("already") || error.toLowerCase().contains("registered"),
                "Error should mention already registered. Got: " + error);

        logPass("TC-AUTH-008 PASSED — Duplicate email registration rejected");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-009 — ADMIN Role Falls Back to USER
    // ──────────────────────────────────────────────

    @Test(testName = "TC-AUTH-009 Registration With ADMIN Role Assigns USER Role",
          groups = {"auth", "registration", "security"})
    public void testAdminRoleFallback() {
        logStep("Open Register page");
        RegisterPage registerPage = getRegisterPage().open();

        String email = "admintest_" + UNIQUE_SUFFIX + "@test.com";

        logStep("Try to register with ADMIN role");
        registerPage.enterName("AdminAttempt");
        registerPage.enterEmail(email);
        registerPage.enterPassword("pass123");
        // Try selecting ADMIN if dropdown has it
        try {
            registerPage.selectRole("ADMIN");
        } catch (Exception e) {
            logStep("ADMIN option not in dropdown (expected) — using default role");
        }
        registerPage.clickRegister();

        logStep("Verify registration succeeded");
        boolean registered = registerPage.isSuccessDisplayed()
                || driver.getCurrentUrl().contains("/dashboard")
                || !registerPage.isErrorDisplayed();

        if (registered && !driver.getCurrentUrl().contains("/dashboard")) {
            logStep("Login and verify role is not ADMIN");
            driver.get(ConfigReader.getBaseUrl() + "/login");
            getLoginPage().loginAs(email, "pass123");
            driver.get(ConfigReader.getBaseUrl() + "/admin/dashboard");
            com.smarttransport.utils.WaitUtils.waitForUrlContains("/dashboard");
            Assert.assertFalse(driver.getCurrentUrl().contains("/admin/dashboard"),
                    "User registered as ADMIN should not be able to access admin dashboard");
        }

        logPass("TC-AUTH-009 PASSED — ADMIN role registration prevented");
    }

    // ──────────────────────────────────────────────
    //  Data Driven — Registration Scenarios (Excel)
    // ──────────────────────────────────────────────

    @DataProvider(name = "registrationData")
    public Object[][] getRegistrationData() {
        return ExcelUtils.readSheet(
                ConfigReader.getExcelDataPath(),
                "RegistrationData");
    }

    @Test(testName = "TC-AUTH-DD Data Driven Registration Test",
          dataProvider = "registrationData",
          groups = {"auth", "data-driven"})
    public void testRegistrationDataDriven(String name, String email,
                                            String password, String expected) {
        logStep("Data driven registration — email: " + email + " | expected: " + expected);

        RegisterPage page = getRegisterPage().open();
        page.enterName(name);
        page.enterEmail(email);
        page.enterPassword(password);
        page.clickRegister();

        if ("valid".equalsIgnoreCase(expected)) {
            Assert.assertFalse(page.isErrorDisplayed(),
                    "Valid registration should not show error for: " + email);
        } else {
            Assert.assertTrue(page.isErrorDisplayed() || !page.getEmailValidationError().isEmpty()
                    || !page.getPasswordValidationError().isEmpty(),
                    "Invalid registration should show some error for: " + email);
        }

        logPass("Data driven registration test completed for: " + email);
    }
}
