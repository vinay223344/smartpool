package com.smarttransport.tests;

import com.smarttransport.base.BaseTest;
import com.smarttransport.pages.*;
import com.smarttransport.utils.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * AdminTest — Covers TS-ORG, TS-VEH, TS-DASH-04 to TS-DASH-07
 * TC-ORG-001 to TC-ORG-006, TC-VEH-006, TC-VEH-007
 * TC-DASH-004, TC-DASH-006, TC-DASH-007
 */
public class AdminTest extends BaseTest {

    private static final String UNIQUE = String.valueOf(System.currentTimeMillis()).substring(7);

    // ──────────────────────────────────────────────
    //  TC-DASH-004 — Admin Sees Only Admin Sidebar
    // ──────────────────────────────────────────────

    @Test(testName = "TC-DASH-004 Admin Sees Only Admin Navigation In Sidebar",
          groups = {"smoke", "admin", "dashboard"})
    public void testAdminSeesOnlyAdminNavigation() {
        logStep("Login as ADMIN");
        AdminDashboardPage adminDashboard = loginAsAdmin();

        logStep("Verify admin dashboard loaded");
        Assert.assertTrue(adminDashboard.isPageLoaded(),
                "Admin dashboard stats should be visible");

        logStep("Verify admin sidebar items are visible");
        Assert.assertTrue(adminDashboard.isAdminDashboardSidebarVisible(),
                "Admin Dashboard sidebar link should be visible");
        Assert.assertTrue(adminDashboard.isAdminOrgsSidebarVisible(),
                "Organizations sidebar link should be visible");
        Assert.assertTrue(adminDashboard.isAdminVehiclesSidebarVisible(),
                "Approve Vehicles sidebar link should be visible");

        logStep("Verify non-admin links are NOT visible");
        Assert.assertFalse(adminDashboard.isSearchRidesSidebarVisible(),
                "Search Rides should NOT appear in admin sidebar");
        Assert.assertFalse(adminDashboard.isMyTripsSidebarVisible(),
                "My Trips should NOT appear in admin sidebar");

        logPass("TC-DASH-004 PASSED — Admin sees only admin navigation");
    }

    // ──────────────────────────────────────────────
    //  TC-DASH-005 — Regular User Sees Full Navigation
    // ──────────────────────────────────────────────

    @Test(testName = "TC-DASH-005 Regular User Sees Ride And Trip Navigation",
          groups = {"dashboard"})
    public void testRegularUserSeesRideNavigation() {
        logStep("Login as regular USER");
        DashboardPage dashboard = loginAsDefaultUser();

        logStep("Verify ride-related sidebar items are visible");
        Assert.assertTrue(dashboard.isSidebarSearchRidesVisible(),
                "Search Rides should be visible for regular user");
        Assert.assertTrue(dashboard.isSidebarMyBookingsVisible(),
                "My Bookings should be visible");
        Assert.assertTrue(dashboard.isSidebarCreateTripVisible(),
                "Create Trip should be visible");
        Assert.assertTrue(dashboard.isSidebarMyTripsVisible(),
                "My Trips should be visible");
        Assert.assertTrue(dashboard.isSidebarMyVehiclesVisible(),
                "My Vehicles should be visible");

        logStep("Verify admin links NOT visible for regular user");
        Assert.assertFalse(dashboard.isSidebarAdminDashboardVisible(),
                "Admin Dashboard should NOT be in regular user sidebar");

        logPass("TC-DASH-005 PASSED — Regular user sees full ride navigation");
    }

    // ──────────────────────────────────────────────
    //  TC-DASH-006 — Admin Dashboard Shows Platform Stats
    // ──────────────────────────────────────────────

    @Test(testName = "TC-DASH-006 Admin Dashboard Shows All Platform Statistics",
          groups = {"admin", "dashboard"})
    public void testAdminDashboardStats() {
        logStep("Login as ADMIN");
        AdminDashboardPage adminDashboard = loginAsAdmin();

        logStep("Read all stat card values");
        int users  = adminDashboard.getTotalUsers();
        int trips  = adminDashboard.getTotalTrips();
        int active = adminDashboard.getActiveTrips();
        int books  = adminDashboard.getTotalBookings();
        int orgs   = adminDashboard.getTotalOrganizations();
        int pveh   = adminDashboard.getPendingVehicles();

        logStep("Stats — Users:" + users + " Trips:" + trips + " Active:" + active
                + " Bookings:" + books + " Orgs:" + orgs + " PendingVeh:" + pveh);

        Assert.assertTrue(users   >= 0, "Total users should be >= 0");
        Assert.assertTrue(trips   >= 0, "Total trips should be >= 0");
        Assert.assertTrue(active  >= 0, "Active trips should be >= 0");
        Assert.assertTrue(books   >= 0, "Total bookings should be >= 0");
        Assert.assertTrue(orgs    >= 0, "Total organizations should be >= 0");
        Assert.assertTrue(pveh    >= 0, "Pending vehicles should be >= 0");

        Assert.assertTrue(active <= trips,
                "Active trips cannot exceed total trips");

        logPass("TC-DASH-006 PASSED — All platform stats displayed correctly");
    }

    // ──────────────────────────────────────────────
    //  TC-DASH-007 — Admin Dashboard Links Navigate
    // ──────────────────────────────────────────────

    @Test(testName = "TC-DASH-007 Admin Dashboard Links Navigate To Correct Pages",
          groups = {"admin", "dashboard"})
    public void testAdminDashboardLinksNavigate() {
        logStep("Login as ADMIN");
        AdminDashboardPage adminDashboard = loginAsAdmin();

        logStep("Click Organizations link");
        AdminOrganizationsPage orgsPage = adminDashboard.clickOrganizationsLink();
        Assert.assertTrue(driver.getCurrentUrl().contains("/admin/organizations"),
                "Should navigate to /admin/organizations");

        logStep("Navigate back to admin dashboard");
        driver.navigate().back();
        com.smarttransport.utils.WaitUtils.waitForUrlContains("/admin/dashboard");
        adminDashboard = getAdminDashboardPage();

        logStep("Click Approve Vehicles link");
        AdminVehiclesPage vehiclesPage = adminDashboard.clickVehiclesLink();
        Assert.assertTrue(driver.getCurrentUrl().contains("/admin/vehicles"),
                "Should navigate to /admin/vehicles");

        logPass("TC-DASH-007 PASSED — Admin dashboard navigation links work");
    }

    // ──────────────────────────────────────────────
    //  TC-ORG-001 — Create Organization
    // ──────────────────────────────────────────────

    @Test(testName = "TC-ORG-001 Admin Creates Organization With Valid Domain",
          groups = {"admin", "organization"})
    public void testCreateOrganization() {
        logStep("Login as ADMIN");
        loginAsAdmin();

        logStep("Navigate to Organizations page");
        AdminOrganizationsPage orgsPage = getAdminOrgsPage().open();

        int beforeCount = orgsPage.getOrgCount();
        logStep("Organization count before: " + beforeCount);

        String uniqueDomain = "testorg" + UNIQUE + ".com";

        logStep("Create new organization with domain: " + uniqueDomain);
        orgsPage.createOrganization("TestOrg " + UNIQUE, uniqueDomain, true);

        logStep("Verify success or new org in list");
        boolean success = orgsPage.isSuccessDisplayed()
                || orgsPage.getOrgCount() > beforeCount;
        Assert.assertTrue(success,
                "Organization should be created. Success: " + orgsPage.isSuccessDisplayed());

        logPass("TC-ORG-001 PASSED — Organization created successfully");
    }

    // ──────────────────────────────────────────────
    //  TC-ORG-002 — Duplicate Domain Rejected
    // ──────────────────────────────────────────────

    @Test(testName = "TC-ORG-002 Duplicate Organization Domain Is Rejected",
          groups = {"admin", "organization"})
    public void testDuplicateDomainRejected() {
        logStep("Login as ADMIN");
        loginAsAdmin();

        logStep("Navigate to Organizations page");
        AdminOrganizationsPage orgsPage = getAdminOrgsPage().open();

        if (orgsPage.getOrgCount() == 0) {
            logStep("No existing orgs — create one first");
            orgsPage.createOrganization("First Org", "firstorg.com", true);
        }

        logStep("Get domain of first existing org");
        String existingDomain = orgsPage.getOrgDomain(0);
        logStep("Existing domain: " + existingDomain);

        if (existingDomain.isEmpty()) {
            logStep("Could not read domain — skip");
            return;
        }

        logStep("Try to create another org with same domain");
        orgsPage.createOrganization("Duplicate Org", existingDomain, true);

        logStep("Verify error shown for duplicate domain");
        Assert.assertTrue(orgsPage.isErrorDisplayed(),
                "Duplicate domain should be rejected with error");

        String error = orgsPage.getErrorMessage();
        Assert.assertTrue(
                error.toLowerCase().contains("domain")
                        || error.toLowerCase().contains("exists")
                        || error.toLowerCase().contains("already"),
                "Error should mention duplicate domain. Got: " + error);

        logPass("TC-ORG-002 PASSED — Duplicate domain rejected");
    }

    // ──────────────────────────────────────────────
    //  TC-VEH-007 — Admin Approves a Vehicle
    // ──────────────────────────────────────────────

    @Test(testName = "TC-VEH-007 Admin Approves Pending Vehicle",
          groups = {"admin", "vehicle"})
    public void testAdminApprovesVehicle() {
        logStep("Login as ADMIN");
        loginAsAdmin();

        logStep("Navigate to Pending Vehicles page");
        AdminVehiclesPage vehiclesPage = getAdminVehiclesPage().open();

        int pending = vehiclesPage.getPendingVehicleCount();
        logStep("Pending vehicles count: " + pending);

        if (pending == 0) {
            logStep("No pending vehicles to approve — skip");
            return;
        }

        logStep("Approve the first pending vehicle");
        vehiclesPage.approveVehicle(0);

        logStep("Verify success message");
        boolean success = vehiclesPage.isSuccessDisplayed()
                || vehiclesPage.getPendingVehicleCount() < pending;
        Assert.assertTrue(success, "Vehicle approval should succeed");

        logPass("TC-VEH-007 PASSED — Vehicle approved by admin");
    }

    // ──────────────────────────────────────────────
    //  TC-AUTH-018 — Non-Admin Blocked from Admin Routes
    // ──────────────────────────────────────────────

    @Test(testName = "TC-UX-012 Role Guard Redirects Non-Admin From Admin Route",
          groups = {"security", "admin"})
    public void testNonAdminRedirectedFromAdminRoute() {
        logStep("Login as regular USER");
        loginAsDefaultUser();

        logStep("Attempt to access /admin/dashboard directly");
        driver.get(ConfigReader.getBaseUrl() + "/admin/dashboard");

        logStep("Wait for redirect");
        com.smarttransport.utils.WaitUtils.waitForUrlContains("/dashboard");

        logStep("Verify user is NOT on /admin/dashboard");
        Assert.assertFalse(driver.getCurrentUrl().endsWith("/admin/dashboard"),
                "Non-admin should be redirected away from /admin/dashboard");

        logPass("TC-UX-012 PASSED — Role guard blocks non-admin from admin pages");
    }
}
