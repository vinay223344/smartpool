package com.smarttransport.tests;

import com.smarttransport.base.BaseTest;
import com.smarttransport.pages.*;
import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.Test;

/**
 * KnownDefectTest — Tests that are EXPECTED TO FAIL because they
 * expose confirmed bugs from the Defect Report (Sheet 3).
 *
 * These tests use @Test(expectedExceptions) or explicit Assert.fail()
 * to correctly mark the defect status.
 *
 * Run group: "defect" to execute only known-defect tests.
 *
 * ┌─────────────────────────────────────────────────────────┐
 * │  HOW TO INTERPRET RESULTS:                              │
 * │  FAIL  = Bug still present (expected — do not fix yet)  │
 * │  PASS  = Bug has been fixed (update defect status)      │
 * └─────────────────────────────────────────────────────────┘
 */
public class KnownDefectTest extends BaseTest {

    // ══════════════════════════════════════════════════
    //  DEF-001 — Rejected passenger cannot re-book
    //  Expected: FAIL (bug present) | Pass if fixed
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-001 Rejected Passenger Should Be Able To Re-Book (Currently Blocked)",
          groups = {"defect", "booking"},
          description = "DEF-001: existsByTripIdAndPassengerIdAndStatusNot checks REJECTED "
                      + "which prevents re-booking. Should only check PENDING and APPROVED.")
    public void testDef001RejectedPassengerCanRebook() {

        logStep("[SETUP] Login as Passenger and book a MANUAL trip");
        loginAsPassenger();

        SearchTripsPage search = getSearchTripsPage().open();
        search.clickSearch();

        if (!search.hasResults()) {
            throw new SkipException("No trips available — need test data to reproduce DEF-001");
        }

        TripDetailPage tripDetail = search.openFirstResult();
        String tripUrl = driver.getCurrentUrl();
        tripDetail.setSeats(1).clickBookNow();

        // Verify booking created
        MyBookingsPage myBookings = getMyBookingsPage().open();
        if (myBookings.getBookingCount() == 0) {
            throw new SkipException("Booking not created — need MANUAL approval trip data");
        }

        logStep("[SETUP] Logout passenger — login as driver to reject booking");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsDriver();

        MyTripsPage myTrips = getMyTripsPage().open();
        if (myTrips.getTripCount() == 0) {
            throw new SkipException("No driver trips found");
        }

        TripBookingsPage bookings = myTrips.clickManageBookings(0);
        if (bookings.getBookingCount() == 0) {
            throw new SkipException("No bookings to reject");
        }

        boolean rejected = false;
        for (int i = 0; i < bookings.getBookingCount(); i++) {
            if ("PENDING".equalsIgnoreCase(bookings.getBookingStatus(i))) {
                bookings.rejectBooking(i);
                Assert.assertEquals(bookings.getBookingStatus(i), "REJECTED",
                        "Booking should be REJECTED");
                rejected = true;
                break;
            }
        }

        if (!rejected) {
            throw new SkipException("No PENDING booking found to reject");
        }

        logStep("[DEF-001 TEST] Logout driver — login as passenger and try to re-book");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsPassenger();

        // Navigate back to the SAME trip
        driver.get(tripUrl);
        WaitUtils.waitForUrlContains("/trip/");
        TripDetailPage retryTrip = new TripDetailPage(driver);
        retryTrip.setSeats(1).clickBookNow();

        logStep("[DEF-001] Checking whether re-booking is allowed after rejection...");

        if (retryTrip.isBookingErrorDisplayed()) {
            String errorMsg = retryTrip.getBookingErrorText();
            logStep("[DEF-001] FAIL — Re-booking blocked. Error: " + errorMsg);
            // DEF-001 is reproduced — this Assert.fail marks the test as FAILED
            Assert.fail("DEF-001 REPRODUCED: Rejected passenger cannot re-book same trip. "
                    + "Error: " + errorMsg
                    + "\nFix: Change existsByTripIdAndPassengerIdAndStatusNot "
                    + "to exclude both CANCELLED and REJECTED statuses.");
        } else if (retryTrip.isBookingSuccessDisplayed()) {
            logPass("DEF-001 IS FIXED — Re-booking after rejection now works. "
                    + "Update DEF-001 status to CLOSED.");
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-002 — Any user can view another driver's trip bookings
    //  Expected: FAIL (security bug) | Pass if fixed
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-002 Any Authenticated User Can View Another Drivers Trip Bookings",
          groups = {"defect", "security"},
          description = "DEF-002: GET /api/bookings/trip/{tripId} has no ownership check. "
                      + "Any logged-in user can see all booking details of any trip.")
    public void testDef002AnyUserCanViewTripBookings() {

        logStep("[SETUP] Login as Driver and find a trip with bookings");
        loginAsDriver();

        MyTripsPage myTrips = getMyTripsPage().open();
        if (myTrips.getTripCount() == 0) {
            throw new SkipException("Driver has no trips — need test data");
        }

        TripBookingsPage driverBookings = myTrips.clickManageBookings(0);
        int bookingCount = driverBookings.getBookingCount();
        logStep("[DRIVER] Driver's trip has " + bookingCount + " bookings");

        // Get the trip-bookings URL
        String tripBookingsUrl = driver.getCurrentUrl();
        logStep("[DRIVER] Trip bookings URL: " + tripBookingsUrl);

        if (bookingCount == 0) {
            throw new SkipException("No bookings on driver's trip — need booking data");
        }

        logStep("[DEF-002 TEST] Logout driver — login as DIFFERENT user (Satya)");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsPassenger(); // Satya is NOT the driver of this trip

        logStep("[SATYA] Navigate directly to the DRIVER's trip-bookings URL");
        driver.get(tripBookingsUrl);
        WaitUtils.pause(1000);

        String currentUrl = driver.getCurrentUrl();
        logStep("[SATYA] Current URL after navigation: " + currentUrl);

        if (currentUrl.contains("/trip-bookings/")) {
            // We're on the page — check if booking data is visible
            TripBookingsPage satyaView = new TripBookingsPage(driver);
            int satyaSeenCount = satyaView.getBookingCount();
            logStep("[SATYA] Satya can see " + satyaSeenCount + " bookings on DRIVER's trip");

            if (satyaSeenCount > 0) {
                String passengerName = satyaView.getPassengerName(0);
                logStep("[SATYA] Satya sees passenger name: " + passengerName);

                // DEF-002: This should NOT be accessible — but it IS
                Assert.fail("DEF-002 REPRODUCED: Passenger (Satya) can see "
                        + satyaSeenCount + " booking(s) on Driver's trip "
                        + "without being the trip driver. "
                        + "\nSatya can see passenger: " + passengerName
                        + "\nFix: Add ownership check in BookingService.getTripBookings()");
            } else {
                logPass("DEF-002 APPEARS FIXED — Satya cannot see Driver's bookings. "
                        + "Update DEF-002 to CLOSED.");
            }
        } else {
            logPass("DEF-002 FIXED — Satya redirected away from driver's trip-bookings. "
                    + "Access denied correctly.");
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-006 — Duplicate license plate shows 500 error
    //  Expected: FAIL (shows 500 instead of friendly msg)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-006 Duplicate License Plate Should Show Friendly Error Not 500",
          groups = {"defect", "vehicle"},
          description = "DEF-006: Second vehicle registration with duplicate plate shows "
                      + "raw 500 server error instead of a user-friendly message.")
    public void testDef006DuplicateLicensePlate500Error() {

        logStep("[SETUP] Login as user and register first vehicle");
        loginAsDefaultUser();

        MyVehiclesPage vehiclesPage = getMyVehiclesPage().open();
        String uniquePlate = "DEF006TEST" + (System.currentTimeMillis() % 10000);

        logStep("[SETUP] Register vehicle with plate: " + uniquePlate);
        vehiclesPage.registerVehicle(uniquePlate, "TestCar", "Black", 4);

        logStep("[DEF-006 TEST] Register SECOND vehicle with the SAME plate");
        vehiclesPage.clickRegisterVehicle();
        vehiclesPage.enterLicensePlate(uniquePlate);
        vehiclesPage.enterModel("AnotherCar");
        vehiclesPage.enterColor("White");
        vehiclesPage.enterTotalSeats(3);
        vehiclesPage.clickSave();

        logStep("[DEF-006] Checking error message quality...");

        boolean hasError = vehiclesPage.isErrorAlertDisplayed();
        String errorMsg = hasError ? vehiclesPage.getErrorMessage() : "";
        logStep("[DEF-006] Error displayed: " + hasError + " | Message: " + errorMsg);

        if (!hasError) {
            Assert.fail("DEF-006: No error shown for duplicate license plate registration. "
                    + "Second vehicle should be rejected.");
        }

        // Check if it's a raw 500 message or a friendly one
        boolean isRaw500 = errorMsg.toLowerCase().contains("internal server error")
                || errorMsg.toLowerCase().contains("500")
                || errorMsg.toLowerCase().contains("constraint")
                || errorMsg.toLowerCase().contains("duplicate entry");

        boolean isFriendly = errorMsg.toLowerCase().contains("already")
                || errorMsg.toLowerCase().contains("plate")
                || errorMsg.toLowerCase().contains("exists")
                || errorMsg.toLowerCase().contains("registered");

        if (isRaw500 && !isFriendly) {
            Assert.fail("DEF-006 REPRODUCED: Duplicate license plate shows raw/technical error: '"
                    + errorMsg + "'. "
                    + "\nFix: Add @ExceptionHandler(DataIntegrityViolationException.class) "
                    + "in GlobalExceptionHandler.java");
        } else if (isFriendly) {
            logPass("DEF-006 FIXED — Friendly error shown: " + errorMsg
                    + ". Update DEF-006 to CLOSED.");
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-017 — Forgot password reveals user enumeration
    //  Expected: FAIL (exposes whether email is registered)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-017 Forgot Password Reveals If Email Is Registered (Enumeration Bug)",
          groups = {"defect", "security"},
          description = "DEF-017: /forgot-password shows different messages for registered "
                      + "vs unregistered emails, allowing user enumeration.")
    public void testDef017ForgotPasswordUserEnumeration() {

        logStep("[DEF-017 TEST] Try forgot password with a NON-REGISTERED email");
        ForgotPasswordPage forgotPage = getForgotPasswordPage().open();
        forgotPage.requestPasswordReset("definitely.not.registered@unknown123.com");

        String nonRegisteredResponse = "";
        if (forgotPage.isErrorMessageDisplayed()) {
            nonRegisteredResponse = forgotPage.getErrorMessage();
            logStep("[DEF-017] Response for NON-registered email: " + nonRegisteredResponse);
        } else if (forgotPage.isSuccessMessageDisplayed()) {
            nonRegisteredResponse = forgotPage.getSuccessMessage();
            logStep("[DEF-017] Success for NON-registered email: " + nonRegisteredResponse);
        }

        logStep("[DEF-017 TEST] Now try with a REGISTERED email");
        driver.navigate().refresh();
        WaitUtils.pause(300);
        forgotPage = getForgotPasswordPage();
        forgotPage.requestPasswordReset(ConfigReader.getDefaultUserEmail());

        String registeredResponse = "";
        if (forgotPage.isSuccessMessageDisplayed()) {
            registeredResponse = forgotPage.getSuccessMessage();
            logStep("[DEF-017] Response for REGISTERED email: " + registeredResponse);
        } else if (forgotPage.isErrorMessageDisplayed()) {
            registeredResponse = forgotPage.getErrorMessage();
            logStep("[DEF-017] Error for REGISTERED email: " + registeredResponse);
        }

        logStep("[DEF-017] Comparing responses...");
        logStep("[DEF-017] Non-registered: '" + nonRegisteredResponse + "'");
        logStep("[DEF-017] Registered:     '" + registeredResponse + "'");

        boolean differentResponses = !nonRegisteredResponse.equalsIgnoreCase(registeredResponse);

        if (differentResponses) {
            Assert.fail("DEF-017 REPRODUCED: Different responses reveal which emails are registered.\n"
                    + "Non-registered email response: '" + nonRegisteredResponse + "'\n"
                    + "Registered email response: '" + registeredResponse + "'\n"
                    + "Fix: Return the same generic success message regardless of whether "
                    + "the email exists. E.g., 'If this email is registered, you will receive a reset link.'");
        } else {
            logPass("DEF-017 FIXED — Same response shown for both registered and unregistered emails. "
                    + "Update DEF-017 to CLOSED.");
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-016 — Auto-cancel misses same-day expired trips
    //  Expected: FAIL (date-only comparison misses today's trips)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-016 Auto-Cancel Job Misses Same-Day Expired Trips",
          groups = {"defect", "scheduled"},
          description = "DEF-016: cancelExpiredTrips() uses toLocalDate().isBefore(today) "
                      + "which skips trips that departed earlier today.")
    public void testDef016AutoCancelMissesSameDayTrips() {

        logStep("[SETUP] Login as driver and create a trip");
        loginAsDriver();

        // Check if there are any past-departure SCHEDULED trips visible
        // (These are trips that should have been cancelled but weren't)
        MyTripsPage myTrips = getMyTripsPage().open();

        boolean foundUncancelled = false;
        for (int i = 0; i < myTrips.getTripCount(); i++) {
            String status = myTrips.getTripStatus(i);
            // A SCHEDULED trip that is in the past = not auto-cancelled
            if ("SCHEDULED".equalsIgnoreCase(status)) {
                logStep("[DEF-016] Found SCHEDULED trip at index " + i
                        + " — checking if it's in the past");
                // In a full test environment, we'd check the departure time
                // and verify today's past trips are NOT being auto-cancelled
                foundUncancelled = true;
            }
        }

        logStep("[DEF-016] This test requires DB manipulation to set "
                + "departure_time to earlier today and then trigger the job.");
        logStep("[DEF-016] The bug: toLocalDate().isBefore(today) only cancels "
                + "trips from YESTERDAY — not trips from EARLIER TODAY.");
        logStep("[DEF-016] Fix: Use t.getDepartureTime().isBefore(LocalDateTime.now()) "
                + "instead of toLocalDate comparison.");

        // Document the defect clearly — test is skipped if no manipulated data
        throw new SkipException("DEF-016: Requires DB setup to set departure_time "
                + "to earlier today. Manually verified: "
                + "auto-cancel job compares dates not datetimes, "
                + "missing same-day expired trips. "
                + "Fix: compare full LocalDateTime, not just LocalDate.");
    }

    // ══════════════════════════════════════════════════
    //  DEF-007 — Recurring trip search shows all siblings
    //  Expected: FAIL (shows 5 results instead of 1)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-007 Recurring Trip Search Should Show Only Earliest Sibling",
          groups = {"defect", "search"},
          description = "DEF-007: searchTrips() returns ALL sibling trips in a recurring group. "
                      + "FR-SRCH-09 requires only the earliest sibling to be shown.")
    public void testDef007RecurringTripDeduplication() {

        logStep("[SETUP] Login as Driver and create a 5-day recurring trip MON-FRI");
        loginAsDriver();

        CreateTripPage createTrip = getCreateTripPage().open();
        createTrip.setPickupLocation("Chennai");
        createTrip.setDropoffLocation("Bangalore");
        createTrip.setDepartureTime(
                java.time.LocalDateTime.now().plusHours(2)
                        .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")));
        createTrip.setAvailableSeats(3);

        // Try to enable recurring
        try {
            createTrip.enableRecurring();
            createTrip.setDailyRate(150.0);
        } catch (Exception e) {
            logStep("[DEF-007] Could not enable recurring — using single trip instead");
        }

        if (!createTrip.areLocationsSet()) {
            throw new SkipException("DEF-007: Locations not set via map — "
                    + "need Photon API to reproduce this test");
        }

        createTrip.clickCreateTrip();
        boolean created = createTrip.isSuccessAlertDisplayed()
                || driver.getCurrentUrl().contains("/my-trips");

        if (!created) {
            throw new SkipException("DEF-007: Trip creation failed — cannot test deduplication");
        }

        logStep("[DEF-007 TEST] Logout and login as passenger");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsPassenger();

        logStep("[DEF-007] Search for the recurring trip route");
        SearchTripsPage search = getSearchTripsPage().open();
        search.enterOrigin("Chennai").enterDestination("Bangalore").clickSearch();

        int resultCount = search.getResultsCount();
        logStep("[DEF-007] Results returned: " + resultCount);

        if (resultCount > 1) {
            // Check if multiple results share the same route (sibling trips)
            logStep("[DEF-007] Multiple results found for same route");
            logStep("[DEF-007] DEFECT PRESENT: All sibling trips shown (" + resultCount + ")");
            logStep("[DEF-007] Expected: Only 1 result (earliest sibling) per FR-SRCH-09");
            Assert.fail("DEF-007 REPRODUCED: Search returns " + resultCount
                    + " sibling trips for the same recurring route. "
                    + "FR-SRCH-09 requires only the earliest sibling to be shown. "
                    + "Fix: Add deduplication logic in SearchTrips frontend component "
                    + "to show only the trip with the earliest departureTime per recurringGroupId.");
        } else {
            logPass("DEF-007 MAY BE FIXED — Only " + resultCount
                    + " result shown. Verify it's the earliest sibling.");
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-008 — City filter too restrictive
    //  Expected: FAIL (Chennai user cannot find Bangalore→Chennai trips)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-008 City Filter Blocks Intercity Trips From Other Origins",
          groups = {"defect", "search"},
          description = "DEF-008: Search filters by driver.city = passenger.city, "
                      + "blocking intercity trips even when destination matches.")
    public void testDef008CityFilterTooRestrictive() {

        logStep("[SETUP] Login as Driver with city=Bangalore and create Bangalore→Chennai trip");
        loginAsDriver();

        CreateTripPage ct = getCreateTripPage().open();
        ct.setPickupLocation("Bangalore");
        ct.setDropoffLocation("Chennai");
        ct.setDepartureTime(
                java.time.LocalDateTime.now().plusHours(4)
                        .format(java.time.format.DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm")));
        ct.setAvailableSeats(2);
        ct.setPricePerSeat(200.0);

        if (!ct.areLocationsSet()) {
            throw new SkipException("DEF-008: Map locations not set — need Photon API");
        }

        ct.clickCreateTrip();
        boolean created = ct.isSuccessAlertDisplayed()
                || driver.getCurrentUrl().contains("/my-trips");
        if (!created) {
            throw new SkipException("DEF-008: Trip creation failed");
        }

        logStep("[SETUP] Logout driver — login as PASSENGER with city=Chennai");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsPassenger(); // passenger city = Chennai

        logStep("[DEF-008 TEST] Search Bangalore→Chennai");
        SearchTripsPage search = getSearchTripsPage().open();
        search.enterOrigin("Bangalore").enterDestination("Chennai").clickSearch();

        int results = search.getResultsCount();
        logStep("[DEF-008] Results for Bangalore→Chennai: " + results);

        if (results == 0) {
            Assert.fail("DEF-008 REPRODUCED: Chennai passenger cannot find "
                    + "Bangalore→Chennai trip because city filter uses driver.city='Bangalore' "
                    + "but passenger.city='Chennai', so the trip is excluded. "
                    + "\nFix: City filter should be optional OR filter by trip origin/destination "
                    + "city, not driver's registered city.");
        } else {
            logPass("DEF-008 FIXED — Chennai passenger found Bangalore→Chennai trip. "
                    + "Update DEF-008 to CLOSED. Results: " + results);
        }
    }

    // ══════════════════════════════════════════════════
    //  DEF-004 — Password exposed in profile API response
    //  Expected: FAIL (hashed password visible in network)
    // ══════════════════════════════════════════════════

    @Test(testName = "DEF-004 Profile Response Should Not Expose Password Hash",
          groups = {"defect", "security"},
          description = "DEF-004: GET /api/auth/profile returns full User entity "
                      + "including BCrypt hashed password field.")
    public void testDef004PasswordExposedInProfileResponse() {

        logStep("[DEF-004 TEST] Login and load profile page");
        loginAsDefaultUser();

        logStep("[DEF-004] Use JavaScript fetch to call /api/auth/profile and check response");
        Object responseJson = ((org.openqa.selenium.JavascriptExecutor) driver)
                .executeScript(
                    "const token = localStorage.getItem('token');" +
                    "return fetch('" + ConfigReader.get("api.base.url") + "/auth/profile', {" +
                    "  headers: { 'Authorization': 'Bearer ' + token }" +
                    "}).then(r => r.json()).then(d => JSON.stringify(d));" );

        // Wait for promise to resolve
        WaitUtils.pause(2000);

        logStep("[DEF-004] Fetching profile data to check for password field...");

        // Alternative: check via page source or LocalStorage inspection
        // The real test is done by reading the network response
        // Since we cannot directly read the fetch result synchronously in this way,
        // we navigate to profile and verify through the page

        ProfilePage profilePage = getProfilePage().open();
        Assert.assertTrue(profilePage.isPageLoaded(),
                "Profile page should load");

        // In a real environment, intercept the network request
        // For now, we document this as requiring proxy/network interception
        logStep("[DEF-004] To fully reproduce: Open DevTools → Network → "
                + "find profile request → Response tab → look for 'password' field.");
        logStep("[DEF-004] Expected: 'password' field should NOT be in response JSON.");
        logStep("[DEF-004] Fix: Create ProfileResponse DTO excluding password field.");

        // This test documents the defect rather than hard-failing
        // because verifying HTTP response body requires network interception
        logStep("[DEF-004] MANUAL VERIFICATION REQUIRED — See defect report for steps.");
        logPass("DEF-004 documented — requires manual network inspection to verify ✓");
    }
}
