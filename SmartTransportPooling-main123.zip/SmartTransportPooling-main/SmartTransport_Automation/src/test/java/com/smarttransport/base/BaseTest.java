package com.smarttransport.base;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.smarttransport.pages.*;
import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.DriverFactory;
import com.smarttransport.utils.ScreenshotUtils;
import com.smarttransport.utils.WaitUtils;
import com.smarttransport.utils.WaitUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.lang.reflect.Method;

/**
 * BaseTest — Parent class for ALL test classes.
 *
 * Responsibilities:
 *  - @BeforeSuite  : Initialize ExtentReports once
 *  - @BeforeMethod : Start driver, open browser, log test start
 *  - @AfterMethod  : Capture screenshot on failure, log result, quit driver
 *  - @AfterSuite   : Flush Extent Report to HTML
 *
 *  Every test class MUST extend BaseTest.
 */
public class BaseTest {

    private static final Logger log = LogManager.getLogger(BaseTest.class);

    // ExtentReports — shared across all tests in the suite
    protected static ExtentReports extent;
    // ThreadLocal so parallel tests each get their own ExtentTest node
    protected static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    protected WebDriver driver;

    // ──────────────────────────────────────────────
    //  Suite Setup & Teardown
    // ──────────────────────────────────────────────

    @BeforeSuite(alwaysRun = true)
    public void initReport() {
        String reportDir  = ConfigReader.getReportsDir();
        String reportPath = reportDir + "/SmartTransport_AutoReport.html";

        // Create reports directory
        new File(reportDir).mkdirs();
        new File(ConfigReader.getScreenshotsDir()).mkdirs();
        new File("test-output/logs").mkdirs();

        ExtentSparkReporter spark = new ExtentSparkReporter(reportPath);
        spark.config().setDocumentTitle("SmartTransport Automation Report");
        spark.config().setReportName("SmartTransport - Selenium Test Results");
        spark.config().setTheme(
                com.aventstack.extentreports.reporter.configuration.Theme.DARK);

        extent = new ExtentReports();
        extent.attachReporter(spark);
        extent.setSystemInfo("Application", "SmartTransport Pooling");
        extent.setSystemInfo("Environment", ConfigReader.getBaseUrl());
        extent.setSystemInfo("Browser", ConfigReader.getBrowser());
        extent.setSystemInfo("Tester", "QA Team");

        log.info("ExtentReports initialized. Report path: {}", reportPath);
    }

    @AfterSuite(alwaysRun = true)
    public void flushReport() {
        if (extent != null) {
            extent.flush();
            log.info("ExtentReports flushed successfully.");
        }
    }

    // ──────────────────────────────────────────────
    //  Test Setup & Teardown
    // ──────────────────────────────────────────────

    @BeforeMethod(alwaysRun = true)
    public void setUp(Method method) {
        // Initialize the browser
        DriverFactory.initDriver();
        driver = DriverFactory.getDriver();

        // Create ExtentTest node for this test method
        Test testAnnotation = method.getAnnotation(Test.class);
        String testName = testAnnotation != null && !testAnnotation.testName().isEmpty()
                ? testAnnotation.testName()
                : method.getName();

        ExtentTest test = extent.createTest(testName);
        extentTest.set(test);

        log.info("====== STARTING TEST: {} ======", method.getName());
        extentTest.get().log(Status.INFO, "Browser started: " + ConfigReader.getBrowser());
        extentTest.get().log(Status.INFO, "URL: " + ConfigReader.getBaseUrl());
    }

    @AfterMethod(alwaysRun = true)
    public void tearDown(ITestResult result) {
        // Handle test result
        if (result.getStatus() == ITestResult.FAILURE) {
            log.error("TEST FAILED: {}", result.getName());
            log.error("Failure reason: {}", result.getThrowable().getMessage());

            // Capture screenshot on failure
            if (ConfigReader.isScreenshotOnFail()) {
                String screenshotBase64 = ScreenshotUtils.captureBase64();
                if (screenshotBase64 != null) {
                    extentTest.get().fail("Test Failed: " + result.getThrowable().getMessage())
                            .addScreenCaptureFromBase64String(screenshotBase64);
                } else {
                    extentTest.get().fail("Test Failed: " + result.getThrowable().getMessage());
                }
            }
        } else if (result.getStatus() == ITestResult.SUCCESS) {
            log.info("TEST PASSED: {}", result.getName());
            extentTest.get().pass("Test Passed");
        } else if (result.getStatus() == ITestResult.SKIP) {
            log.warn("TEST SKIPPED: {}", result.getName());
            extentTest.get().skip("Test Skipped: " + result.getSkipCausedBy());
        }

        log.info("====== FINISHED TEST: {} ======\n", result.getName());

        // Close browser
        DriverFactory.quitDriver();
    }

    // ──────────────────────────────────────────────
    //  Helper Methods for Tests
    // ──────────────────────────────────────────────

    /**
     * Logs a step to both Log4j and ExtentReport.
     */
    protected void logStep(String message) {
        log.info("STEP: {}", message);
        if (extentTest.get() != null) {
            extentTest.get().log(Status.INFO, message);
        }
    }

    /**
     * Logs a pass assertion to ExtentReport.
     */
    protected void logPass(String message) {
        log.info("PASS: {}", message);
        if (extentTest.get() != null) {
            extentTest.get().pass(message);
        }
    }

    /**
     * Logs a fail to ExtentReport with screenshot.
     */
    protected void logFail(String message) {
        log.error("FAIL: {}", message);
        if (extentTest.get() != null) {
            String b64 = ScreenshotUtils.captureBase64();
            if (b64 != null) {
                extentTest.get().fail(message)
                        .addScreenCaptureFromBase64String(b64);
            } else {
                extentTest.get().fail(message);
            }
        }
    }

    // ──────────────────────────────────────────────
    //  Page Factory Getters — Create Page Objects
    // ──────────────────────────────────────────────

    protected LoginPage getLoginPage()                   { return new LoginPage(driver); }
    protected RegisterPage getRegisterPage()             { return new RegisterPage(driver); }
    protected DashboardPage getDashboardPage()           { return new DashboardPage(driver); }
    protected SearchTripsPage getSearchTripsPage()       { return new SearchTripsPage(driver); }
    protected CreateTripPage getCreateTripPage()         { return new CreateTripPage(driver); }
    protected MyTripsPage getMyTripsPage()               { return new MyTripsPage(driver); }
    protected MyBookingsPage getMyBookingsPage()         { return new MyBookingsPage(driver); }
    protected MyVehiclesPage getMyVehiclesPage()         { return new MyVehiclesPage(driver); }
    protected NotificationsPage getNotificationsPage()   { return new NotificationsPage(driver); }
    protected ForgotPasswordPage getForgotPasswordPage() { return new ForgotPasswordPage(driver); }
    protected AdminDashboardPage getAdminDashboardPage() { return new AdminDashboardPage(driver); }
    protected AdminOrganizationsPage getAdminOrgsPage()  { return new AdminOrganizationsPage(driver); }
    protected AdminVehiclesPage getAdminVehiclesPage()   { return new AdminVehiclesPage(driver); }
    // ── Newly added missing pages ──
    protected LandingPage getLandingPage()               { return new LandingPage(driver); }
    protected ProfilePage getProfilePage()               { return new ProfilePage(driver); }
    protected ResetPasswordPage getResetPasswordPage()   { return new ResetPasswordPage(driver); }
    protected VerifyEmailPage getVerifyEmailPage()       { return new VerifyEmailPage(driver); }

    // ──────────────────────────────────────────────
    //  Common Reusable Flows
    // ──────────────────────────────────────────────

    /**
     * Logs in as default user and returns DashboardPage.
     */
    protected DashboardPage loginAsDefaultUser() {
        logStep("Logging in as default user: " + ConfigReader.getDefaultUserEmail());
        return getLoginPage()
                .open()
                .loginAs(ConfigReader.getDefaultUserEmail(),
                         ConfigReader.getDefaultUserPass());
    }

    /**
     * Logs in as admin and returns AdminDashboardPage.
     */
    protected AdminDashboardPage loginAsAdmin() {
        logStep("Logging in as ADMIN: " + ConfigReader.getAdminEmail());
        getLoginPage()
                .open()
                .loginAs(ConfigReader.getAdminEmail(), ConfigReader.getAdminPassword());
        return getAdminDashboardPage();
    }

    /**
     * Logs in as driver user.
     */
    protected DashboardPage loginAsDriver() {
        logStep("Logging in as Driver: " + ConfigReader.getDriverEmail());
        return getLoginPage()
                .open()
                .loginAs(ConfigReader.getDriverEmail(), ConfigReader.getDriverPass());
    }

    /**
     * Logs in as passenger user.
     */
    protected DashboardPage loginAsPassenger() {
        logStep("Logging in as Passenger: " + ConfigReader.getPassengerEmail());
        return getLoginPage()
                .open()
                .loginAs(ConfigReader.getPassengerEmail(), ConfigReader.getPassengerPass());
    }
}
