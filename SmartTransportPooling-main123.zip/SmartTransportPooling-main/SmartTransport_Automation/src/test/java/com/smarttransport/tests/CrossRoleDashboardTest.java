package com.smarttransport.tests;

import com.smarttransport.base.BaseTest;
import com.smarttransport.pages.*;
import com.smarttransport.utils.ConfigReader;
import com.smarttransport.utils.WaitUtils;
import org.testng.Assert;
import org.testng.annotations.Test;

/**
 * CrossRoleDashboardTest — Tests that verify the SAME dashboard
 * behaves differently for ADMIN vs USER vs DRIVER vs PASSENGER.
 *
 * These are the multi-role sequential tests where we:
 *  - Login as User A → do action → logout
 *  - Login as User B → verify the result
 * All within a single browser session to simulate real usage.
 */
public class CrossRoleDashboardTest extends BaseTest {

    // ──────────────────────────────────────────────
    //  TEST 1: Admin Dashboard vs User Dashboard
    //  Same /dashboard URL but completely different
    //  content and sidebar for each role
    // ──────────────────────────────────────────────

    @Test(testName = "CROSS-ROLE-01 Admin And User See Different Dashboards At Same URL",
          groups = {"cross-role", "dashboard"})
    public void testAdminAndUserSeeDifferentDashboards() {

        // ── STEP 1: Login as ADMIN ──
        logStep("[ADMIN] Login as ADMIN user");
        AdminDashboardPage adminDashboard = loginAsAdmin();

        logStep("[ADMIN] Verify admin-specific stats are present");
        int totalUsers  = adminDashboard.getTotalUsers();
        int totalTrips  = adminDashboard.getTotalTrips();
        int totalOrgs   = adminDashboard.getTotalOrganizations();
        logStep("[ADMIN] Stats — Users:" + totalUsers
                + " Trips:" + totalTrips + " Orgs:" + totalOrgs);

        Assert.assertTrue(adminDashboard.isAdminOrgsSidebarVisible(),
                "[ADMIN] Organizations sidebar should be visible for admin");
        Assert.assertFalse(adminDashboard.isSearchRidesSidebarVisible(),
                "[ADMIN] Search Rides should NOT be visible for admin");

        logStep("[ADMIN] URL should contain /admin/dashboard");
        Assert.assertTrue(driver.getCurrentUrl().contains("/admin/dashboard"),
                "[ADMIN] Admin should land on /admin/dashboard");

        // ── STEP 2: Logout from ADMIN ──
        logStep("[ADMIN] Logout from admin account");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");

        // ── STEP 3: Login as regular USER ──
        logStep("[USER] Login as regular USER");
        DashboardPage userDashboard = getLoginPage()
                .loginAs(ConfigReader.getDefaultUserEmail(),
                         ConfigReader.getDefaultUserPass());

        logStep("[USER] Verify user-specific dashboard content");
        Assert.assertTrue(userDashboard.isDashboardLoaded(),
                "[USER] Dashboard should load for regular user");

        logStep("[USER] Verify user sidebar has ride navigation");
        Assert.assertTrue(userDashboard.isSidebarSearchRidesVisible(),
                "[USER] Search Rides should be visible for regular user");
        Assert.assertTrue(userDashboard.isSidebarCreateTripVisible(),
                "[USER] Create Trip should be visible for regular user");
        Assert.assertTrue(userDashboard.isSidebarMyTripsVisible(),
                "[USER] My Trips should be visible for regular user");

        logStep("[USER] Verify admin-only links NOT in user sidebar");
        Assert.assertFalse(userDashboard.isSidebarAdminDashboardVisible(),
                "[USER] Admin Dashboard link should NOT be in user sidebar");
        Assert.assertFalse(userDashboard.isSidebarAdminOrgsVisible(),
                "[USER] Organizations link should NOT be in user sidebar");

        logStep("[USER] URL should be /dashboard not /admin/dashboard");
        Assert.assertTrue(driver.getCurrentUrl().contains("/dashboard")
                && !driver.getCurrentUrl().contains("/admin"),
                "[USER] Regular user should be on /dashboard, not /admin/dashboard");

        // ── STEP 4: User tries to access admin dashboard ──
        logStep("[USER] Attempt to access /admin/dashboard as regular user");
        driver.get(ConfigReader.getBaseUrl() + "/admin/dashboard");
        WaitUtils.waitForUrlContains("/dashboard");

        Assert.assertFalse(driver.getCurrentUrl().contains("/admin/dashboard"),
                "[USER] Regular user should be redirected away from /admin/dashboard");

        logPass("CROSS-ROLE-01 PASSED — Admin and User see completely different dashboards");
    }

    // ──────────────────────────────────────────────
    //  TEST 2: Driver Dashboard Stats vs Passenger Dashboard Stats
    //  Same user dashboard but different counts
    //  based on each person's own data
    // ──────────────────────────────────────────────

    @Test(testName = "CROSS-ROLE-02 Driver And Passenger Have Different Dashboard Stats",
          groups = {"cross-role", "dashboard"})
    public void testDriverAndPassengerDifferentStats() {

        // ── Login as DRIVER ──
        logStep("[DRIVER] Login as Driver");
        DashboardPage driverDashboard = loginAsDriver();

        logStep("[DRIVER] Read driver's dashboard stats");
        int driverTrips    = driverDashboard.getMyTripsCount();
        int driverBookings = driverDashboard.getMyBookingsCount();
        int driverPending  = driverDashboard.getPendingCount();
        int driverActive   = driverDashboard.getActiveCount();

        logStep("[DRIVER] Stats — Trips:" + driverTrips
                + " Bookings:" + driverBookings
                + " Pending:" + driverPending
                + " Active:" + driverActive);

        Assert.assertTrue(driverTrips >= 0,   "[DRIVER] Trip count should be >= 0");
        Assert.assertTrue(driverBookings >= 0, "[DRIVER] Booking count should be >= 0");

        // Verify driver has trip creation tools available
        Assert.assertTrue(driverDashboard.isSidebarCreateTripVisible(),
                "[DRIVER] Create Trip option should be visible for driver");

        logStep("[DRIVER] Logout driver account");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");

        // ── Login as PASSENGER ──
        logStep("[PASSENGER] Login as Passenger");
        DashboardPage passengerDashboard = loginAsPassenger();

        logStep("[PASSENGER] Read passenger's dashboard stats");
        int passengerTrips    = passengerDashboard.getMyTripsCount();
        int passengerBookings = passengerDashboard.getMyBookingsCount();
        int passengerPending  = passengerDashboard.getPendingCount();

        logStep("[PASSENGER] Stats — Trips:" + passengerTrips
                + " Bookings:" + passengerBookings
                + " Pending:" + passengerPending);

        Assert.assertTrue(passengerBookings >= 0,
                "[PASSENGER] Booking count should be >= 0");

        // Verify passenger also has booking search available
        Assert.assertTrue(passengerDashboard.isSidebarSearchRidesVisible(),
                "[PASSENGER] Search Rides should be accessible for passenger");
        Assert.assertTrue(passengerDashboard.isSidebarMyBookingsVisible(),
                "[PASSENGER] My Bookings should be accessible for passenger");

        logStep("Verify driver and passenger dashboard data is INDEPENDENT");
        // Each person should only see their OWN data — their counts may differ
        logStep("Driver trip count: " + driverTrips
                + " vs Passenger trip count: " + passengerTrips);

        logPass("CROSS-ROLE-02 PASSED — Driver and Passenger have independent dashboard stats");
    }

    // ──────────────────────────────────────────────
    //  TEST 3: Admin Notifications vs User Notifications
    //  Admin should NOT see notification bell polling
    //  Regular user SHOULD see notification bell
    // ──────────────────────────────────────────────

    @Test(testName = "CROSS-ROLE-03 Admin Has No Notification Bell User Has Notification Bell",
          groups = {"cross-role", "notification"})
    public void testAdminHasNoNotificationBellUserHasIt() {

        // ── Login as ADMIN ──
        logStep("[ADMIN] Login as Admin");
        AdminDashboardPage adminDash = loginAsAdmin();

        logStep("[ADMIN] Verify notification bell badge is NOT shown for admin");
        // Admin layout does not show notification bell (confirmed in layout.ts)
        boolean adminBadgeVisible = adminDash.isPageLoaded()
                && driver.findElements(
                        org.openqa.selenium.By.cssSelector(".notif-badge")).isEmpty();
        logStep("[ADMIN] Notification badge present: " + !adminBadgeVisible);

        // Admin sidebar doesn't have bell badge — verify admin is on admin dashboard
        Assert.assertTrue(driver.getCurrentUrl().contains("/admin"),
                "[ADMIN] Admin should be on admin route");

        logStep("[ADMIN] Logout admin");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");

        // ── Login as USER ──
        logStep("[USER] Login as regular user");
        DashboardPage userDash = loginAsDefaultUser();

        logStep("[USER] Verify notification bell icon is present in navbar");
        // Bell icon href points to /notifications
        boolean bellPresent = !driver.findElements(
                org.openqa.selenium.By.cssSelector(
                        "a[routerLink='/notifications'], a[href*='notifications']"))
                .isEmpty();

        Assert.assertTrue(bellPresent,
                "[USER] Notification bell link should be present in navbar for regular user");

        logStep("[USER] Navigate to notifications page");
        NotificationsPage notifPage = getNotificationsPage().open();

        logStep("[USER] Verify notifications page loads for user");
        Assert.assertTrue(driver.getCurrentUrl().contains("/notifications"),
                "[USER] Should be on /notifications page");

        logPass("CROSS-ROLE-03 PASSED — Admin has no bell; User has notification bell");
    }

    // ──────────────────────────────────────────────
    //  TEST 4: Admin Sees ALL vehicles pending
    //  User sees ONLY their own vehicles
    // ──────────────────────────────────────────────

    @Test(testName = "CROSS-ROLE-04 Admin Sees All Pending Vehicles User Sees Only Own",
          groups = {"cross-role", "vehicle"})
    public void testAdminSeesAllVehiclesUserSeesOwn() {

        // ── Login as USER and register a vehicle ──
        logStep("[USER] Login as user and navigate to My Vehicles");
        loginAsDefaultUser();
        MyVehiclesPage myVehicles = getMyVehiclesPage().open();

        int userVehicleCount = myVehicles.getVehicleCount();
        logStep("[USER] User's vehicle count: " + userVehicleCount);

        // ── Logout and login as different user ──
        logStep("[USER2] Login as different user (driver account)");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        getLoginPage().loginAs(ConfigReader.getDriverEmail(), ConfigReader.getDriverPass());

        MyVehiclesPage driverVehicles = getMyVehiclesPage().open();
        int driverVehicleCount = driverVehicles.getVehicleCount();
        logStep("[DRIVER] Driver's vehicle count: " + driverVehicleCount);

        logStep("Verify each user sees only their own vehicles — counts may differ");
        Assert.assertTrue(userVehicleCount >= 0,
                "User vehicle count should be >= 0");
        Assert.assertTrue(driverVehicleCount >= 0,
                "Driver vehicle count should be >= 0");

        // ── Logout and login as ADMIN ──
        logStep("[ADMIN] Login as Admin and check pending vehicles");
        driver.get(ConfigReader.getBaseUrl() + "/login");
        WaitUtils.waitForUrlContains("/login");
        loginAsAdmin();

        AdminVehiclesPage adminVehicles = getAdminVehiclesPage().open();
        int pendingCount = adminVehicles.getPendingVehicleCount();
        logStep("[ADMIN] Admin sees " + pendingCount + " pending vehicles total (ALL users)");

        Assert.assertTrue(pendingCount >= 0,
                "[ADMIN] Pending vehicles count should be >= 0");

        logPass("CROSS-ROLE-04 PASSED — Admin sees all pending, users see only their own");
    }

    // ──────────────────────────────────────────────
    //  TEST 5: Admin Dashboard Stats Reflect Real Counts
    //  After admin whitelists a new domain and a user registers,
    //  admin stats should update
    // ──────────────────────────────────────────────

    @Test(testName = "CROSS-ROLE-05 Admin Stats Update After New Organization Added",
          groups = {"cross-role", "admin", "dashboard"})
    public void testAdminStatsUpdateAfterOrgAdded() {

        // ── Login as ADMIN and read initial org count ──
        logStep("[ADMIN] Login as Admin");
        AdminDashboardPage adminDash = loginAsAdmin();

        int orgCountBefore = adminDash.getTotalOrganizations();
        logStep("[ADMIN] Initial organization count: " + orgCountBefore);

        // ── Create a new organization ──
        logStep("[ADMIN] Navigate to Organizations and create new one");
        AdminOrganizationsPage orgsPage = getAdminOrgsPage().open();
        String uniqueDomain = "crossrole" + System.currentTimeMillis() + ".com";
        orgsPage.createOrganization("CrossRole Org", uniqueDomain, true);

        logStep("[ADMIN] Navigate back to Admin Dashboard");
        adminDash = getAdminDashboardPage().open();

        int orgCountAfter = adminDash.getTotalOrganizations();
        logStep("[ADMIN] Organization count after adding: " + orgCountAfter);

        Assert.assertTrue(orgCountAfter >= orgCountBefore,
                "[ADMIN] Organization count should be >= previous count after adding new org");

        logPass("CROSS-ROLE-05 PASSED — Admin stats updated after org creation");
    }
}
